CREATE OR REPLACE PROCEDURE los.sp_login_main_daily_load()
 LANGUAGE plpgsql
AS $$
BEGIN 

delete from reporting.Login_main_daily
where mis_date=current_date;

--=========================inserting MongoDB data from lms.vw_EPIK_login to merge into  reporting table  ==================================================================
Insert into Reporting.Login_main_daily
SELECT applicant_id,sz_application_no,customer_id,customer_name,branch_cd,cro_code,vcp_id,vcp_name,mobile_no,
-- loan_amount,
case when loan_amount like '' or loan_amount like ' ' or loan_amount is null
then cast(0 as int) else cast(loan_amount as numeric(18,2)) end,
-- appliedamount,
case when appliedamount like '' or appliedamount like ' ' or appliedamount is null
then cast(0 as int) else cast(appliedamount as numeric(18,2)) end,
-- net_applied_amt,
case when net_applied_amt like '' or net_applied_amt like ' ' or net_applied_amt is null
then cast(0 as int) else cast(net_applied_amt as numeric(18,2)) end,
-- net_loan_amt,
case when net_loan_amt like '' or net_loan_amt like ' ' or net_loan_amt is null
then cast(0 as int) else cast(net_loan_amt as numeric(18,2)) end,
-- eb_outstanding_amt,
case when eb_outstanding_amt like '' or eb_outstanding_amt like ' ' or eb_outstanding_amt is null
then cast(0 as int) else cast(eb_outstanding_amt as numeric(18,2)) end,
-- i_tenor,
case when i_tenor like '' or i_tenor like ' ' or i_tenor is null
then cast(0 as int) else cast(i_tenor as numeric(18,2)) end,
-- f_interest_rate,
case when f_interest_rate like '' or f_interest_rate like ' ' or f_interest_rate is null
then cast(0 as int) else cast(f_interest_rate as numeric(18,2)) end,
-- application_fee,
case when application_fee like '' or application_fee like ' ' or application_fee is null
then cast(0 as int) else cast(application_fee as numeric(18,2)) end,
-- disbursed_amt,
case when disbursed_amt like '' or disbursed_amt like ' ' or disbursed_amt is null
then cast(0 as int) else cast(disbursed_amt as numeric(18,2)) end,
fee_payment_status,
-- sanctioned_amt,
case when sanctioned_amt like '' or sanctioned_amt like ' ' or sanctioned_amt is null
then cast(0 as int) else cast(sanctioned_amt as numeric(18,2)) end,
rejection_reason,
sz_oldlan,
cibil_score,
property_type,
sectors,
login_status,
customer_type_sourcing,
branch_product,
current_step_name,
existing_customer,
facility_type,
product,
branchcro,
rcu_final_status,
rcu_kyc_status,
-- cast(creation_date as date),
to_date(creation_date, 'YYYY/MM/DD') as creation_date ,
-- cast(application_fee_date as date),
to_date(application_fee_date, 'YYYY/MM/DD') as application_fee_date ,
-- cast(submission_date as date),
to_date(submission_date, 'YYYY/MM/DD') as submission_date ,
-- cast(cmfa_max_date as date),
to_date(cmfa_max_date, 'YYYY/MM/DD') as cmfa_max_date ,
-- cast(soft_approval_date as date),
to_date(soft_approval_date, 'YYYY/MM/DD') as soft_approval_date ,
-- cast(approval_date as date),
to_date(approval_date, 'YYYY/MM/DD') as approval_date ,
-- cast(du_1 as date),
to_date(du_1, 'YYYY/MM/DD') as du_1 ,
-- cast(disb_date as date),
to_date(disb_date, 'YYYY/MM/DD') as disb_date ,
-- cast(disb_tranche_2 as date),
to_date(disb_tranche_2, 'YYYY/MM/DD') as disb_tranche_2 ,
-- cast(disb_tranche_3 as date),
to_date(disb_tranche_3, 'YYYY/MM/DD') as disb_tranche_3 ,
-- cast(soft_reject_date as date),
to_date(soft_reject_date, 'YYYY/MM/DD') as soft_reject_date ,
-- cast(hard_reject_date as date),
to_date(hard_reject_date, 'YYYY/MM/DD') as hard_reject_date ,
-- cast(rejection_date as date),
to_date(rejection_date, 'YYYY/MM/DD') as rejection_date ,
login_status_v1,
-- cast(cm_pd_date as date),
to_date(cm_pd_date, 'YYYY/MM/DD') as cm_pd_date ,
-- cast(cibil_trigger_date as date),
to_date(cibil_trigger_date, 'YYYY/MM/DD') as cibil_trigger_date ,
-- cast(fit_dufin_date as date),
to_date(fit_dufin_date, 'YYYY/MM/DD') as fit_dufin_date ,
dup_check,
flag,                                            
cro_name,
mis_date,
to_date(disbursement_date, 'YYYY/MM/DD') as disbursement_date,
Legal_report_Received,
to_date(Legal_Report_Date, 'YYYY/MM/DD') as Legal_Report_Date ,
Final_Recommendation
 
from los.vw_epik_login
WHERE flag='N' OR 
((flag='CF' AND login_status_v1='Approved' AND (last_day(to_date(disb_date,'YYYY/MM/DD')) = last_day(current_date) OR disb_date IS NULL))) OR
((flag='CF' AND login_status_v1='Rejection' AND (last_day(to_date(rejection_date,'YYYY/MM/DD')) = last_day(current_date)))) OR
(flag='CF' AND login_status_v1='Pending');

--=========================inserting oracle data from lms.vw_login to merge into  reporting table  ==================================================================

insert into Reporting.Login_main_daily
(sz_application_no, customer_id,customer_name,branch_cd,cro_code,vcp_id,mobile_no, loan_amount, appliedamount,net_applied_amt, net_loan_amt,
eb_outstanding_amt, application_fee, fee_payment_status, sanctioned_amt,rejection_reason, sectors, login_status, branch_product, branchcro,
creation_date, submission_date, soft_approval_date, approval_date, du_1, rejection_date, dup_check, CRO_NAME,login_status_v1,mis_date,flag)

Select 
sz_application_no as sz_application_no,
sz_customer_no as customer_id,
(firstname||lastname) as customer_name,
branchcode as branch_cd,
openedby as cro_code,
vcp_id as vcp_id,
aadhar_card as mobile_no,
loanamount as loan_amount,
appliedamount as appliedamount,
netapplied_amt as net_applied_amt,
(case when loanamount is null then appliedamount else loan_amount end) as net_loan_amt,
eb_outstanding_amt as eb_outstanding_amt,
f_afee_amount as application_fee,
sz_payment_mode as fee_payment_status,
f_sanctioned_amt as sanctioned_amt,
rejectedreason as rejection_reason,
sector as sectors,
status as login_status,
sz_product_code as branch_product,
branchname as branchcro,
creation_date as creation_date,
submission_date as submission_date,
soft_approval_dt as soft_approval_date,
approval_dt as approval_date,
du1_dt as du_1,
rejection_date as rejection_date,
dup_check as dup_check,
cro_name as CRO_NAME,
login_status As login_status_v1,
mis_date,
flag

from lms.vw_login ----Indus login  oracle data 
WHERE (submission_date >= last_day(add_months(trunc(CURRENT_DATE), -2)) + 1  AND submission_date <= last_day(trunc(CURRENT_DATE)))
    OR (last_day(submission_date) != last_day(CURRENT_DATE) AND last_day(approval_dt) = last_day(CURRENT_DATE))
    OR (last_day(submission_date) != last_day(CURRENT_DATE) AND last_day(rejection_date) = last_day(CURRENT_DATE))
    OR (last_day(submission_date) != last_day(CURRENT_DATE) AND login_status1='Pending');

-- ==============================MONTHLY DATA LOAD ========================================================

if CURRENT_DATE=last_day(CURRENT_DATE) THEN 

   delete from reporting.Login_main_monthly
    where mis_date=current_date;

    insert into Reporting.Login_main_monthly
    Select * from Reporting.Login_main_daily where mis_date=current_date;
    END IF;
END;
$$
