CREATE OR REPLACE PROCEDURE los.sp_mis_variables()
 LANGUAGE plpgsql
AS $_$
BEGIN
DELETE FROM los.mis_variables WHERE applicant_id in 
(Select applicant_id from los_stg.mis_variables);
	
insert into  los.mis_variables (
    applicant_id ,
    sz_application_no ,
    customer_id ,
    branch_cd ,
    cro_code ,
    vcp_id ,
    vcp_name  ,
    gender,
    dt_birth_dte,
    age,
    sz_marital_status,
    sz_eduction_level,
    mobile_no,
    loan_amount,
    appliedamount,
    eb_outstanding_amt,
    i_tenor,
    collateraloneid,
    collateraltwoid,
    f_interest_rate,
    application_fee,
    fee_payment_status,
    creation_dt,
    sanctioned_amt,
    i_dsb_srno,
    disbursed_amt,
    primary_livelihood,
    total_income,
    f_total_val,
    cibil_score ,
    property_type  ,
    sectors,
    sub_sectors,
    login_status,
    customer_type_sourcing,
    customer_name,
    eb_closure_amt_mtd,
    final_disb_flag,
    tenor_finalloan_period,
    f_actual_emi,
    branch_product,
    current_step_name,
    existing_customer,
    facility_type,
    product,
    max_loan_amount,
    dsr_value,
    roi,
    emi,
    assesment_method_policy,
    final_emi_amount,
    limit_requested,
    limit_proposed,
    ro1,
    tenor,
    dsr,
    current_obligations,
    customer_comfortable_emi,
    asset_created_within_4_years,
    no_of_collaterals_offered,
    sampatti_end_use ,
    occupancy_type ,
    collateral_scheme ,
    fair_makret_value,
    assesment_method,
    net_profit_considered,
    additional_income,
    total_net_income,
    max_eligible_emi,
    proposed_limit,
    product_cap,
    collateral_cap,
    cfa,
    comfortable_emi,
    sampatti_margin,
    maximum_loan_which_can_be_approved_to_the_customer,
    actual_dsr,
    actual_ltv,
    tenor_in_months,
    assessment_method_considerd,
    product_considered,
    sampatti_margin_calculation,
    final_loan_amount,
    final_emi,
    loan_period,
    rate,
    rcu_final_status,
    rcu_kyc_status,
    dedupe_status,
    limitdataentry,
    product_selected_is_sampatti,
    branch_tier,
    rate_card,
    branchcro,
    roitierone,
    roitiertwo,
    roitierthree,
    property_type_2,
    roi_sampatti,
    temporary_business,
    difference_in_roi_approval,
    deviation_level,
    processing_fee_excluding_gst_standard_amount,
    processing_fee_amount,
    collection_type,
    waived_processing_fee,
    processing_fee_collected_amount_incl_gst,
    enter_the_actual_waiver,
    documentation_fee_excl_gst_standard_amount ,
    documentation_fee_incl_gst_collected_amount,
    legal_and_valuation_fee,
    insurance_amount_collected_kotak,
    insurance_amount_collected_icici,
    salutation,
    addresslineone,
    addresslinetwo,
    city,
    state,
    pincode,
    propertyaddressone,
    propertyaddresstwo,
    propertycity,
    propertystate,
    propertypincode,
    nomineename ,
    relationship,
    sz_pan ,
    roi_difference,
    finalroi,
    region,
    split_loan,
    flow_name,
    created_datetime,
    modified_datetime,
    rejection_reason,
    sz_oldlan,
    tranche_amount_3,
    tranche_amount_2,
    tranche_amount_1,
    actual_roi,
    Legal_report_Received,
    Legal_Report_Date,
    Final_Recommendation
    
)
SELECT 
    CAST(applicant_id  AS VARCHAR(20)),
    CAST(sz_application_no AS VARCHAR(20)),
    CAST(customer_id AS VARCHAR(20)),
    CAST(branch_cd AS VARCHAR(20)),
    CAST(cro_code AS VARCHAR(20)),
    CAST(vcp_id AS VARCHAR(20)),
    CAST(vcp_name AS VARCHAR(250)),
    CAST(gender AS VARCHAR(50)), 	
	CASE WHEN dt_birth_dte = '' or dt_birth_dte=' ' OR  dt_birth_dte  IS NULL or len(dt_birth_dte) !=10 THEN DATE '1971/01/01'
    ELSE TO_DATE(dt_birth_dte, 'YYYY/MM/DD') END AS dt_birth_dte,
    -- case when age like ' ' or age like '' or age  is null then cast(0 as int)
    -- ELSE cast(age as INTEGER)  END,
    case when age like ' ' or age like '' or age  is null then cast(0 as int)
    ELSE cast(age AS NUMERIC(18, 2))  END ,
       CAST(sz_marital_status AS VARCHAR(100)),
    CAST(sz_eduction_level AS VARCHAR(100)),
    CAST(mobile_no AS VARCHAR(50)),   
    case when loan_amount like ' ' or loan_amount like '' or loan_amount  is null then cast(0 as int)
    ELSE cast(loan_amount as NUMERIC(18, 2))  END,
    case when appliedamount like ' ' or appliedamount like '' or appliedamount  is null then cast(0 as int)
    ELSE cast(appliedamount as NUMERIC(18, 2))  END, 
	case when eb_outstanding_amt like ' ' or eb_outstanding_amt like '' or eb_outstanding_amt  is null then cast(0 as int)
    ELSE cast(eb_outstanding_amt as NUMERIC(18, 2))  END ,  
    -- case when i_tenor like ' ' or i_tenor like '' or i_tenor  is null then cast(0 as int)
    -- ELSE cast(i_tenor as NUMERIC(18, 2))  END,
    case when i_tenor like ' ' or i_tenor like '' or i_tenor  is null then cast(0 as int)
    ELSE cast(i_tenor AS NUMERIC(18, 2))  END ,
    CAST(collateraloneid AS VARCHAR(150)),
    CAST(collateraltwoid AS VARCHAR(150)),    
    case when f_interest_rate like ' ' or f_interest_rate like '' or f_interest_rate  is null then cast(0 as int)
    ELSE cast(f_interest_rate as NUMERIC(18, 2))  END, 
    case when application_fee like ' ' or application_fee like '' or application_fee  is null then cast(0 as int)
    ELSE cast(application_fee as NUMERIC(18, 2))  END, 
    CAST(fee_payment_status AS VARCHAR(150)),
    CASE WHEN creation_dt = '' OR creation_dt= ' ' OR creation_dt IS NULL THEN DATE '1971/01/01'
    ELSE TO_DATE(creation_dt, 'YYYY/MM/DD') END AS creation_dt,
    case when sanctioned_amt like ' ' or sanctioned_amt like '' or sanctioned_amt  is null then cast(0 as int)
    ELSE cast(sanctioned_amt as NUMERIC(18, 2))  END,
	-- case when i_dsb_srno like ' ' or i_dsb_srno like '' or i_dsb_srno  is null then cast(0 as int)
    -- ELSE cast(i_dsb_srno as int)  END,
    case when i_dsb_srno like ' ' or i_dsb_srno like '' or i_dsb_srno  is null then cast(0 as int)
    ELSE CAST(i_dsb_srno AS NUMERIC(18, 2))  END , 
    case when disbursed_amt like ' ' or disbursed_amt like '' or disbursed_amt  is null then cast(0 as int)
    ELSE cast(disbursed_amt as NUMERIC(18, 2))  END, 
    cast(primary_livelihood AS VARCHAR(600)),
    case when total_income like ' ' or total_income like '' or total_income  is null then cast(0 as int)
    ELSE cast(total_income as NUMERIC(18, 2))  END, 
    case when f_total_val like ' ' or f_total_val like '' or f_total_val  is null then cast(0 as int)
    ELSE cast(f_total_val as NUMERIC(18, 2))  END,    
    CAST(cibil_score AS VARCHAR(20)),
    CAST(property_type AS VARCHAR(250)),
    CAST(sectors AS VARCHAR(500)),
    CAST(sub_sectors AS VARCHAR(700)),
    CAST(login_status AS VARCHAR(100)),
    CAST(customer_type_sourcing AS VARCHAR(100)),
    CAST(customer_name AS VARCHAR(200)),
    case when eb_closure_amt_mtd like ' ' or eb_closure_amt_mtd like '' or eb_closure_amt_mtd  is null then cast(0 as int)
    ELSE cast(eb_closure_amt_mtd as NUMERIC(18, 2))  END, 
	CAST(final_disb_flag AS VARCHAR(1010)),
    -- case when tenor_finalloan_period like ' ' or tenor_finalloan_period like '' or tenor_finalloan_period  is null then cast(0 as int)
    -- ELSE cast(tenor_finalloan_period as NUMERIC(18, 2))  END, 
     case when tenor_finalloan_period like ' ' or tenor_finalloan_period like '' or tenor_finalloan_period  is null then cast(0 as int)
    ELSE CAST(tenor_finalloan_period AS NUMERIC(18, 2))  END , 
    case when f_actual_emi like ' ' or f_actual_emi like '' or f_actual_emi  is null then cast(0 as int)
    ELSE cast(f_actual_emi as NUMERIC(18, 2))  END, 
    CAST(branch_product AS VARCHAR(100)),
    CAST(current_step_name AS VARCHAR(300)),
    CAST(existing_customer AS VARCHAR(100)),
    CAST(facility_type AS VARCHAR(100)),
    CAST(product AS VARCHAR(100)),
    case when max_loan_amount like ' ' or max_loan_amount like '' or max_loan_amount  is null then cast(0 as int)
    ELSE cast(max_loan_amount as NUMERIC(18, 2))  END, 
    case when dsr_value like ' ' or dsr_value like '' or dsr_value  is null then cast(0 as int)
    ELSE cast(dsr_value as NUMERIC(18, 2))  END, 
    case when roi like ' ' or roi like '' or roi  is null then cast(0 as numeric(18,2))
    ELSE cast(roi as NUMERIC(18, 2))  END, 
    case when emi like ' ' or emi like '' or emi  is null then cast(0 as int)
    ELSE cast(emi as NUMERIC(18, 2))  END,     
    CAST(assesment_method_policy AS VARCHAR(500)),    
    case when final_emi_amount like ' ' or final_emi_amount like '' or final_emi_amount  is null then cast(0 as int)
    ELSE cast(final_emi_amount as NUMERIC(18, 2))  END,       
    case when limit_requested like ' ' or limit_requested like '' or limit_requested  is null then cast(0 as int)
    ELSE cast(limit_requested as NUMERIC(18, 2))  END,       
    case when limit_proposed like ' ' or limit_proposed like '' or limit_proposed  is null then cast(0 as int)
    ELSE cast(limit_proposed as NUMERIC(18, 2))  END,       
    case when ro1 like ' ' or ro1 like '' or ro1  is null then cast(0 as int)
    ELSE cast(ro1 as NUMERIC(18, 2))  END,       
    -- case when tenor like ' ' or tenor like '' or tenor  is null then cast(0 as int)
    -- ELSE cast(tenor as INTEGER)  END,
    case when tenor like ' ' or tenor like '' or tenor  is null then cast(0 as int)
    ELSE CAST(tenor AS NUMERIC(18, 2))  END ,    
    case when dsr like ' ' or dsr like '' or dsr  is null then cast(0 as int)
    ELSE cast(dsr as NUMERIC(18, 2))  END,       
    case when current_obligations like ' ' or current_obligations like '' or current_obligations  is null then cast(0 as int)
    ELSE cast(current_obligations as NUMERIC(18, 2))  END,       
    case when customer_comfortable_emi like ' ' or customer_comfortable_emi like '' or customer_comfortable_emi  is null then cast(0 as int)
    ELSE cast(customer_comfortable_emi as NUMERIC(18, 2))  END,       
    CAST(asset_created_within_4_years AS VARCHAR(150)),
    CAST(no_of_collaterals_offered AS VARCHAR(100)),
    CAST(sampatti_end_use AS VARCHAR(400)),
    CAST(occupancy_type AS VARCHAR(400)),
    CAST(collateral_scheme AS VARCHAR(400)),  
    case when fair_makret_value like ' ' or fair_makret_value like '' or fair_makret_value  is null then cast(0 as int)
    ELSE cast(fair_makret_value as NUMERIC(18, 2))  END,      
    CAST(assesment_method AS VARCHAR(500)),
    case when net_profit_considered like ' ' or net_profit_considered like '' or net_profit_considered  is null then cast(0 as int)
    ELSE cast(net_profit_considered as NUMERIC(18, 2))  END,       
    case when additional_income like ' ' or additional_income like '' or additional_income  is null then cast(0 as int)
    ELSE cast(additional_income as NUMERIC(18, 2))  END,      
    case when total_net_income like ' ' or total_net_income like '' or total_net_income  is null then cast(0 as int)
    ELSE cast(total_net_income as NUMERIC(18, 2))  END,       
    case when max_eligible_emi like ' ' or max_eligible_emi like '' or max_eligible_emi  is null then cast(0 as int)
    ELSE cast(max_eligible_emi as NUMERIC(18, 2))  END,     
    case when proposed_limit like ' ' or proposed_limit like '' or proposed_limit  is null then cast(0 as int)
    ELSE cast(proposed_limit as NUMERIC(18, 2))  END,       
    case when product_cap like ' ' or product_cap like '' or product_cap  is null then cast(0 as int)
    ELSE cast(product_cap as NUMERIC(18, 2))  END,       
    case when collateral_cap like ' ' or collateral_cap like '' or collateral_cap  is null then cast(0 as int)
    ELSE cast(collateral_cap as NUMERIC(18, 2))  END,      
    case when cfa like ' ' or cfa like '' or cfa  is null then cast(0 as int)
    ELSE cast(cfa as NUMERIC(18, 2))  END,     
    case when comfortable_emi like ' ' or comfortable_emi like '' or comfortable_emi  is null then cast(0 as int)
    ELSE cast(comfortable_emi as NUMERIC(18, 2))  END,       
    case when sampatti_margin like ' ' or sampatti_margin like '' or sampatti_margin  is null then cast(0 as int)
    ELSE cast(sampatti_margin as NUMERIC(18, 2))  END,       
    case when maximum_loan_which_can_be_approved_to_the_customer like ' ' or maximum_loan_which_can_be_approved_to_the_customer like '' or maximum_loan_which_can_be_approved_to_the_customer  is null then cast(0 as int)
    ELSE cast(maximum_loan_which_can_be_approved_to_the_customer as NUMERIC(18, 2))  END,       
    case when actual_dsr like ' ' or actual_dsr like '' or actual_dsr  is null then cast(0 as int)
    ELSE cast(actual_dsr as NUMERIC(18, 2))  END,       
    case when actual_ltv like ' ' or actual_ltv like '' or actual_ltv  is null then cast(0 as int)
    ELSE cast(actual_ltv as NUMERIC(18, 2))  END,      
    -- case when tenor_in_months like ' ' or tenor_in_months like '' or tenor_in_months  is null then cast(0 as int)
    -- ELSE cast(tenor_in_months as INTEGER)  END, 
    case when tenor_in_months like ' ' or tenor_in_months like '' or tenor_in_months  is null then cast(0 as int)
    ELSE CAST(tenor_in_months AS NUMERIC(18, 2))  END ,   
    CAST(assessment_method_considerd AS VARCHAR(500)),
    CAST(product_considered AS VARCHAR(200)),
    case when sampatti_margin_calculation like ' ' or sampatti_margin_calculation like '' or sampatti_margin_calculation  is null then cast(0 as int)
    ELSE cast(sampatti_margin_calculation as NUMERIC(18, 2))  END,  
    case when final_loan_amount like ' ' or final_loan_amount like '' or final_loan_amount  is null then cast(0 as int)
    ELSE cast(final_loan_amount as NUMERIC(18, 2))  END,   
    case when final_emi like ' ' or final_emi like '' or final_emi  is null then cast(0 as int)
    ELSE cast(final_emi as NUMERIC(18, 2))  END,   
    -- case when loan_period like ' ' or loan_period like '' or loan_period  is null then cast(0 as int)
    -- ELSE cast(loan_period as NUMERIC(18, 2))  END, 
     case when loan_period like ' ' or loan_period like '' or loan_period  is null then cast(0 as int)
    ELSE CAST(loan_period AS NUMERIC(18, 2))  END , 
    case when rate like ' ' or rate like '' or rate  is null then cast(0 as int)
    ELSE cast(rate as NUMERIC(18, 2))  END,   
    CAST(rcu_final_status AS VARCHAR(150)),
    CAST(rcu_kyc_status AS VARCHAR(100)),
    CAST(dedupe_status AS VARCHAR(100)), 
    case when limitdataentry like ' ' or limitdataentry like '' or limitdataentry  is null then cast(0 as int)
    ELSE cast(limitdataentry as NUMERIC(18, 2))  END,  
    CAST(product_selected_is_sampatti AS VARCHAR(50)),
    CAST(branch_tier AS VARCHAR(10)),
    CAST(rate_card AS VARCHAR(10)),
    CAST(branchcro AS VARCHAR(200)),
    case when roitierone like ' ' or roitierone like '' or roitierone  is null then cast(0 as int)
    ELSE cast(roitierone as NUMERIC(18, 2))  END,  
    case when roitiertwo like ' ' or roitiertwo like '' or roitiertwo  is null then cast(0 as int)
    ELSE cast(roitiertwo as NUMERIC(18, 2))  END , 
    case when roitierthree like ' ' or roitierthree like '' or roitierthree  is null then cast(0 as int)
    ELSE cast(roitierthree as NUMERIC(18, 2))  END , 
    CAST(property_type_2 AS VARCHAR(600)),
    case when roi_sampatti like ' ' or roi_sampatti like '' or roi_sampatti  is null then cast(0 as int)
    ELSE cast(roi_sampatti as NUMERIC(18, 2))  END , 
    CAST(temporary_business AS VARCHAR(50)),  
    case when difference_in_roi_approval like ' ' or difference_in_roi_approval like '' or difference_in_roi_approval  is null then cast(0 as int)
    ELSE cast(difference_in_roi_approval as NUMERIC(18, 2))  END ,   
    CAST(deviation_level AS VARCHAR(200)),
    case when processing_fee_excluding_gst_standard_amount like ' ' or processing_fee_excluding_gst_standard_amount like '' or processing_fee_excluding_gst_standard_amount  is null then cast(0 as int)
    ELSE cast(processing_fee_excluding_gst_standard_amount as NUMERIC(18, 2))  END,    
    -- CAST(deviation_level AS VARCHAR(200)),  
    case when processing_fee_amount like ' ' or processing_fee_amount like '' or processing_fee_amount  is null then cast(0 as int)
    ELSE cast(processing_fee_amount as NUMERIC(18, 2))  END , 
    CAST(collection_type AS VARCHAR(200)),    
    case when waived_processing_fee like ' ' or waived_processing_fee like '' or waived_processing_fee  is null then cast(0 as int)
    ELSE cast(waived_processing_fee as NUMERIC(18, 2))  END , 
    case when processing_fee_collected_amount_incl_gst like ' ' or processing_fee_collected_amount_incl_gst like '' or processing_fee_collected_amount_incl_gst  is null then cast(0 as int)
    ELSE cast(processing_fee_collected_amount_incl_gst as NUMERIC(18, 2))  END ,
    case when enter_the_actual_waiver like ' ' or enter_the_actual_waiver like '' or enter_the_actual_waiver  is null then cast(0 as int)
    ELSE cast(enter_the_actual_waiver as NUMERIC(18, 2))  END,  
    -- case when documentation_fee_excl_gst_standard_amount like ' ' or documentation_fee_excl_gst_standard_amount like '' or documentation_fee_excl_gst_standard_amount  is null then cast(0 as int)
    -- ELSE cast(documentation_fee_excl_gst_standard_amount as NUMERIC(18, 2))  END ,
    case when documentation_fee_excl_gst_standard_amount like ' ' or documentation_fee_excl_gst_standard_amount like '' or documentation_fee_excl_gst_standard_amount  is null then cast(0 as int)
    ELSE CAST(documentation_fee_excl_gst_standard_amount AS NUMERIC(18, 2))  END ,  
    case when documentation_fee_incl_gst_collected_amount like ' ' or documentation_fee_incl_gst_collected_amount like '' or documentation_fee_incl_gst_collected_amount  is null then cast(0 as int)
    ELSE cast(documentation_fee_incl_gst_collected_amount as NUMERIC(18, 2))  END , 
    case when legal_and_valuation_fee like ' ' or legal_and_valuation_fee like '' or legal_and_valuation_fee  is null then cast(0 as int)
    ELSE cast(legal_and_valuation_fee as NUMERIC(18, 2))  END ,   
    case when insurance_amount_collected_kotak like ' ' or insurance_amount_collected_kotak like '' or insurance_amount_collected_kotak  is null then cast(0 as int)
    ELSE cast(insurance_amount_collected_kotak as NUMERIC(18, 2))  END , 
    case when insurance_amount_collected_icici like ' ' or insurance_amount_collected_icici like '' or insurance_amount_collected_icici  is null then cast(0 as int)
    ELSE cast(insurance_amount_collected_icici as NUMERIC(18, 2))  END , 
    CAST(salutation AS VARCHAR(30)),
    CAST(addresslineone AS VARCHAR(500)),
    CAST(addresslinetwo AS VARCHAR(500)),
    CAST(city AS VARCHAR(500)),
    CAST(state AS VARCHAR(500)),
    CAST(pincode AS VARCHAR(50)),
    CAST(propertyaddressone AS VARCHAR(500)),
    CAST(propertyaddresstwo AS VARCHAR(500)),
    CAST(propertycity AS VARCHAR(500)),
    CAST(propertystate AS VARCHAR(500)),
    CAST(propertypincode AS VARCHAR(50)),
    CAST(nomineename AS VARCHAR(250)),
    CAST(relationship AS VARCHAR(100)),
    CAST(sz_pan AS VARCHAR(20)),
    case when roi_difference like ' ' or roi_difference like '' or roi_difference  is null then cast(0 as int)
    ELSE cast(roi_difference as NUMERIC(18, 2))  END,   
    case when finalroi like ' ' or finalroi like '' or finalroi  is null then cast(0 as int)
    ELSE cast(finalroi as NUMERIC(18, 2))  END,   
    CAST(region AS VARCHAR(200)),
    CAST(split_loan AS VARCHAR(20)),
    CAST(flow_name AS VARCHAR(150)),
    CAST(created_datetime AS VARCHAR(50)),
    CAST(modified_datetime AS VARCHAR(50)),	
    cast(rejection_reason as VARCHAR(250)),
    CAST(sz_oldlan AS VARCHAR(20)),
    case when tranche_amount_3 like ' ' or tranche_amount_3 like '' or tranche_amount_3  is null then cast(0 as int)
    ELSE cast(tranche_amount_3 as NUMERIC(18, 2))  END ,	  
    case when tranche_amount_2 like ' ' or tranche_amount_2 like '' or tranche_amount_2  is null then cast(0 as int)
    ELSE cast(tranche_amount_2 as NUMERIC(18, 2))  END, 
    case when tranche_amount_1 like ' ' or tranche_amount_1 like '' or tranche_amount_1  is null then cast(0 as int)
    ELSE cast(tranche_amount_1 as NUMERIC(18, 2))  END,
    case when actual_roi like ' ' or actual_roi like '' or actual_roi  is null then cast(0 as numeric(18,2))
    ELSE cast(actual_roi as NUMERIC(18, 2))  END,
    CAST(Legal_report_Received AS VARCHAR(50)),
    CASE 
        WHEN legal_report_date ~ '^[0-9]{2}/[0-9]{2}/[0-9]{4}$' THEN TO_DATE(legal_report_date, 'MM/DD/YYYY')
        WHEN legal_report_date ~ '^[0-9]{2}-[0-9]{2}-[0-9]{4}$' THEN TO_DATE(legal_report_date, 'MM-DD-YYYY')
        WHEN legal_report_date ~ '^[0-9]{2}/[0-9]{2}/[0-9]{4}$' THEN TO_DATE(legal_report_date, 'DD/MM/YYYY')
        ELSE NULL::Date
    END AS legal_report_date,
    CAST(Final_Recommendation AS VARCHAR(50))
   
from los_stg.mis_variables;       
END;
$_$
