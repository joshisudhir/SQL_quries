CREATE OR REPLACE PROCEDURE los.sp_worklogs()
 LANGUAGE plpgsql
AS $$

BEGIN

DELETE FROM los.worklogs 
WHERE applicant_id ||'_' || step_name || '_' || action || '_' || status || '_' || start_ts in (
    Select applicant_id ||'_' || step_name || '_' || action || '_' || status || '_' || start_ts from los_stg.worklogs); 

--Insert all the records received from staging based on the incremental load 
Insert into los.worklogs
select * from los_stg.worklogs;

END;
$$
