CREATE OR REPLACE PROCEDURE los.sp_insert_delete_worklogs_dropped()
 LANGUAGE plpgsql
AS $$

BEGIN
-------------------------------------------------------------------------------------
--Created By Created On Modified by Modified On Change Type

--Sandip Sharma 15-May-2024 Null Null New stored proc created to load data in worklogs


--------------------------------------------------------------------------------------


--delete all the records first which received from incremental load in staging in case records exit in final desitnation table.

DELETE FROM los.worklogs 
WHERE 
    worklog_type = 'Dropped'
    AND applicant_id +'-'+ startts in (select applicant_id +'-'+ startts from los_stg.worklogs_rejected ); 

--Insert all the records received from staging based on the incremental load 
Insert into los.worklogs
select 
    applicant_id ,
    mod_time ,
    cre_time ,
    flow_name,
    step_name,
    startts ,
    action,
    action_description,
    status,
    user_name,
    task_name,
    eventdate,
    eventtime,
    worklog_type,
    (CURRENT_TIMESTAMP + INTERVAL '5 hours 30 minutes') AS created_datetime_edw
from los_stg.worklogs_dropped;

END;
$$
