CREATE OR REPLACE PROCEDURE lms.sp_x_bucket()
 LANGUAGE plpgsql
AS $$
BEGIN 
Delete from reporting.x_bucket
where mis_date = current_date;

Insert into reporting.x_bucket
select
a.mis_date x_mis_date,
a.branchcode ,
a.branch_name ,
a.client_name,
a.ACCOUNT_ID ,
a.sz_cro_id cro_id,
a.LOAN_AMOUNT,
a.DISB_DT,
a.dt_installment_start  INSTALLMENTSTARTDATE,
a.LOANPRODUCTTYPEID as Product_code,
a.INSTAMNT ,
a.PRINCIPAL_PAID ,
a.interest_paid,
(a.PRINCIPAL_PAID+a.interest_paid) as AMOUNT_PAID_TILL_DT,
a.OUTSTANDING_PRINCIPAL ,
a.OUST_INT ,
a.TOTAL_OUTSTANDING ,
c.TOTAL_ARREARS current_arrears,
a.TOTAL_ARREARS,
a.OVERDUE_DATE,
a.OVERDUE_DAYS,
a.no_ofinstallments_totaltenor ,
a.paid_date ,
c.paid_date current_paid_date,
a.total_Paid,
(case when c.Total_Arrears<=1 then 'Paid' when c.Total_Arrears>1 then 'Unpaid' Else NULL End) as Paid_Unpaid,
a.rbi_loan_quality_code ,
datediff(mm,a.dt_installment_start ,a.mis_date)+1 as MOB,
c.mis_date
from reporting.od_report_daily a
inner join reporting.od_report_daily b on a.ACCOUNT_ID=b.ACCOUNT_ID  and b.mis_date= last_day(add_months(CURRENT_DATE,-1))
and b.OVERDUE_DAYS=0 and b.TOTAL_ARREARS<=0
inner join reporting.od_report_daily c on a.ACCOUNT_ID=c.ACCOUNT_ID
-------------------------------------------------------------------------------------
--Created By Created On Modified by Modified On Change Type
-- the x_mis_date (alias of a.mis_date) should be 11th of the month from JUNE 2024 (prathap/sagar)
-- now it is 9 (10thmay) change it to 10(11th JUne) from JUne 2024
--------------------------------------------------------------------------------------
where a.mis_date=TO_CHAR(DATE_TRUNC('month', CURRENT_DATE) + 9, 'YYYY-mm-dd')
----date for opening X buckets accounts
and a.OVERDUE_DAYS='6' and c.mis_date=CURRENT_DATE and b.rbi_loan_quality_code not in('LOSS','DBF2','DBF1','SBSTD');


END;
$$
