CREATE OR REPLACE PROCEDURE lms.sp_night_full_load_t_cs_address_details_from_s3()
 LANGUAGE plpgsql
AS $$
BEGIN

    TRUNCATE lms.t_cs_address_details;
    COPY lms.t_cs_address_details
    FROM 's3://vistaar-lms-oracle/Every_night_full_load/T_CS_ADDRESS_DETAILS/'
    IAM_ROLE 'arn:aws:iam::975050328457:role/Redshift-Read-write-Prod'
    FORMAT AS PARQUET;

END;
$$
