CREATE OR REPLACE PROCEDURE lms.vistaar_load_actual_collection_data()
 LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO lms.mis_actual_collection ( 
    SZ_LOAN_ACCOUNT_NO,
    sz_portfolio_code,
    DT_STATUS_CHANGE,
    C_ACCOUNT_STATUS,
    total_amt_paid,
    PRN_AMT_paid,
    INT_AMT_paid,
    Fee_Tax_paid,
    Excess_paid,
    Fut_PRNT_paid,
    last_day_paid,
    Last_instal_pay,
    Max_DT_DUEDATE,
    last_pay_DT,
    mis_date) 
	
	select distinct 
    pq.SZ_LOAN_ACCOUNT_NO,
    pq.sz_portfolio_code,
    pq.DT_STATUS_CHANGE,
    pq.C_ACCOUNT_STATUS,
    pp.total_amt_paid,
    pp.PRN_AMT_paid,
    pp.INT_AMT_paid,
    pp.Fee_Tax_paid,
    pp.Excess_paid,
    pp.Fut_PRNT_paid,
    pp.last_day_paid,
    pp.Last_instal_pay,
    pp.Max_DT_DUEDATE,
    pp.last_pay_DT,
    TO_CHAR(SYSDATE - INTERVAL '24 Hour','DD-MM-YYYY') as mis_date
FROM
    lms.T_LMS_LOAN_ACCOUNT pq
LEFT JOIN
    (
        SELECT
            x1.*,
            x2.PRN_AMT_paid,
            x3.INT_AMT_paid,
            x4.Fee_Tax_paid,
            x5.Excess_paid,
            x6.Fut_PRNT_paid,
            x7.last_day_paid
        FROM
            (
                SELECT
                    a.SZ_LOAN_ACCOUNT_NO,
                    MAX(b.I_reference_no) AS Last_instal_pay,
                    MAX(b.DT_DUEDATE) AS Max_DT_DUEDATE,
                    SUM(b.F_AMOUNT) AS total_amt_paid,
                    MAX(b.DT_PAYMENT) AS last_pay_DT
                FROM
                    lms.T_LMS_PAYMENT_HEADER a
                INNER JOIN lms.T_LMS_PAYMENT_DTLS b ON a.I_TRAN_ID=b.I_TRAN_ID
                                                              AND a.I_PAYMENT_SRNO=b.I_PAYMENT_SRNO
                                                              AND b.DT_PAYMENT BETWEEN '01-Feb-2024' AND '29-Feb-2024'
                INNER JOIN lms.t_lms_instruments i ON i.i_tran_id=a.i_tran_id
                                                            AND i.SZ_INST_STATUS='CLR'
                GROUP BY
                    a.SZ_LOAN_ACCOUNT_NO
            ) x1
        LEFT JOIN
            (
                SELECT
                    b.SZ_LOAN_ACCOUNT_NO,
                    SUM(a.F_AMOUNT) AS PRN_AMT_paid
                FROM
                    lms.T_LMS_PAYMENT_DTLS a
                INNER JOIN lms.T_LMS_PAYMENT_HEADER b ON a.I_TRAN_ID=b.I_TRAN_ID
                                                                  AND a.I_PAYMENT_SRNO=b.I_PAYMENT_SRNO
                                                                  AND a.DT_PAYMENT BETWEEN '01-Feb-2024' AND '29-Feb-2024'
                                                                  AND a.sz_Trantype='INSTALLMENT'
                                                                  AND a.SZ_TRANHEAD='PRN_AMT'
                INNER JOIN lms.t_lms_instruments i ON i.i_tran_id=b.i_tran_id
                                                            AND i.SZ_INST_STATUS='CLR'
                GROUP BY
                    b.SZ_LOAN_ACCOUNT_NO
            ) x2 ON x1.SZ_LOAN_ACCOUNT_NO=x2.SZ_LOAN_ACCOUNT_NO
        LEFT JOIN
            (
                SELECT
                    b.SZ_LOAN_ACCOUNT_NO,
                    SUM(a.F_AMOUNT) AS INT_AMT_paid
                FROM
                    lms.T_LMS_PAYMENT_DTLS a
                INNER JOIN lms.T_LMS_PAYMENT_HEADER b ON a.I_TRAN_ID=b.I_TRAN_ID
                                                                  AND a.I_PAYMENT_SRNO=b.I_PAYMENT_SRNO
                                                                  AND a.DT_PAYMENT BETWEEN '01-Feb-2024' AND '29-Feb-2024'
                                                                  AND a.sz_Trantype='INSTALLMENT'
                                                                  AND a.SZ_TRANHEAD='INT_AMT'
                INNER JOIN lms.t_lms_instruments i ON i.i_tran_id=a.i_tran_id
                                                              AND i.SZ_INST_STATUS='CLR'
                GROUP BY
                    b.SZ_LOAN_ACCOUNT_NO
            ) x3 ON x1.SZ_LOAN_ACCOUNT_NO=x3.SZ_LOAN_ACCOUNT_NO
        LEFT JOIN
            (
                SELECT
                    b.SZ_LOAN_ACCOUNT_NO,
                    SUM(a.F_AMOUNT) AS Fee_Tax_paid
                FROM
                    lms.T_LMS_PAYMENT_DTLS a
                INNER JOIN lms.T_LMS_PAYMENT_HEADER b ON a.I_TRAN_ID=b.I_TRAN_ID
                                                                  AND a.I_PAYMENT_SRNO=b.I_PAYMENT_SRNO
                                                                  AND a.DT_PAYMENT BETWEEN '01-Feb-2024' AND '29-Feb-2024'
                                                                  AND a.sz_Trantype IN ('FEE','TAX')
                INNER JOIN lms.t_lms_instruments i ON i.i_tran_id=a.i_tran_id
                                                              AND i.SZ_INST_STATUS='CLR'
                GROUP BY
                    b.SZ_LOAN_ACCOUNT_NO
            ) x4 ON x1.SZ_LOAN_ACCOUNT_NO=x4.SZ_LOAN_ACCOUNT_NO
        LEFT JOIN
            (
                SELECT
                    b.SZ_LOAN_ACCOUNT_NO,
                    SUM(a.F_AMOUNT) AS Excess_paid
                FROM
                    lms.T_LMS_PAYMENT_DTLS a
                INNER JOIN lms.T_LMS_PAYMENT_HEADER b ON a.I_TRAN_ID=b.I_TRAN_ID
                                                                  AND a.I_PAYMENT_SRNO=b.I_PAYMENT_SRNO
                                                                  AND a.DT_PAYMENT BETWEEN '01-Feb-2024' AND '29-Feb-2024'
                                                                  AND a.sz_Trantype='EXCESS'
                INNER JOIN lms.t_lms_instruments i ON i.i_tran_id=a.i_tran_id
                                                              AND i.SZ_INST_STATUS='CLR'
                GROUP BY
                    b.SZ_LOAN_ACCOUNT_NO
            ) x5 ON x1.SZ_LOAN_ACCOUNT_NO=x5.SZ_LOAN_ACCOUNT_NO
        LEFT JOIN
            (
                SELECT
                    b.SZ_LOAN_ACCOUNT_NO,
                    SUM(a.F_AMOUNT) AS Fut_PRNT_paid
                FROM
                    lms.T_LMS_PAYMENT_DTLS a
                INNER JOIN lms.T_LMS_PAYMENT_HEADER b ON a.I_TRAN_ID=b.I_TRAN_ID
                                                                  AND a.I_PAYMENT_SRNO=b.I_PAYMENT_SRNO
                                                                  AND a.DT_PAYMENT BETWEEN '01-Feb-2024' AND '29-Feb-2024'
                                                                  AND a.sz_Trantype='LOAN_AMOUNT'
                INNER JOIN lms.t_lms_instruments i ON i.i_tran_id=a.i_tran_id
                                                              AND i.SZ_INST_STATUS='CLR'
                GROUP BY
                    b.SZ_LOAN_ACCOUNT_NO
            ) x6 ON x1.SZ_LOAN_ACCOUNT_NO=x6.SZ_LOAN_ACCOUNT_NO
        LEFT JOIN
            (
                SELECT
                    b.SZ_LOAN_ACCOUNT_NO,
                    SUM(a.F_AMOUNT) AS last_day_paid
                FROM
                    lms.T_LMS_PAYMENT_DTLS a
                INNER JOIN lms.T_LMS_PAYMENT_HEADER b ON a.I_TRAN_ID=b.I_TRAN_ID
                                                                  AND a.I_PAYMENT_SRNO=b.I_PAYMENT_SRNO
                                                                  AND a.DT_PAYMENT='29-Feb-2024'
                INNER JOIN lms.t_lms_instruments i ON i.i_tran_id=a.i_tran_id
                                                              AND i.SZ_INST_STATUS='CLR'
                GROUP BY
                    b.SZ_LOAN_ACCOUNT_NO
            ) x7 ON x1.SZ_LOAN_ACCOUNT_NO=x7.SZ_LOAN_ACCOUNT_NO
    ) pp ON pq.SZ_LOAN_ACCOUNT_NO=pp.SZ_LOAN_ACCOUNT_NO
WHERE
    pq.DT_STATUS_CHANGE IS NULL     OR pq.DT_STATUS_CHANGE >= '01-Feb-2024';
END;
$$
