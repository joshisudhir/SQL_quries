CREATE OR REPLACE PROCEDURE lms.od_report_dail_load()
 LANGUAGE plpgsql
AS $$
BEGIN
  -- Delete daily data for reporting.od_report_daily
  DELETE FROM reporting.od_report_daily
  WHERE mis_date = current_date;

  -- Insert filtered data into reporting.od_report_daily
  INSERT INTO reporting.od_report_daily
  SELECT * FROM lms.vw_od_report
  WHERE dup_check = 1;  -- Filter based on dup_check flag
--====================================================================================================================
--to get r=preious month pause DPD , arears,Bucket We are performing below Update operatio

  UPDATE reporting.od_report_daily 
  SET previous_month_end_oddays = p.overdue_days,
      previous_month_end_pos = p.outstanding_principal,
      previous_month_end_total_arrears = p.total_arrears
  FROM reporting.od_report_daily q
  JOIN (select account_id,overdue_days,outstanding_principal,total_arrears,mis_date from reporting.od_report_daily WHERE mis_date = last_day(add_months(current_date::date::timestamp without time zone, -1)) ) 
  p on q.account_id=p.account_id
  WHERE q.mis_date = current_date;
  
  --------------------------
  update reporting.od_report_daily
  set write_off = case when a.account_id = b.account_id then 'Y' else 'N' end
  from reporting.od_report_daily a
  join (
    select account_id
    from reporting.manual_writeoff
    where writeoff_date = '2024-03-31'
    ) b on a.account_id = b.account_id
  where a.mis_date = current_date;
---------------------------------------------------------
  UPDATE reporting.od_report_daily 
  SET current_bucket = (case
   when ((previous_month_end_oddays <=0 or previous_month_end_oddays is null) or (previous_month_end_total_arrears <=1 or previous_month_end_total_arrears is null)) 
                            and (overdue_days>=0 AND total_arrears >1) THEN '6'
                 when overdue_days between 1 AND 30  then '1' 
                            when overdue_days between 31 AND 60  then '2'
                            when overdue_days between 61 AND 90  then '3'
                            when overdue_days >90  then '4'
                            Else '9999'  END ),
      previous_month_end_bucket =(case when overdue_days between 1 AND 30  then '1' 
                              when overdue_days between 31 AND 60  then '2'
                              when overdue_days between 61 AND 90  then '3'
                              when overdue_days >90  then '4'
                              Else '9999'  END ),
      mob= datediff('Month',dt_installment_start,mis_date)+1,
      dummy_dpd= previous_month_end_oddays+EXTRACT(DAY FROM current_date) 
  FROM reporting.od_report_daily where mis_date=current_date;
  ----------------------------------------------
  --As below first update is still returing null We are manuallyupdating again 
  UPDATE reporting.od_report_daily 
SET opening_x_bucket= case when odd.account_id=sodd.account_id then 'Y'
        Else 'N' END   
from reporting.od_report_daily odd
join 
(Select distinct a.account_id
FROM
    reporting.od_report_daily a
    JOIN reporting.od_report_daily b ON a.account_id:: text = b.account_id:: text
    AND b.mis_date = last_day(
        add_months(
            'now':: character varying:: date:: timestamp without time zone,
            - 1:: bigint
        )
    )
    AND b.total_arrears <= 1:: numeric:: numeric(18, 0):: numeric(18, 2)
WHERE
    a.mis_date:: character varying:: text = to_char(
        date_trunc(
            'month':: character varying:: text,
            'now':: character varying:: date:: timestamp without time zone
        ) + 9:: bigint,
        'YYYY-mm-dd':: character varying:: text
    )
    AND a.total_arrears > 1:: numeric:: numeric(18, 2)
    AND b.rbi_loan_quality_code:: text <> 'LOSS':: character varying:: text
    AND b.rbi_loan_quality_code:: text <> 'DBF2':: character varying:: text
    AND b.rbi_loan_quality_code:: text <> 'DBF1':: character varying:: text
    AND b.rbi_loan_quality_code:: text <> 'SBSTD':: character varying:: text) sodd
	on odd.account_id=sodd.account_id 
	Where odd.mis_date = CURRENT_DATE;
UPDATE reporting.od_report_daily 
SET opening_x_bucket= CAse when opening_x_bucket is null then 'N' Else opening_x_bucket end 
where mis_date=current_date ;

  --====================================================================================================================
  -- Delete daily data for reporting.bkt_collections
  DELETE FROM reporting.bkt_collections
  WHERE mis_date = current_date;

  -- Insert data with additional columns from lms.vw_actual_collection
  INSERT INTO reporting.bkt_collections
  SELECT 	branchcode,	branch_name,	customer_no,	client_name,	account_id,	sz_cro_id,	loan_amount,	disb_dt,	
  loanproducttypeid,	instamnt,	paid_date,	no_ofinstallments_totaltenor,	total_arrears,	outstanding_principal,	
  opening_dpd,	opening_bucket,	current_arrears,	current_pos,	current_dpd,	current_paiddate,	loan_status,	
  current_bkt,	status,	sub_status,	monthend_dt,	mis_date,	write_off,	rbi_loan_quality_code,  
  ac.total_amt_paid, ac.last_day_paid,	payment_mode,PAYMENT_STATUS_CODE
  FROM reporting.vw_bkt_collections vc
  LEFT JOIN "lms"."vw_actual_collection" ac ON vc.account_id = ac.sz_loan_account_no;

  -- Delete daily data for reporting.x_bucket
  DELETE FROM reporting.x_bucket
  WHERE mis_date = current_date;

  -- Insert data into reporting.x_bucket
  INSERT INTO reporting.x_bucket
  SELECT * FROM reporting.vw_x_bucket;

  --====================inserting snapsot data to repayment_daily===============
  delete from reporting.repayment_daily
    where mis_date=current_date;

    insert into reporting.repayment_daily
    Select * from lms.vw_daily_repayment;
-- =================================MONTHLY DATA LOAD ================================

if CURRENT_DATE=last_day(CURRENT_DATE) THEN 

    -------------------------repayment_monthly--------------------------
    delete from reporting.repayment_monthly
    where mis_date=current_date;

    insert into reporting.repayment_monthly
    SELECT * FROM reporting.repayment_daily where mis_date=current_date;
    -------------------------od_report_monthly--------------------------
    DELETE FROM reporting.od_report_monthly
    WHERE mis_date = current_date;

    INSERT INTO reporting.od_report_monthly
    SELECT * FROM reporting.od_report_daily where mis_date=current_date
    AND dup_check = 1;
    -------------------------x_bucket_monthly--------------------------
    DELETE FROM reporting.x_bucket_monthly
    WHERE mis_date = current_date;

    INSERT INTO reporting.x_bucket_monthly
    SELECT * FROM reporting.x_bucket where mis_date=current_date;

    -------------------------bkt_collections_monthly--------------------------
    DELETE FROM reporting.bkt_collections_monthly
    WHERE mis_date = current_date;

    INSERT INTO reporting.bkt_collections_monthly
    SELECT * FROM reporting.bkt_collections where mis_date=current_date;

    
END IF;

END;
$$
