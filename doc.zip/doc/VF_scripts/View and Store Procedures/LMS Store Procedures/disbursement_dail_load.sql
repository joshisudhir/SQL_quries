CREATE OR REPLACE PROCEDURE lms.disbursement_dail_load()
 LANGUAGE plpgsql
AS $$
BEGIN
    delete from reporting.disbursement_daily
    where mis_date=current_date;

    insert into reporting.disbursement_daily
    Select * from lms.vw_disbursement;

    if CURRENT_DATE=last_day(CURRENT_DATE) THEN 

    delete from reporting.disbursement_monthly
    where mis_date=current_date;
    insert into reporting.disbursement_monthly
    Select * from lms.vw_disbursement;
    END IF;
END;
$$
