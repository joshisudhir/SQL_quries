CREATE OR REPLACE PROCEDURE lms.login_daily_load()
 LANGUAGE plpgsql
AS $$
BEGIN
    
    delete from reporting.login_daily
    where mis_date=current_date;

    insert into reporting.login_daily
    Select * from lms.vw_login;

END;
$$
