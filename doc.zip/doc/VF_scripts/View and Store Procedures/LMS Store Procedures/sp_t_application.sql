CREATE OR REPLACE PROCEDURE lms.sp_t_application()
 LANGUAGE plpgsql
AS $$
BEGIN	
	DELETE FROM lms.t_application WHERE sz_application_no in 
	(Select sz_application_no from lms_stg.t_application);

    INSERT INTO lms.t_application
    SELECT * FROM lms_stg.t_application;
   
END;
$$
