CREATE OR REPLACE PROCEDURE lms.vistaar_load_charges_data()
 LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO mis_charges(sz_loan_account_no, dt_chg_booked, charges_amt, waived_amt, to_be_collected, collected_amt, mis_date)
    SELECT
        x.sz_loan_account_no,
        x.dt_chg_booked,
        x.charges_amt,
        COALESCE(x.waived_amt, 0::numeric) AS waived_amt,
        (x.charges_amt - COALESCE(x.waived_amt, 0::numeric)) * 1.18 AS to_be_collected,
        COALESCE(y.charges_paid, 0::numeric) AS collected_amt,
        TO_CHAR(CURRENT_DATE - INTERVAL '1 day', 'YYYY-MM-DD') AS mis_date
    FROM
        (
            SELECT
                a.sz_loan_account_no,
                MAX(a.dt_chg_booked) AS dt_chg_booked,
                SUM(a.f_amount) AS charges_amt,
                SUM(b.f_waived_amt) AS waived_amt
            FROM
                lms.t_lms_chg_booking_dtls a
            LEFT JOIN
                lms.t_lms_chg_waiver_dtls b ON a.sz_loan_account_no::TEXT = b.sz_loan_account_no::TEXT
                AND a.i_chgbooktran_id = b.i_chgbooktran_id
            WHERE
                (
                    a.sz_tranhead::TEXT = 'LATEPAY_LD'::TEXT
                    OR a.sz_tranhead::TEXT = 'FCC_CH'::TEXT
                    OR a.sz_tranhead::TEXT = 'BNC_CH'::TEXT
                )
                AND a.dt_chg_booked >= CURRENT_DATE - INTERVAL '24 Hour'
                GROUP BY a.sz_loan_account_no
        ) x
    LEFT JOIN
        (
            SELECT
                b.sz_loan_account_no,
                SUM(a.f_amount) AS charges_paid
            FROM
                lms.t_lms_payment_dtls a
            JOIN
                lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                AND a.i_payment_srno = b.i_payment_srno
                AND a.dt_payment >= CURRENT_DATE - INTERVAL '24 Hour'
                AND a.dt_payment < CURRENT_DATE::DATE
                AND (
                    a.sz_trantype::TEXT = 'FEE'::TEXT
                    OR a.sz_trantype::TEXT = 'TAX'::TEXT
                )
                AND b.sz_payment_purpose::TEXT = 'NORMAL_PAYMENT'::TEXT
            JOIN
                lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                AND i.sz_inst_status::TEXT = 'CLR'::TEXT
            GROUP BY
                b.sz_loan_account_no
        ) y ON x.sz_loan_account_no::TEXT = y.sz_loan_account_no::TEXT;
END;
$$
