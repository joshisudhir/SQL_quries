CREATE OR REPLACE PROCEDURE lms.sp_t_lms_repay_schedule()
 LANGUAGE plpgsql
AS $$
Begin 
     Delete from lms.t_lms_repay_schedule where sz_loan_account_no || '_' || i_installment_no in 
    (select sz_loan_account_no || '_' || i_installment_no from lms_stg.t_lms_repay_schedule );
		
	INSERT INTO lms.t_lms_repay_schedule
	SELECT * FROM lms_stg.t_lms_repay_schedule;

END;
$$
