CREATE
OR REPLACE VIEW "reporting"."vw_bkt_collections" AS
SELECT
    DISTINCT lsf.branchcode,
    lsf.branch_name,
    lsf.customer_no,
    lsf.client_name,
    lsf.account_id,
    lsf.sz_cro_id,
    lsf.loan_amount,
    lsf.disb_dt,
    lsf.loanproducttypeid,
    lsf.instamnt,
    lsf.paid_date,
    lsf.no_ofinstallments_totaltenor,
    lsf.total_arrears,
    lsf.outstanding_principal,
    lsf.overdue_days AS opening_dpd,
    CASE
    WHEN CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN lsf.overdue_days >= 1:: bigint
    AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN lsf.overdue_days >= 31:: bigint
    AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN lsf.overdue_days >= 61:: bigint
    AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN lsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END AS opening_bucket,
    olsf.total_arrears AS current_arrears,
    olsf.outstanding_principal AS current_pos,
    olsf.overdue_days AS current_dpd,
    CASE
    WHEN last_day(
        'now':: character varying:: date:: timestamp without time zone
    ) = last_day(olsf.paid_date:: timestamp without time zone) THEN olsf.paid_date
    ELSE NULL:: date END AS current_paiddate,
    lsf.loan_status,
    CASE
    WHEN CASE
    WHEN olsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN olsf.overdue_days >= 1:: bigint
    AND olsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN olsf.overdue_days >= 31:: bigint
    AND olsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN olsf.overdue_days >= 61:: bigint
    AND olsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN olsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END AS current_bkt,
    CASE
    WHEN CASE
    WHEN lsf.overdue_days > 0
    AND lsf.overdue_days > olsf.overdue_days
    AND lsf.loan_product_type_id:: text ! ~ ~ '%write%':: character varying:: text THEN 'Paid':: character varying
    WHEN lsf.overdue_days > 0
    AND lsf.overdue_days < olsf.overdue_days
    OR lsf.loan_product_type_id:: text ! ~ ~ '%write%':: character varying:: text THEN 'Unpaid':: character varying
    ELSE 'Paid':: character varying END:: text = 'Paid':: character varying:: text
    AND (
        CASE
        WHEN CASE
        WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
        ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
        WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
        WHEN lsf.overdue_days >= 1:: bigint
        AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
        WHEN lsf.overdue_days >= 31:: bigint
        AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
        WHEN lsf.overdue_days >= 61:: bigint
        AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
        WHEN lsf.overdue_days > 90 THEN '4':: character varying
        ELSE '9999':: character varying END:: text = '4':: character varying:: text
        OR CASE
        WHEN CASE
        WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
        ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
        WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
        OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
        WHEN lsf.overdue_days >= 1:: bigint
        AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
        WHEN lsf.overdue_days >= 31:: bigint
        AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
        WHEN lsf.overdue_days >= 61:: bigint
        AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
        WHEN lsf.overdue_days > 90 THEN '4':: character varying
        ELSE '9999':: character varying END:: text = 'Writeoff':: character varying:: text
    )
    AND olsf.overdue_days <> 0 THEN 'Unpaid':: character varying
    ELSE CASE
    WHEN lsf.overdue_days > 0
    AND lsf.overdue_days > olsf.overdue_days
    AND lsf.loan_product_type_id:: text ! ~ ~ '%write%':: character varying:: text THEN 'Paid':: character varying
    WHEN lsf.overdue_days > 0
    AND lsf.overdue_days < olsf.overdue_days
    OR lsf.loan_product_type_id:: text ! ~ ~ '%write%':: character varying:: text THEN 'Unpaid':: character varying
    ELSE 'Paid':: character varying END END AS status,
    CASE
    WHEN lsf.overdue_days > 0
    AND olsf.overdue_days <= 0
    AND lsf.loan_product_type_id:: text ! ~ ~ '%write%':: character varying:: text THEN 'Normalized':: character varying
    WHEN lsf.overdue_days > 0
    AND olsf.overdue_days < lsf.overdue_days
    AND CASE
    WHEN CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN lsf.overdue_days >= 1:: bigint
    AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN lsf.overdue_days >= 31:: bigint
    AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN lsf.overdue_days >= 61:: bigint
    AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN lsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text = CASE
    WHEN CASE
    WHEN olsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN olsf.overdue_days >= 1:: bigint
    AND olsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN olsf.overdue_days >= 31:: bigint
    AND olsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN olsf.overdue_days >= 61:: bigint
    AND olsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN olsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text
    AND CASE
    WHEN CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN lsf.overdue_days >= 1:: bigint
    AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN lsf.overdue_days >= 31:: bigint
    AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN lsf.overdue_days >= 61:: bigint
    AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN lsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text <> '4':: character varying:: text
    AND CASE
    WHEN CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN lsf.overdue_days >= 1:: bigint
    AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN lsf.overdue_days >= 31:: bigint
    AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN lsf.overdue_days >= 61:: bigint
    AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN lsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text <> 'Writeoff':: character varying:: text THEN 'Stabilized':: character varying
    WHEN olsf.overdue_days > 0
    AND olsf.overdue_days < lsf.overdue_days
    AND CASE
    WHEN CASE
    WHEN olsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN olsf.overdue_days >= 1:: bigint
    AND olsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN olsf.overdue_days >= 31:: bigint
    AND olsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN olsf.overdue_days >= 61:: bigint
    AND olsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN olsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text < CASE
    WHEN CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN lsf.overdue_days >= 1:: bigint
    AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN lsf.overdue_days >= 31:: bigint
    AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN lsf.overdue_days >= 61:: bigint
    AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN lsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text
    AND lsf.loan_product_type_id:: text ! ~ ~ '%write%':: character varying:: text
    AND CASE
    WHEN CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN lsf.overdue_days >= 1:: bigint
    AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN lsf.overdue_days >= 31:: bigint
    AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN lsf.overdue_days >= 61:: bigint
    AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN lsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text <> '4':: character varying:: text
    AND CASE
    WHEN CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END:: text = 'Y':: character varying:: text THEN 'Writeoff':: character varying
    WHEN sc1.rbi_loan_quality_code:: text = 'LOSS':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF2':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF1':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'SBSTD':: character varying:: text
    OR sc1.rbi_loan_quality_code:: text = 'DBF3':: character varying:: text THEN '4':: character varying
    WHEN lsf.overdue_days >= 1:: bigint
    AND lsf.overdue_days <= 30:: bigint THEN '1':: character varying
    WHEN lsf.overdue_days >= 31:: bigint
    AND lsf.overdue_days <= 60:: bigint THEN '2':: character varying
    WHEN lsf.overdue_days >= 61:: bigint
    AND lsf.overdue_days <= 90:: bigint THEN '3':: character varying
    WHEN lsf.overdue_days > 90 THEN '4':: character varying
    ELSE '9999':: character varying END:: text <> 'Writeoff':: character varying:: text THEN 'Rolled Back':: character varying
    WHEN lsf.overdue_days < olsf.overdue_days
    OR lsf.loan_product_type_id:: text ! ~ ~ '%write%':: character varying:: text THEN 'Forward Flow':: character varying
    ELSE 'Stabilized':: character varying END AS sub_status,
    lsf.mis_date AS monthend_dt,
    olsf.mis_date,
    CASE
    WHEN lsf.account_id:: text = wf.account_id:: text THEN 'Y':: character varying
    ELSE 'N':: character varying END AS write_off,
    lsf.rbi_loan_quality_code,
    cn.payment_mode,
    cn.payment_status_code
FROM
    reporting.od_report_daily lsf
    JOIN reporting.od_report_daily olsf ON lsf.account_id:: text = olsf.account_id:: text
    AND olsf.mis_date = 'now':: character varying:: date
    JOIN reporting.od_report_daily sc1 ON lsf.account_id:: text = sc1.account_id:: text
    AND sc1.mis_date:: character varying:: text = to_char(
        date_trunc(
            'month':: character varying:: text,
            'now':: character varying:: date:: timestamp without time zone
        ) + 4:: bigint,
        'YYYY-mm-dd':: character varying:: text
    )
    LEFT JOIN reporting.manual_writeoff wf ON lsf.account_id:: text = wf.account_id:: text
    AND wf.writeoff_date = '2024-03-31':: date
    LEFT JOIN lms.cn_collection cn ON cn.account_number:: text = lsf.account_id:: text
    AND cn.payment_date >= 'now':: text:: date
WHERE
    lsf.overdue_days > 0
    AND lsf.total_arrears > 1:: numeric:: numeric(18, 0):: numeric(18, 2)
    AND lsf.mis_date = last_day(
        add_months(
            'now':: character varying:: date:: timestamp without time zone,
            - 1:: bigint
        )
    )
    AND lsf.loan_product_type_id:: text <> 'LACR':: character varying:: text
    AND lsf.loan_product_type_id:: text <> 'SBBD':: character varying:: text;