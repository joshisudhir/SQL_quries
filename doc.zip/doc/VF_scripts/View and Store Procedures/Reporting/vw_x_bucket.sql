CREATE
OR REPLACE VIEW "reporting"."vw_x_bucket" AS
SELECT
    a.mis_date AS x_mis_date,
    a.branchcode,
    a.branch_name,
    a.client_name,
    a.account_id,
    a.sz_cro_id AS cro_id,
    a.loan_amount,
    a.disb_dt,
    a.dt_installment_start AS installmentstartdate,
    a.loanproducttypeid AS product_code,
    a.instamnt,
    a.principal_paid,
    a.interest_paid,
    a.principal_paid + a.interest_paid AS amount_paid_till_dt,
    a.outstanding_principal,
    a.oust_int,
    a.total_outstanding,
    c.total_arrears AS current_arrears,
    a.total_arrears,
    a.overdue_date,
    a.overdue_days,
    a.no_ofinstallments_totaltenor,
    a.paid_date,
    CASE
    WHEN c.total_arrears <= 1:: numeric:: numeric(18, 0):: numeric(18, 2) THEN c.paid_date
    ELSE NULL:: date END AS current_paid_date,
    a.total_paid,
    CASE
    WHEN c.total_arrears <= 1:: numeric:: numeric(18, 0):: numeric(18, 2) THEN 'Paid':: character varying
    WHEN c.total_arrears > 1:: numeric:: numeric(18, 0):: numeric(18, 2) THEN 'Unpaid':: character varying
    ELSE NULL:: character varying END AS paid_unpaid,
    a.rbi_loan_quality_code,
    date_diff(
        'month':: character varying:: text,
        a.dt_installment_start:: timestamp without time zone,
        a.mis_date:: timestamp without time zone
    ) + 1 AS mob,
    c.mis_date,
    cn.payment_mode,
    cn.payment_status_code
FROM
    reporting.od_report_daily a
    JOIN reporting.od_report_daily b ON a.account_id:: text = b.account_id:: text
    AND b.mis_date = last_day(
        add_months(
            'now':: character varying:: date:: timestamp without time zone,
            - 1:: bigint
        )
    )
    AND b.total_arrears <= 1:: numeric:: numeric(18, 0):: numeric(18, 2)
    JOIN reporting.od_report_daily c ON a.account_id:: text = c.account_id:: text
    LEFT JOIN lms.cn_collection cn ON cn.account_number:: text = a.account_id:: text
    AND cn.payment_date >= 'now':: character varying:: date
WHERE
    a.mis_date:: character varying:: text = to_char(
        date_trunc(
            'month':: character varying:: text,
            'now':: character varying:: date:: timestamp without time zone
        ) + 10:: bigint,
        'YYYY-mm-dd':: character varying:: text
    )
    AND a.total_arrears > 1:: numeric:: numeric(18, 0):: numeric(18, 2)
    AND c.mis_date = 'now':: character varying:: date
    AND b.rbi_loan_quality_code:: text <> 'LOSS':: character varying:: text
    AND b.rbi_loan_quality_code:: text <> 'DBF2':: character varying:: text
    AND b.rbi_loan_quality_code:: text <> 'DBF1':: character varying:: text
    AND b.rbi_loan_quality_code:: text <> 'SBSTD':: character varying:: text;