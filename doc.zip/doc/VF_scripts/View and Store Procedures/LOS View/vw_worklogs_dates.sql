CREATE
OR REPLACE VIEW "los"."vw_worklogs_dates" AS
SELECT
    worklogs.applicant_id,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'Lead Capture':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS creation_date,
    "max"(
        CASE
        WHEN worklogs.step_name:: text = 'Data Entry':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS application_fee_date,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'CM File Acceptance':: character varying:: text
        AND worklogs."action":: text = 'INITIATE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS submission_date,
    "max"(
        CASE
        WHEN worklogs.step_name:: text = 'CM File Acceptance':: character varying:: text
        AND worklogs."action":: text = 'INITIATE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS cmfa_max_date,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'Security Details':: character varying:: text
        AND worklogs."action":: text = 'INITIATE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS soft_approval_date,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'Negotiations':: character varying:: text
        AND worklogs."action":: text = 'INITIATE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS approval_date,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'DU 1':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS du_1,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'Disbursement':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS disb_date,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'Disbursement - Tranche 2':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS disb_tranche_2,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'Disbursement - Tranche 3':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS disb_tranche_3,
    "max"(
        CASE
        WHEN (
            worklogs.step_name:: text = ANY (
                ARRAY [ 'Lead Capture':: text,
                'Pre-Login Cibil':: text,
                'Pre-PD':: text,
                'Data Entry':: text,
                'CM File Acceptance':: text,
                'Dedupe and Negative Area Check':: text,
                'Triggers':: text,
                'CiBIL Trigger':: text,
                'RCU and Vendor Initiation':: text,
                'CM PD':: text,
                'Cash Flow Analysis':: text,
                'Create Split Loan':: text,
                'Security Details':: text,
                'Negotiations':: text,
                'DU 1':: text,
                'Fit to DU Fin':: text,
                'DU COPS':: text,
                'SH COPS':: text ]
            )
        )
        AND worklogs."action":: text = 'reject':: character varying:: text THEN worklogs.event_date
        WHEN worklogs."action":: text = 'reject':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS soft_reject_date,
    "max"(
        CASE
        WHEN (
            worklogs.step_name:: text = ANY (
                ARRAY [ 'Lead Capture':: text,
                'Pre-Login Cibil':: text,
                'Pre-PD Data Entry':: text,
                'CM File Acceptance':: text,
                'Dedupe and Negative Area Check':: text,
                'Triggers':: text,
                'CiBIL Trigger':: text,
                'RCU and Vendor Initiation':: text,
                'CM PDCash Flow Analysis':: text,
                'Create Split Loan':: text,
                'Security Details':: text,
                'Negotiations':: text,
                'DU 1':: text ]
            )
        )
        AND worklogs."action":: text = 'drop':: character varying:: text THEN worklogs.event_date
        WHEN worklogs."action":: text = 'drop':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS hard_reject_date,
    "max"(
        CASE
        WHEN worklogs.step_name:: text = 'CM PD':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS cm_pd_date,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'CiBIL Trigger':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS cibil_trigger_date,
    min(
        CASE
        WHEN (
            worklogs.step_name:: text = 'Fit to DU Fin':: character varying:: text
            OR worklogs.step_name:: text = 'Fit to DUFIN':: character varying:: text
        )
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS fit_dufin_date,
    "max"(
        CASE
        WHEN worklogs.step_name:: text = 'DU COPS':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN worklogs.event_date
        ELSE NULL:: date END:: character varying:: text
    ) AS disbursement_date,
    min(
        CASE
        WHEN worklogs.step_name:: text = 'Lead Capture':: character varying:: text
        AND worklogs."action":: text = 'COMPLETE_STEP':: character varying:: text THEN "substring"(worklogs.event_time:: text, 1, 2)
        ELSE NULL:: text END:: character varying:: text
    ) AS creation_hours
FROM
    los.worklogs worklogs
GROUP BY
    worklogs.applicant_id;