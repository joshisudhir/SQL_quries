CREATE
OR REPLACE VIEW "los"."vw_epik_login" AS
SELECT
    a.applicant_id,
    a.sz_application_no,
    a.customer_id,
    a.customer_name,
    a.branch_cd,
    a.cro_code,
    a.vcp_id,
    a.vcp_name,
    a.mobile_no,
    CASE
    WHEN a.loan_amount = 0:: numeric:: numeric(18, 0):: numeric(18, 2) THEN a.appliedamount
    ELSE a.loan_amount END AS loan_amount,
    CASE
    WHEN a.appliedamount >= 10000000:: numeric:: numeric(18, 0):: numeric(18, 2) THEN 10000000:: numeric:: numeric(18, 0)
    ELSE a.appliedamount END AS appliedamount,
    CASE
    WHEN a.appliedamount >= 10000000:: numeric:: numeric(18, 0):: numeric(18, 2) THEN 10000000:: numeric:: numeric(18, 0)
    ELSE a.appliedamount END - COALESCE(a.eb_outstanding_amt, 0:: numeric:: numeric(18, 0)) AS net_applied_amt,
    CASE
    WHEN a.loan_amount >= 10000000:: numeric:: numeric(18, 0):: numeric(18, 2) THEN 10000000:: numeric:: numeric(18, 0)
    ELSE a.loan_amount END - COALESCE(a.eb_outstanding_amt, 0:: numeric:: numeric(18, 0)) AS net_loan_amt,
    a.eb_outstanding_amt,
    a.i_tenor,
    a.f_interest_rate,
    a.application_fee,
    a.disbursed_amt,
    a.fee_payment_status,
    a.sanctioned_amt,
    a.rejection_reason,
    a.sz_oldlan,
    a.cibil_score,
    a.property_type,
    a.sectors,
    a.login_status,
    a.customer_type_sourcing,
    a.branch_product,
    a.current_step_name,
    a.existing_customer,
    a.facility_type,
    a.product,
    a.branchcro,
    a.rcu_final_status,
    a.rcu_kyc_status,
    to_date(
        b.creation_date,
        'YYYY/MM/DD':: character varying:: text
    ) AS creation_date,
    b.application_fee_date,
    CASE
    WHEN b.submission_date IS NULL
    OR b.submission_date = '':: character varying:: text THEN b.du_1
    ELSE b.submission_date END AS submission_date,
    b.cmfa_max_date,
    b.soft_approval_date,
    b.approval_date,
    b.du_1,
    b.disb_date,
    b.disb_tranche_2,
    b.disb_tranche_3,
    b.soft_reject_date,
    b.hard_reject_date,
    CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END AS rejection_date,
    CASE
    WHEN b.approval_date IS NOT NULL
    AND CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END < b.approval_date THEN 'Approved':: character varying
    WHEN b.du_1 IS NOT NULL
    AND CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END < b.du_1 THEN 'Approved':: character varying
    WHEN b.du_1 IS NOT NULL
    AND CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END IS NULL THEN 'Approved':: character varying
    WHEN b.disbursement_date IS NOT NULL
    AND CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END < b.disbursement_date THEN 'Approved':: character varying
    WHEN b.approval_date IS NOT NULL
    AND CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END IS NULL THEN 'Approved':: character varying
    WHEN CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END IS NOT NULL
    AND b.approval_date <= CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END THEN 'Rejection':: character varying
    WHEN CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END IS NOT NULL
    AND b.du_1 <= CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END THEN 'Rejection':: character varying
    WHEN CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END IS NOT NULL
    AND b.disbursement_date <= CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END THEN 'Rejection':: character varying
    WHEN b.du_1 <= CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END THEN 'Rejection':: character varying
    WHEN CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END IS NOT NULL THEN 'Rejection':: character varying
    WHEN b.soft_approval_date IS NOT NULL
    AND b.approval_date IS NULL THEN 'Pending':: character varying
    WHEN b.soft_approval_date IS NOT NULL
    AND CASE
    WHEN b.hard_reject_date IS NULL THEN b.soft_reject_date
    ELSE b.hard_reject_date END IS NULL THEN 'Pending':: character varying
    ELSE 'Pending':: character varying END AS login_status_v1,
    b.cm_pd_date,
    b.cibil_trigger_date,
    b.fit_dufin_date,
    pg_catalog.row_number() OVER(
        PARTITION BY a.mobile_no
        ORDER BY
            b.submission_date
    ) AS dup_check,
    CASE
    WHEN last_day(
        to_date(
            b.submission_date,
            'YYYY/MM/DD':: character varying:: text
        ):: timestamp without time zone
    ) = last_day(
        'now':: character varying:: date:: timestamp without time zone
    ) THEN 'N':: character varying
    WHEN (
        b.submission_date IS NULL
        OR b.submission_date = '':: character varying:: text
    )
    AND last_day(
        to_date(b.du_1, 'YYYY/MM/DD':: character varying:: text):: timestamp without time zone
    ) = last_day(
        'now':: character varying:: date:: timestamp without time zone
    ) THEN 'N':: character varying
    ELSE 'CF':: character varying END AS flag,
    '' AS cro_name,
    b.disbursement_date,
    'now':: character varying:: date AS mis_date,
    a.legal_report_received,
    a.legal_report_date,
    a.final_recommendation
FROM
    los.mis_variables a
    LEFT JOIN los.vw_worklogs_dates b ON b.applicant_id:: text = a.applicant_id:: text
WHERE
    b.submission_date IS NOT NULL
    OR b.du_1 IS NOT NULL;