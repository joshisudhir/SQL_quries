CREATE
OR REPLACE VIEW "lms"."vw_disbursement" AS
SELECT
    ap.sz_org_branch_code AS branch_code,
    b.szdescription AS branch_name,
    "cluster".szdescription AS cluster_name,
    ap.sz_loan_account_no AS lan_no,
    ap.sz_los_application_no AS db_number,
    ap.sz_customer_no,
    (
        (
            (
                COALESCE(cu.sz_fname, '':: character varying):: text || ' ':: character varying:: text
            ) || COALESCE(cu.sz_mname, '':: character varying):: text
        ) || ' ':: character varying:: text
    ) || COALESCE(cu.sz_lname, '':: character varying):: text AS customer_name,
    ap.f_sanctioned_amt,
    la.sz_product_code AS product_code,
    ap.sz_portfolio_code,
    h.i_disb_srno,
    h.dt_disbursement,
    trunc(apl.dt_creation) AS creation_date,
    CASE
    WHEN ap.sz_source:: text = 'EPIK':: character varying:: text THEN trunc(ap.dt_submission:: timestamp without time zone)
    ELSE trunc(apl.dt_submission) END AS submission_date,
    du.du1_date,
    apl.sz_dsa_code,
    ap.sz_cro_id,
    r.f_amount AS mtd_disbursements_gross,
    h.f_eb_closer_amt,
    CASE
    WHEN la.sz_product_code:: text = 'GECL':: character varying:: text
    OR la.sz_product_code:: text = 'VECL':: character varying:: text THEN COALESCE(
        r.f_amount,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    )
    ELSE r.f_amount - COALESCE(
        h.f_eb_closer_amt,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) END AS mtd_disbursements_net,
    h.sz_old_eb_lan,
    ap.sz_source,
    aa.f_curr_interestrate,
    'now':: character varying:: date AS mis_date
FROM
    lms.t_lms_disb_dtls h
    LEFT JOIN lms.t_lms_loan_account ap ON ap.sz_loan_account_no:: text = h.sz_loan_account_no:: text
    LEFT JOIN lms.t_cs_customer_details cu ON ap.sz_customer_no:: text = cu.sz_customer_no:: text
    LEFT JOIN lms.t_application apl ON h.sz_loan_account_no:: text = apl.sz_application_no:: text
    LEFT JOIN lms.t_lms_tranche_dtls aa ON aa.sz_loan_account_no:: text = ap.sz_loan_account_no:: text
    JOIN lms.base_org_mst_businessunit b ON b.szname:: text = ap.sz_org_branch_code:: text
    LEFT JOIN (
        SELECT
            wf_t_notifications_hist.sz_application_no,
            min(wf_t_notifications_hist.sz_start_time) AS du1_date
        FROM
            lms.wf_t_notifications_hist
        WHERE
            wf_t_notifications_hist.sz_activity_desc:: text = 'Loan Agreement and Doc Printing':: character varying:: text
        GROUP BY
            wf_t_notifications_hist.sz_application_no
    ) du ON h.sz_loan_account_no:: text = du.sz_application_no:: text
    JOIN lms.t_lms_product_dtls la ON la.sz_loan_account_no:: text = ap.sz_loan_account_no:: text
    JOIN lms.t_lms_tranche_disb_ref r ON r.sz_loan_account_no:: text = ap.sz_loan_account_no:: text
    AND r.i_disb_srno = h.i_disb_srno
    AND h.dt_disbursement >= (
        last_day(
            add_months(
                trunc(
                    'now':: character varying:: timestamp without time zone - 1:: bigint
                ):: timestamp without time zone,
                - 1:: bigint
            )
        ) + 1
    )
    AND h.dt_disbursement <= last_day(
        trunc(
            'now':: character varying:: timestamp without time zone - 1:: bigint
        ):: timestamp without time zone
    )
    AND h.c_cancelationflg = 'N':: bpchar
    JOIN (
        SELECT
            bu.szdescription,
            ap.sz_loan_account_no
        FROM
            lms.base_org_mst_businessunit bu
            JOIN lms.base_org_mst_businessunit bu_parent ON bu.szbusiness_unit_id:: text = bu_parent.szparent_business_unit_id:: text
            JOIN lms.t_lms_loan_account ap ON bu_parent.szname:: text = ap.sz_org_branch_code:: text
    ) "cluster" ON "cluster".sz_loan_account_no:: text = ap.sz_loan_account_no:: text
ORDER BY
    h.sz_loan_account_no;