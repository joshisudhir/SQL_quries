CREATE
OR REPLACE VIEW "lms"."vw_actual_collection" AS
SELECT
     pq.sz_loan_account_no,
     pq.sz_portfolio_code,
     pq.dt_status_change,
     pq.c_account_status,
     pp.total_amt_paid,
     pp.prn_amt_paid,
     pp.int_amt_paid,
     pp.fee_tax_paid,
     pp.excess_paid,
     pp.fut_prnt_paid,
     pp.last_day_paid,
     pp.last_instal_pay,
     pp.max_dt_duedate,
     pp.last_pay_dt
FROM
     lms.t_lms_loan_account pq
     LEFT JOIN (
          SELECT
               x1.sz_loan_account_no,
               x1.last_instal_pay,
               x1.max_dt_duedate,
               x1.total_amt_paid,
               x1.last_pay_dt,
               x2.prn_amt_paid,
               x3.int_amt_paid,
               x4.fee_tax_paid,
               x5.excess_paid,
               x6.fut_prnt_paid,
               x7.last_day_paid
          FROM
               (
                    SELECT
                         a.sz_loan_account_no,
                         "max"(b.i_reference_no:: text) AS last_instal_pay,
                         "max"(b.dt_duedate) AS max_dt_duedate,
                         sum(b.f_amount) AS total_amt_paid,
                         "max"(b.dt_payment) AS last_pay_dt
                    FROM
                         lms.t_lms_payment_header a
                         JOIN lms.t_lms_payment_dtls b ON a.i_tran_id = b.i_tran_id
                         AND a.i_payment_srno = b.i_payment_srno
                         AND b.dt_payment >= (
                              last_day(
                                   add_months(
                                        trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone,
                                        -1:: bigint
                                   )
                              ) + 1
                         )
                         AND b.dt_payment <= last_day(
                              trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone
                         )
                         JOIN lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                         AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                    GROUP BY
                         a.sz_loan_account_no
               ) x1
               LEFT JOIN (
                    SELECT
                         b.sz_loan_account_no,
                         sum(a.f_amount) AS prn_amt_paid
                    FROM
                         lms.t_lms_payment_dtls a
                         JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                         AND a.i_payment_srno = b.i_payment_srno
                         AND a.dt_payment >= (
                              last_day(
                                   add_months(
                                        trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone,
                                        -1:: bigint
                                   )
                              ) + 1
                         )
                         AND a.dt_payment <= last_day(
                              trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone
                         )
                         AND a.sz_trantype:: text = 'INSTALLMENT':: character varying:: text
                         AND a.sz_tranhead:: text = 'PRN_AMT':: character varying:: text
                         JOIN lms.t_lms_instruments i ON i.i_tran_id = b.i_tran_id
                         AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                    GROUP BY
                         b.sz_loan_account_no
               ) x2 ON x1.sz_loan_account_no:: text = x2.sz_loan_account_no:: text
               LEFT JOIN (
                    SELECT
                         b.sz_loan_account_no,
                         sum(a.f_amount) AS int_amt_paid
                    FROM
                         lms.t_lms_payment_dtls a
                         JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                         AND a.i_payment_srno = b.i_payment_srno
                         AND a.dt_payment >= (
                              last_day(
                                   add_months(
                                        trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone,
                                        -1:: bigint
                                   )
                              ) + 1
                         )
                         AND a.dt_payment <= last_day(
                              trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone
                         )
                         AND a.sz_trantype:: text = 'INSTALLMENT':: character varying:: text
                         AND a.sz_tranhead:: text = 'INT_AMT':: character varying:: text
                         JOIN lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                         AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                    GROUP BY
                         b.sz_loan_account_no
               ) x3 ON x1.sz_loan_account_no:: text = x3.sz_loan_account_no:: text
               LEFT JOIN (
                    SELECT
                         b.sz_loan_account_no,
                         sum(a.f_amount) AS fee_tax_paid
                    FROM
                         lms.t_lms_payment_dtls a
                         JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                         AND a.i_payment_srno = b.i_payment_srno
                         AND a.dt_payment >= (
                              last_day(
                                   add_months(
                                        trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone,
                                        -1:: bigint
                                   )
                              ) + 1
                         )
                         AND a.dt_payment <= last_day(
                              trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone
                         )
                         AND (
                              a.sz_trantype:: text = 'FEE':: character varying:: text
                              OR a.sz_trantype:: text = 'TAX':: character varying:: text
                         )
                         JOIN lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                         AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                    GROUP BY
                         b.sz_loan_account_no
               ) x4 ON x1.sz_loan_account_no:: text = x4.sz_loan_account_no:: text
               LEFT JOIN (
                    SELECT
                         b.sz_loan_account_no,
                         sum(a.f_amount) AS excess_paid
                    FROM
                         lms.t_lms_payment_dtls a
                         JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                         AND a.i_payment_srno = b.i_payment_srno
                         AND a.dt_payment >= (
                              last_day(
                                   add_months(
                                        trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone,
                                        -1:: bigint
                                   )
                              ) + 1
                         )
                         AND a.dt_payment <= last_day(
                              trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone
                         )
                         AND a.sz_trantype:: text = 'EXCESS':: character varying:: text
                         JOIN lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                         AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                    GROUP BY
                         b.sz_loan_account_no
               ) x5 ON x1.sz_loan_account_no:: text = x5.sz_loan_account_no:: text
               LEFT JOIN (
                    SELECT
                         b.sz_loan_account_no,
                         sum(a.f_amount) AS fut_prnt_paid
                    FROM
                         lms.t_lms_payment_dtls a
                         JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                         AND a.i_payment_srno = b.i_payment_srno
                         AND a.dt_payment >= (
                              last_day(
                                   add_months(
                                        trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone,
                                        -1:: bigint
                                   )
                              ) + 1
                         )
                         AND a.dt_payment <= last_day(
                              trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone
                         )
                         AND a.sz_trantype:: text = 'LOAN_AMOUNT':: character varying:: text
                         JOIN lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                         AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                    GROUP BY
                         b.sz_loan_account_no
               ) x6 ON x1.sz_loan_account_no:: text = x6.sz_loan_account_no:: text
               LEFT JOIN (
                    SELECT
                         b.sz_loan_account_no,
                         sum(a.f_amount) AS last_day_paid
                    FROM
                         lms.t_lms_payment_dtls a
                         JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                         AND a.i_payment_srno = b.i_payment_srno
                         AND a.dt_payment = last_day(
                              trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone
                         )
                         JOIN lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                         AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                    GROUP BY
                         b.sz_loan_account_no
               ) x7 ON x1.sz_loan_account_no:: text = x7.sz_loan_account_no:: text
     ) pp ON pq.sz_loan_account_no:: text = pp.sz_loan_account_no:: text
WHERE
     pq.dt_status_change IS NULL
     OR pq.dt_status_change >= (
          last_day(
               add_months(
                    trunc('now':: text:: timestamp without time zone - 1:: bigint):: timestamp without time zone,
                    -1:: bigint
               )
          ) + 1
     );