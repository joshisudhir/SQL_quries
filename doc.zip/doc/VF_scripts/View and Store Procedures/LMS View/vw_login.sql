CREATE
OR REPLACE VIEW "lms"."vw_login" AS
SELECT
    DISTINCT ab.branchcode,
    ab.branchname,
    ab.cluster_name,
    ab.sz_application_no,
    ab.sz_customer_no,
    ab.firstname,
    ab.lastname,
    ab.sz_product_code,
    ab.sz_portfolio_code,
    ab.loanamount,
    ab.appliedamount,
    ab.applied_amt,
    ab.eb_outstanding_amt,
    ab.sector_code,
    ab.sector,
    ab.sub_sector,
    ab.rag_rating,
    ab.aadhar_card,
    ab.openedby,
    ab.cro_name,
    ab.vcp_id,
    ab.creation_date,
    ab.submission_date,
    ab.status,
    ab.sub_status,
    ab.rejectedreason,
    ab.sz_payment_mode,
    ab.f_afee_amount,
    ab.soft_approval_dt,
    ab.approval_dt,
    ab.du1_dt,
    ab.sz_rej_code,
    ab.rejection_date,
    ab.rejection_reason,
    ab.f_sanctioned_amt,
    ab.credit_activity,
    ab.credit_description,
    ab.credit_reason,
    ab.dup_check,
    ab.prev_day_login,
    ab.prev_day_approved,
    ab.prev_day_rejected,
    ab.workdays,
    ab.tat_pending,
    ab.vsbl,
    ab.vsl,
    ab.vcp,
    ab.vvml,
    ab.login_status,
    'now':: character varying:: date AS mis_date,
    CASE
    WHEN ab.login_status:: text = 'Approved':: character varying:: text
    AND ab.du1_dt IS NULL THEN 'DU1_Pending':: character varying
    ELSE ab.login_status END AS login_status1,
    CASE
    WHEN ab.login_status:: text = 'Approved':: character varying:: text
    AND ab.du1_dt IS NULL THEN trunc(
        'now':: character varying:: timestamp without time zone - 1:: bigint
    ) - trunc(ab.approval_dt:: timestamp without time zone)
    ELSE 0 END AS du1_tat_pending,
    CASE
    WHEN ab.sz_product_code:: text ~ ~ '%PQL%':: character varying:: text
    OR ab.sz_product_code:: text ~ ~ '%PAL%':: character varying:: text THEN ab.loanamount
    ELSE ab.loanamount - COALESCE(
        ab.eb_outstanding_amt,
        '0':: character varying:: text
    ):: numeric(18, 0) END AS loanapproved_amt,
    CASE
    WHEN ab.sz_product_code:: text ~ ~ '%PQL%':: character varying:: text
    OR ab.sz_product_code:: text ~ ~ '%PAL%':: character varying:: text THEN ab.appliedamount
    ELSE ab.appliedamount - COALESCE(
        ab.eb_outstanding_amt,
        '0':: character varying:: text
    ):: numeric(18, 0) END AS netapplied_amt,
    CASE
    WHEN last_day(
        to_date(
            ab.submission_date:: text,
            'YYYY/MM/DD':: character varying:: text
        ):: timestamp without time zone
    ) = last_day(
        'now':: character varying:: date:: timestamp without time zone
    ) THEN 'N':: character varying
    ELSE 'CF':: character varying END AS flag
FROM
    (
        SELECT
            y.branchcode,
            y.branchname,
            y.cluster_name,
            y.sz_application_no,
            y.sz_customer_no,
            y.firstname,
            y.lastname,
            y.sz_product_code,
            y.sz_portfolio_code,
            y.loanamount,
            y.appliedamount,
            y.applied_amt,
            y.eb_outstanding_amt,
            y.sector_code,
            y.sector,
            y.sub_sector,
            y.rag_rating,
            y.aadhar_card,
            y.openedby,
            y.cro_name,
            y.vcp_id,
            y.creation_date,
            y.submission_date,
            y.status,
            y.sub_status,
            y.rejectedreason,
            y.sz_payment_mode,
            y.f_afee_amount,
            y.soft_approval_dt,
            y.approval_dt,
            y.du1_dt,
            y.sz_rej_code,
            y.rejection_date,
            y.rejection_reason,
            y.f_sanctioned_amt,
            y.credit_activity,
            y.credit_description,
            y.credit_reason,
            y.dup_check,
            y.prev_day_login,
            y.prev_day_approved,
            y.prev_day_rejected,
            y.workdays,
            y.tat_pending,
            y.vsbl,
            y.vsl,
            y.vcp,
            y.vvml,
            CASE
            WHEN y.rejection_date IS NOT NULL THEN 'Rejection':: character varying
            WHEN y.approval_dt IS NOT NULL THEN 'Approved':: character varying
            WHEN y.soft_approval_dt IS NOT NULL THEN 'Pending':: character varying
            ELSE 'Pending':: character varying END AS login_status
        FROM
            (
                SELECT
                    x.branchcode,
                    x.branchname,
                    x.cluster_name,
                    x.sz_application_no,
                    x.sz_customer_no,
                    x.firstname,
                    x.lastname,
                    x.sz_product_code,
                    x.sz_portfolio_code,
                    x.loanamount,
                    x.appliedamount,
                    x.applied_amt,
                    x.eb_outstanding_amt,
                    x.sector_code,
                    x.sector,
                    x.sub_sector,
                    x.rag_rating,
                    x.aadhar_card,
                    x.openedby,
                    x.cro_name,
                    x.vcp_id,
                    x.creation_date,
                    x.submission_date,
                    x.status,
                    x.sub_status,
                    x.rejectedreason,
                    x.sz_payment_mode,
                    x.f_afee_amount,
                    x.soft_approval_dt,
                    x.approval_dt,
                    x.du1_dt,
                    x.sz_rej_code,
                    x.rejection_date,
                    x.rejection_reason,
                    x.f_sanctioned_amt,
                    x.credit_activity,
                    x.credit_description,
                    x.credit_reason,
                    CASE
                    WHEN x.sz_product_code:: text ~ ~ 'SPLIT%':: character varying:: text
                    OR x.sz_product_code:: text ~ ~ 'SL%':: character varying:: text THEN pg_catalog.row_number() OVER(
                        PARTITION BY x.aadhar_card
                        ORDER BY
                            x.loanamount DESC,
                            x.submission_date DESC
                    )
                    ELSE pg_catalog.row_number() OVER(
                        PARTITION BY x.aadhar_card
                        ORDER BY
                            x.submission_date DESC
                    ) END AS dup_check,
                    CASE
                    WHEN trunc(x.submission_date:: timestamp without time zone) = trunc(
                        'now':: character varying:: timestamp without time zone - 1:: bigint
                    ) THEN 1
                    ELSE 0 END AS prev_day_login,
                    CASE
                    WHEN trunc(x.approval_dt:: timestamp without time zone) = trunc(
                        'now':: character varying:: timestamp without time zone - 1:: bigint
                    ) THEN 1
                    ELSE 0 END AS prev_day_approved,
                    CASE
                    WHEN trunc(x.rejection_date:: timestamp without time zone) = trunc(
                        'now':: character varying:: timestamp without time zone - 1:: bigint
                    ) THEN 1
                    ELSE 0 END AS prev_day_rejected,
                    CASE
                    WHEN x.approval_dt IS NULL
                    AND x.sz_rej_code IS NULL THEN (
                        trunc(
                            'now':: character varying:: timestamp without time zone - 1:: bigint
                        ) - trunc(x.submission_date:: timestamp without time zone)
                    ):: double precision - 1:: double precision * floor(
                        (
                            (
                                trunc(
                                    'now':: character varying:: timestamp without time zone - 1:: bigint
                                ) - trunc(x.submission_date:: timestamp without time zone)
                            ) / 7
                        ):: double precision
                    ) - CASE
                    WHEN sign(
                        to_char(
                            trunc(
                                'now':: character varying:: timestamp without time zone - 1:: bigint
                            ):: timestamp without time zone,
                            'D':: character varying:: text
                        ):: numeric(18, 0) - to_char(
                            trunc(x.submission_date:: timestamp without time zone):: timestamp without time zone,
                            'D':: character varying:: text
                        ):: numeric(18, 0)
                    ) = (- 1:: numeric:: numeric(18, 0))
                    OR sign(
                        to_char(
                            trunc(
                                'now':: character varying:: timestamp without time zone - 1:: bigint
                            ):: timestamp without time zone,
                            'D':: character varying:: text
                        ):: numeric(18, 0) - to_char(
                            trunc(x.submission_date:: timestamp without time zone):: timestamp without time zone,
                            'D':: character varying:: text
                        ):: numeric(18, 0)
                    ) IS NULL
                    AND -1 IS NULL THEN 1
                    ELSE 0 END:: double precision
                    ELSE 0:: double precision END AS workdays,
                    CASE
                    WHEN x.approval_dt IS NULL
                    AND x.sz_rej_code IS NULL THEN trunc(
                        'now':: character varying:: timestamp without time zone - 1:: bigint
                    ) - trunc(x.submission_date:: timestamp without time zone)
                    ELSE 0 END AS tat_pending,
                    CASE
                    WHEN x.sz_product_code:: text ~ ~ '%VSBL%':: character varying:: text THEN 1
                    ELSE 0 END AS vsbl,
                    CASE
                    WHEN x.sz_product_code:: text ~ ~ '%VSL%':: character varying:: text THEN 1
                    ELSE 0 END AS vsl,
                    CASE
                    WHEN x.vcp_id IS NOT NULL THEN 1
                    ELSE 0 END AS vcp,
                    CASE
                    WHEN x.sz_product_code:: text ~ ~ '%VVML%':: character varying:: text THEN 1
                    ELSE 0 END AS vvml
                FROM
                    (
                        SELECT
                            ta.sz_servicing_branch_code AS branchcode,
                            b.szdescription AS branchname,
                            cl_name.szdescription AS cluster_name,
                            ta.sz_application_no,
                            app.sz_customer_no,
                            ad.sz_first_name AS firstname,
                            ad.sz_last_name AS lastname,
                            ta.sz_product_code,
                            ta.sz_portfolio_code,
                            lo.f_basic_loan_amount AS loanamount,
                            lo.f_applied_loan_amount AS appliedamount,
                            CASE
                            WHEN lo.f_applied_loan_amount < lo.f_basic_loan_amount THEN lo.f_basic_loan_amount
                            ELSE lo.f_applied_loan_amount END AS applied_amt,
                            ac.eb_outstanding_amt,
                            (
                                ad.sz_primary_me_cat:: text || '-':: character varying:: text
                            ) || ad.sz_primary_me_typ:: text AS sector_code,
                            CASE
                            WHEN r.szdescription:: text ~ ~ '%Hotels%':: character varying:: text THEN 'Hotels and Restaurants':: character varying
                            WHEN r.szdescription:: text = 'Trading- Essentials':: character varying:: text THEN 'Trading - Essentials':: character varying
                            ELSE r.szdescription END AS sector,
                            s.szdescription AS sub_sector,
                            CASE
                            WHEN r.szdescription:: text = 'Power/Auto/Hand Loom':: character varying:: text
                            OR r.szdescription:: text ~ ~ '%Hotels%':: character varying:: text THEN 'Red':: character varying
                            ELSE 'Green':: character varying END AS rag_rating,
                            ax.sz_mobile_no AS aadhar_card,
                            ta.sz_sales_manager_code AS openedby,
                            us.szuser_name AS cro_name,
                            ta.sz_dsa_code AS vcp_id,
                            trunc(ta.dt_creation) AS creation_date,
                            trunc(ta.dt_submission) AS submission_date,
                            asa.sz_status AS status,
                            asa.sz_sub_status AS sub_status,
                            asa.sz_sts_description AS rejectedreason,
                            fe.sz_payment_mode,
                            fe.f_afee_amount,
                            h.soft_approval_dt,
                            g.approval_dt,
                            du.du1_dt,
                            CASE
                            WHEN rj.sz_rej_code IS NULL
                            AND asa.sz_status:: text = 'CLOSE':: character varying:: text
                            AND la.f_sanctioned_amt IS NULL THEN 'Dummy':: character varying
                            ELSE rj.sz_rej_code END AS sz_rej_code,
                            CASE
                            WHEN rj.sz_rej_code IS NOT NULL
                            OR asa.sz_status:: text = 'CLOSE':: character varying:: text
                            AND la.f_sanctioned_amt IS NULL THEN trunc(asa.dt_sts_last_updated)
                            ELSE NULL:: date END AS rejection_date,
                            rk.rejection_reason,
                            la.f_sanctioned_amt,
                            ta.sz_credit_stat_activity AS credit_activity,
                            lp.szdescription AS credit_description,
                            ta.sz_credit_stat_reason AS credit_reason
                        FROM
                            lms.t_application ta
                            LEFT JOIN lms.base_sec_mst_systemuser us ON us.szuser_code:: text = ta.sz_sales_manager_code:: text
                            LEFT JOIN lms.base_org_mst_businessunit b ON ta.sz_servicing_branch_code:: text = b.szname:: text
                            LEFT JOIN (
                                SELECT
                                    base_org_mst_businessunit.szdescription,
                                    base_org_mst_businessunit.szname
                                FROM
                                    lms.base_org_mst_businessunit
                                WHERE
                                    (
                                        base_org_mst_businessunit.szbusiness_unit_id IN (
                                            SELECT
                                                b.szparent_business_unit_id
                                            FROM
                                                lms.t_application ta
                                                LEFT JOIN lms.base_org_mst_businessunit b ON ta.sz_servicing_branch_code:: text = b.szname:: text
                                        )
                                    )
                            ) cl_name ON ta.sz_servicing_branch_code:: text = cl_name.szname:: text
                            JOIN lms.t_applicant app ON app.sz_application_no:: text = ta.sz_application_no:: text
                            AND app.sz_appl_type_code:: text = 'BORROWER':: character varying:: text
                            JOIN lms.t_ind_applicant_detail ad ON app.i_applicant_id = ad.i_applicant_id
                            LEFT JOIN lms.base_app_mst_lookups r ON r.szcode:: text = ad.sz_primary_me_cat:: text
                            AND r.szlookupefinedfor:: text = 'ME_CATEGORY':: character varying:: text
                            LEFT JOIN lms.base_app_mst_lookups s ON s.szcode:: text = ad.sz_primary_me_typ:: text
                            AND s.szlookupefinedfor:: text = 'ME_TYPE':: character varying:: text
                            JOIN lms.t_applicant_address ax ON app.i_applicant_id = ax.i_applicant_id
                            JOIN lms.t_loan_details lo ON app.sz_application_no:: text = lo.sz_application_no:: text
                            LEFT JOIN lms.t_application_spl_attrib asa ON app.sz_application_no:: text = asa.sz_application_no:: text
                            LEFT JOIN lms.t_application_fee fe ON ta.sz_application_no:: text = fe.sz_application_no:: text
                            LEFT JOIN (
                                SELECT
                                    DISTINCT t_application_cfa.sz_application_no,
                                    "max"(t_application_cfa.sz_src_type:: text) AS sz_src_type,
                                    COALESCE(
                                        "max"(t_application_cfa.sz_outstanding_amt:: text),
                                        '0':: character varying:: text
                                    ) AS eb_outstanding_amt
                                FROM
                                    lms.t_application_cfa
                                WHERE
                                    t_application_cfa.sz_src_type:: text = 'EB':: character varying:: text
                                    AND t_application_cfa.c_loan_type:: text <> 'P':: character varying:: text
                                    AND t_application_cfa.clatestflag:: text = 'Y':: character varying:: text
                                GROUP BY
                                    t_application_cfa.sz_application_no
                            ) ac ON ac.sz_application_no:: text = ta.sz_application_no:: text
                            LEFT JOIN (
                                SELECT
                                    DISTINCT wf_t_notifications_hist.sz_application_no,
                                    "max"(wf_t_notifications_hist.dt_activity_end) AS approval_dt
                                FROM
                                    lms.wf_t_notifications_hist
                                WHERE
                                    wf_t_notifications_hist.sz_activity_code:: text = 'UPDATE_FINAL_DECISION':: character varying:: text
                                GROUP BY
                                    wf_t_notifications_hist.sz_application_no
                            ) g ON ta.sz_application_no:: text = g.sz_application_no:: text
                            LEFT JOIN (
                                SELECT
                                    DISTINCT wf_t_notifications_hist.sz_application_no,
                                    "max"(wf_t_notifications_hist.dt_activity_end) AS soft_approval_dt
                                FROM
                                    lms.wf_t_notifications_hist
                                WHERE
                                    wf_t_notifications_hist.sz_activity_code:: text = 'CFA_ELIGIBILITY':: character varying:: text
                                GROUP BY
                                    wf_t_notifications_hist.sz_application_no
                            ) h ON ta.sz_application_no:: text = h.sz_application_no:: text
                            LEFT JOIN (
                                SELECT
                                    DISTINCT wf_t_notifications_hist.sz_application_no,
                                    "max"(wf_t_notifications_hist.sz_start_time) AS du1_dt
                                FROM
                                    lms.wf_t_notifications_hist
                                WHERE
                                    wf_t_notifications_hist.sz_activity_code:: text = 'LOAN_AGREE_DOC_PRINT':: character varying:: text
                                GROUP BY
                                    wf_t_notifications_hist.sz_application_no
                                UNION ALL
                                SELECT
                                    DISTINCT wf_t_notifications.sz_application_no,
                                    "max"(wf_t_notifications.sz_start_time) AS du1_dt_1
                                FROM
                                    lms.wf_t_notifications
                                WHERE
                                    wf_t_notifications.sz_activity_code:: text = 'LOAN_AGREE_DOC_PRINT':: character varying:: text
                                GROUP BY
                                    wf_t_notifications.sz_application_no
                            ) du ON ta.sz_application_no:: text = du.sz_application_no:: text
                            LEFT JOIN lms.t_lms_loan_account la ON ta.sz_application_no:: text = la.sz_loan_account_no:: text
                            LEFT JOIN lms.t_reject_application rj ON ta.sz_application_no:: text = rj.sz_application_no:: text
                            LEFT JOIN (
                                SELECT
                                    base_app_mst_lookups.szcode,
                                    "max"(base_app_mst_lookups.szdescription:: text) AS rejection_reason
                                FROM
                                    lms.base_app_mst_lookups
                                GROUP BY
                                    base_app_mst_lookups.szcode
                            ) rk ON rj.sz_rej_code:: text = rk.szcode:: text
                            LEFT JOIN lms.base_app_mst_lookups lp ON ta.sz_credit_stat_activity:: text = lp.szcode:: text
                        WHERE
                            (
                                ta.sz_portfolio_code:: text = 'SBML':: character varying:: text
                                OR ta.sz_portfolio_code:: text = 'SVHL':: character varying:: text
                                OR ta.sz_portfolio_code:: text = 'SBHL':: character varying:: text
                            )
                            AND ta.dt_submission >= (
                                last_day(
                                    add_months(
                                        trunc(
                                            'now':: character varying:: timestamp without time zone - 1:: bigint
                                        ):: timestamp without time zone,
                                        - 2:: bigint
                                    )
                                ) + 1
                            )
                            AND ta.dt_submission <= last_day(
                                trunc(
                                    'now':: character varying:: timestamp without time zone - 1:: bigint
                                ):: timestamp without time zone
                            )
                    ) x
            ) y
    ) ab;