CREATE
OR REPLACE VIEW "lms"."vw_charges" AS
SELECT
        x.sz_loan_account_no,
        x.dt_chg_booked,
        x.charges_amt,
        'now':: text:: date AS mis_date,
        COALESCE(x.waived_amt, 0:: numeric:: numeric(18, 0)) AS waived_amt,
        round(
                (
                        x.charges_amt - COALESCE(x.waived_amt, 0:: numeric:: numeric(18, 0))
                ) * 1.18,
                2
        ) AS to_be_collected,
        y.collected_amt
FROM
        (
                SELECT
                        a.sz_loan_account_no,
                        "max"(a.dt_chg_booked) AS dt_chg_booked,
                        sum(a.f_amount) AS charges_amt,
                        sum(b.f_waived_amt) AS waived_amt
                FROM
                        lms.t_lms_chg_booking_dtls a
                        LEFT JOIN lms.t_lms_chg_waiver_dtls b ON a.sz_loan_account_no:: text = b.sz_loan_account_no:: text
                        AND a.i_chgbooktran_id = b.i_chgbooktran_id
                WHERE
                        (
                                a.sz_tranhead:: text = 'LATEPAY_LD':: character varying:: text
                                OR a.sz_tranhead:: text = 'FCC_CH':: character varying:: text
                                OR a.sz_tranhead:: text = 'BNC_CH':: character varying:: text
                        )
                        AND a.dt_chg_booked >= (
                                last_day(
                                        add_months(
                                                trunc(
                                                        'now':: character varying:: timestamp without time zone - 1:: bigint
                                                ):: timestamp without time zone,
                                                - 1:: bigint
                                        )
                                ) + 1
                        )
                        AND a.dt_chg_booked <= last_day(
                                trunc(
                                        'now':: character varying:: timestamp without time zone - 1:: bigint
                                ):: timestamp without time zone
                        )
                GROUP BY
                        a.sz_loan_account_no
        ) x
        LEFT JOIN (
                SELECT
                        b.sz_loan_account_no,
                        sum(a.f_amount) AS collected_amt
                FROM
                        lms.t_lms_payment_dtls a
                        JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
                        AND a.i_payment_srno = b.i_payment_srno
                        AND a.dt_payment >= (
                                last_day(
                                        add_months(
                                                trunc(
                                                        'now':: character varying:: timestamp without time zone - 1:: bigint
                                                ):: timestamp without time zone,
                                                - 1:: bigint
                                        )
                                ) + 1
                        )
                        AND a.dt_payment <= last_day(
                                trunc(
                                        'now':: character varying:: timestamp without time zone - 1:: bigint
                                ):: timestamp without time zone
                        )
                        AND (
                                a.sz_trantype:: text = 'FEE':: character varying:: text
                                OR a.sz_trantype:: text = 'TAX':: character varying:: text
                        )
                        AND b.sz_payment_purpose:: text = 'NORMAL_PAYMENT':: character varying:: text
                        JOIN lms.t_lms_instruments i ON i.i_tran_id = a.i_tran_id
                        AND i.sz_inst_status:: text = 'CLR':: character varying:: text
                GROUP BY
                        b.sz_loan_account_no
        ) y ON x.sz_loan_account_no:: text = y.sz_loan_account_no:: text;