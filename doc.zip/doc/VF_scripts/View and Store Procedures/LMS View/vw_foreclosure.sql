CREATE
OR REPLACE VIEW "lms"."vw_foreclosure" AS
SELECT
    a.sz_org_branch_code AS branch_code,
    b.szdescription AS branch_name,
    a.sz_loan_account_no,
    a.sz_portfolio_code,
    f.sz_product_code AS product_code,
    c.dt_disbursement AS disburse_date,
    g.disburse_amt,
    a.sz_customer_no,
    regexp_replace(
        (
            (
                (e.sz_fname:: text || ' ':: character varying:: text) || e.sz_mname:: text
            ) || ' ':: character varying:: text
        ) || e.sz_lname:: text,
        '[ ]+':: character varying:: text,
        ' ':: character varying:: text
    ) AS customer_name,
    e.sz_mobile1 AS mobile,
    (a.sz_fund_id:: text || '-':: character varying:: text) || "replace"(
        h.sz_fund_name:: text,
        ',':: character varying:: text,
        '':: character varying:: text
    ) AS fund_name,
    COALESCE(
        COALESCE(
            COALESCE(a.dt_status_change, c.dt_cancelsdatetime),
            a.dt_lastupdated
        ),
        c.dt_cancelsdatetime
    ) AS closing_date,
    COALESCE(
        i.principal_outstanding,
        0:: numeric:: numeric(18, 0)
    ) AS principal_outstanding,
    COALESCE(j.actual_payable, 0:: numeric:: numeric(18, 0)) AS actual_payable,
    COALESCE("k".settled_amount, 0:: numeric:: numeric(18, 0)) AS settled_amount,
    CASE
    WHEN a.c_account_status = 'C':: bpchar THEN 'Close':: character varying
    ELSE CASE
    WHEN a.c_additional_status:: text = 'DC':: character varying:: text THEN 'Disbursement Cancelled':: character varying
    WHEN a.c_additional_status:: text = 'F':: character varying:: text THEN 'Foreclosed':: character varying
    WHEN a.c_additional_status:: text = 'L':: character varying:: text THEN 'Live':: character varying
    WHEN a.c_additional_status:: text = 'M':: character varying:: text THEN 'Matured':: character varying
    WHEN a.c_additional_status:: text = 'PD':: character varying:: text THEN 'Pending for Setlmnt DRE':: character varying
    WHEN a.c_additional_status:: text = 'PF':: character varying:: text THEN 'Pending for foreclosure':: character varying
    WHEN a.c_additional_status:: text = 'PP':: character varying:: text THEN 'Pending for Prepayment':: character varying
    WHEN a.c_additional_status:: text = 'PR':: character varying:: text THEN 'Pending for repossession':: character varying
    WHEN a.c_additional_status:: text = 'PS':: character varying:: text THEN 'Pending For Settlement':: character varying
    WHEN a.c_additional_status:: text = 'R':: character varying:: text THEN 'Asset Sold':: character varying
    WHEN a.c_additional_status:: text = 'RC':: character varying:: text THEN 'Recalled':: character varying
    WHEN a.c_additional_status:: text = 'RD':: character varying:: text THEN 'Pending for Restructure DRE':: character varying
    WHEN a.c_additional_status:: text = 'RP':: character varying:: text THEN 'Repossessed':: character varying
    WHEN a.c_additional_status:: text = 'RS':: character varying:: text THEN 'Pending for Restructure':: character varying
    WHEN a.c_additional_status:: text = 'S':: character varying:: text THEN 'Settled':: character varying
    WHEN a.c_additional_status:: text = 'UC':: character varying:: text THEN 'Under Cancellation':: character varying
    WHEN a.c_additional_status:: text = 'FF':: character varying:: text THEN 'Foreclosure':: character varying
    WHEN a.c_additional_status:: text = 'W':: character varying:: text THEN 'WriteOff':: character varying
    WHEN a.c_additional_status:: text = 'Z':: character varying:: text THEN 'Excess':: character varying
    ELSE NULL:: character varying END END AS c_account_status,
    d.sz_settlement_mode AS settlement_mode
FROM
    lms.t_lms_loan_account a
    LEFT JOIN lms.base_org_mst_businessunit b ON b.szname:: text = a.sz_org_branch_code:: text
    JOIN lms.t_lms_disb_dtls c ON a.sz_loan_account_no:: text = c.sz_loan_account_no:: text
    AND c.i_disb_srno = 1
    LEFT JOIN lms.t_lms_settlement d ON a.sz_loan_account_no:: text = d.sz_loan_account_no:: text
    AND d.c_status:: text = 'A':: character varying:: text
    JOIN lms.t_cs_customer_details e ON a.sz_customer_no:: text = e.sz_customer_no:: text
    LEFT JOIN lms.t_lms_fund_details h ON a.sz_fund_id:: text = h.sz_fund_id:: text
    LEFT JOIN lms.t_lms_product_dtls f ON a.sz_loan_account_no:: text = f.sz_loan_account_no:: text
    AND f.i_tranche_no = 1
    LEFT JOIN (
        SELECT
            t_lms_tranche_disb_ref.sz_loan_account_no,
            sum(t_lms_tranche_disb_ref.f_amount) AS disburse_amt
        FROM
            lms.t_lms_tranche_disb_ref
        GROUP BY
            t_lms_tranche_disb_ref.sz_loan_account_no
    ) g ON a.sz_loan_account_no:: text = g.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            t_lms_payment_header.sz_loan_account_no,
            sum(
                CASE
                WHEN t_lms_payment_header.c_pay_reverse_yn = 'N':: bpchar THEN t_lms_payment_header.f_amount
                ELSE 0:: numeric:: numeric(18, 0) END
            ) AS principal_outstanding
        FROM
            lms.t_lms_payment_header
        WHERE
            t_lms_payment_header.c_pay_reverse_yn = 'N':: bpchar
        GROUP BY
            t_lms_payment_header.sz_loan_account_no
    ) i ON a.sz_loan_account_no:: text = i.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            t_lms_payment_header.sz_loan_account_no,
            sum(
                CASE
                WHEN t_lms_payment_header.c_pay_reverse_yn = 'N':: bpchar THEN t_lms_payment_header.f_amount
                ELSE 0:: numeric:: numeric(18, 0) END
            ) AS actual_payable
        FROM
            lms.t_lms_payment_header
        WHERE
            t_lms_payment_header.c_pay_reverse_yn = 'N':: bpchar
        GROUP BY
            t_lms_payment_header.sz_loan_account_no
    ) j ON a.sz_loan_account_no:: text = j.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            t_lms_payment_header.sz_loan_account_no,
            sum(
                CASE
                WHEN t_lms_payment_header.c_pay_reverse_yn = 'N':: bpchar THEN t_lms_payment_header.f_amount
                ELSE 0:: numeric:: numeric(18, 0) END
            ) AS settled_amount
        FROM
            lms.t_lms_payment_header
        WHERE
            t_lms_payment_header.c_pay_reverse_yn = 'N':: bpchar
        GROUP BY
            t_lms_payment_header.sz_loan_account_no
    ) "k" ON a.sz_loan_account_no:: text = "k".sz_loan_account_no:: text
WHERE
    a.c_account_status = 'C':: bpchar;