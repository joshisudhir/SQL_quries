CREATE
OR REPLACE VIEW "lms"."vw_od_report" AS
SELECT
    a.sz_org_branch_code AS branchcode,
    i.szdescription AS branch_name,
    a.sz_fund_id AS fund_id,
    "replace"(
        f.sz_fund_name:: text,
        ',':: character varying:: text,
        '':: character varying:: text
    ) AS fund_name,
    CASE
    WHEN a.c_repay_freq = 12 THEN 'Monthly':: character varying
    WHEN a.c_repay_freq = 52 THEN 'Weekly':: character varying
    WHEN a.c_repay_freq = 26 THEN 'Fortnightly':: character varying
    WHEN a.c_repay_freq = 6 THEN 'Bi-Monthly':: character varying
    WHEN a.c_repay_freq = 4 THEN 'Quarterly':: character varying
    WHEN a.c_repay_freq = 2 THEN 'Half Yearly':: character varying
    WHEN a.c_repay_freq = 1 THEN 'Yearly':: character varying
    ELSE NULL:: character varying END AS repay_freq,
    a.sz_portfolio_code AS loan_product_type_id,
    a.sz_loan_account_no AS account_id,
    CASE
    WHEN a.c_account_status = 'L':: bpchar THEN 'Active Loan':: character varying
    WHEN a.c_account_status = 'C':: bpchar THEN 'Paid Off':: character varying
    ELSE '':: character varying END:: text || CASE
    WHEN a.c_additional_status:: text = 'DC':: character varying:: text THEN 'Disbursement Cancelled':: character varying
    WHEN a.c_additional_status:: text = 'F':: character varying:: text THEN 'Foreclosed':: character varying
    WHEN a.c_additional_status:: text = 'L':: character varying:: text THEN 'Live':: character varying
    WHEN a.c_additional_status:: text = 'M':: character varying:: text THEN 'Matured':: character varying
    WHEN a.c_additional_status:: text = 'PD':: character varying:: text THEN 'Pending for Setlmnt DRE':: character varying
    WHEN a.c_additional_status:: text = 'PF':: character varying:: text THEN 'Pending for foreclosure':: character varying
    WHEN a.c_additional_status:: text = 'PP':: character varying:: text THEN 'Pending for Prepayment':: character varying
    WHEN a.c_additional_status:: text = 'PR':: character varying:: text THEN 'Pending for repossession':: character varying
    WHEN a.c_additional_status:: text = 'PS':: character varying:: text THEN 'Pending For Settlement':: character varying
    WHEN a.c_additional_status:: text = 'R':: character varying:: text THEN 'Asset Sold':: character varying
    WHEN a.c_additional_status:: text = 'RC':: character varying:: text THEN 'Recalled':: character varying
    WHEN a.c_additional_status:: text = 'RD':: character varying:: text THEN 'Pending for Restructure DRE':: character varying
    WHEN a.c_additional_status:: text = 'RP':: character varying:: text THEN 'Repossessed':: character varying
    WHEN a.c_additional_status:: text = 'RS':: character varying:: text THEN 'Pending for Restructure':: character varying
    WHEN a.c_additional_status:: text = 'S':: character varying:: text THEN 'Settled':: character varying
    WHEN a.c_additional_status:: text = 'UC':: character varying:: text THEN 'Under Cancellation':: character varying
    WHEN a.c_additional_status:: text = 'W':: character varying:: text THEN 'WriteOff':: character varying
    WHEN a.c_additional_status:: text = 'Z':: character varying:: text THEN 'Excess':: character varying
    WHEN a.c_additional_status:: text = 'EB':: character varying:: text THEN 'EB Foreclosed':: character varying
    ELSE '':: character varying END:: text AS loan_status,
    a.f_sanctioned_amt AS loan_amount,
    COALESCE(
        r.principal_due_till_date,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) AS principal_due_till_date,
    COALESCE(
        r.interest_due_till_date,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) AS interest_due_till_date,
    COALESCE(
        r.amount_due_till_dt,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) AS amount_due_till_dt,
    j.principal_paid,
    j.interest_paid,
    j.amount_paid_till_dt,
    COALESCE(
        r.principal_due_till_date,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) + COALESCE(
        l.f_futpri_amt,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) AS outstanding_principal,
    COALESCE(
        r.total_outs,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) + COALESCE(
        r.f_tax_amt,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) AS total_outstanding,
    COALESCE(
        r.principal_due_till_date,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) AS principal_overdue,
    COALESCE(
        r.interest_due_till_date,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) AS int_overdue,
    CASE
    WHEN (
        'now':: character varying:: date:: timestamp without time zone - r.dt_duedate
    ):: character varying:: text > 0:: character varying:: text THEN COALESCE(
        r.principal_due_till_date,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) + COALESCE(
        r.interest_due_till_date,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    )
    ELSE 0:: numeric:: numeric(18, 0):: numeric(18, 2) END AS total_arrears,
    CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN r.dt_duedate + (a.dt_morat_end - a.dt_morat_st):: bigint
    ELSE COALESCE(
        r.dt_duedate:: date:: timestamp without time zone,
        'now':: character varying:: date:: timestamp without time zone
    ) END:: date AS overdue_date,
    CASE
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN 'now':: character varying:: date - to_date(
        r.dt_duedate:: character varying:: text,
        'yyyy-mm-dd':: character varying:: text
    ) - (a.dt_morat_end - a.dt_morat_st):: bigint
    ELSE (
        'now':: character varying:: date - to_date(
            r.dt_duedate:: character varying:: text,
            'yyyy-mm-dd':: character varying:: text
        )
    ):: bigint END IS NULL THEN 0:: bigint
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN 'now':: character varying:: date - to_date(
        r.dt_duedate:: character varying:: text,
        'yyyy-mm-dd':: character varying:: text
    ) - (a.dt_morat_end - a.dt_morat_st):: bigint
    ELSE (
        'now':: character varying:: date - to_date(
            r.dt_duedate:: character varying:: text,
            'yyyy-mm-dd':: character varying:: text
        )
    ):: bigint END < 0 THEN 0:: bigint
    ELSE CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN 'now':: character varying:: date - to_date(
        r.dt_duedate:: character varying:: text,
        'yyyy-mm-dd':: character varying:: text
    ) - (a.dt_morat_end - a.dt_morat_st):: bigint
    ELSE (
        'now':: character varying:: date - to_date(
            r.dt_duedate:: character varying:: text,
            'yyyy-mm-dd':: character varying:: text
        )
    ):: bigint END END AS overdue_days,
    CASE
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END IS NULL THEN '0':: character varying
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END <= 0 THEN '0':: character varying
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END >= 1
    AND CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END <= 30 THEN '1-30':: character varying
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END >= 31
    AND CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END <= 60 THEN '31-60':: character varying
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END >= 61
    AND CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END <= 90 THEN '61-90':: character varying
    WHEN CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END >= 91
    AND CASE
    WHEN a.c_cov_morat = 'Y':: bpchar
    AND r.dt_duedate <= a.dt_morat_st THEN date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) - date_diff(
        'day':: character varying:: text,
        a.dt_morat_end:: timestamp without time zone,
        a.dt_morat_st:: timestamp without time zone
    )
    ELSE date_diff(
        'day':: character varying:: text,
        r.dt_duedate,
        getdate()
    ) END <= 120 THEN '91-120':: character varying
    ELSE '>120':: character varying END AS overdue_bucket,
    kl.max_paydt AS paid_date,
    "k".total_paid,
    (
        j.paid_emis:: character varying:: text || '_':: character varying:: text
    ) || l.i_tenor:: character varying:: text AS no_ofinstallments_totaltenor,
    CASE
    WHEN c.f_prov_amt < 0:: numeric:: numeric(18, 0):: numeric(18, 2)
    OR a.c_account_status = 'C':: bpchar THEN 0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ELSE c.f_prov_amt END AS provision_amt,
    c.f_sec_prov_rate AS provision_sec_per,
    c.f_non_sec_prov_rate AS provision_non_sec_per,
    a.sz_customer_no AS customer_no,
    (
        (
            (
                COALESCE(d.sz_fname, '':: character varying):: text || ' ':: character varying:: text
            ) || COALESCE(d.sz_mname, '':: character varying):: text
        ) || ' ':: character varying:: text
    ) || COALESCE(d.sz_lname, '':: character varying):: text AS client_name,
    d.sz_pref_add_type AS address_type_id,
    "replace"(
        e.sz_address_1:: text,
        ',':: character varying:: text,
        ' ':: character varying:: text
    ) AS addressline_1,
    "replace"(
        e.sz_address_2:: text,
        ',':: character varying:: text,
        ' ':: character varying:: text
    ) AS addressline2,
    "replace"(
        (
            (
                (e.sz_city:: text || '-':: character varying:: text) || e.sz_extra_1:: text
            ) || '-':: character varying:: text
        ) || e.sz_postal_code:: text,
        ',':: character varying:: text,
        ' ':: character varying:: text
    ) AS city_village_pin,
    m.installment_amnt AS instamnt,
    h.dt_disbursement AS disb_dt,
    CASE
    WHEN (
        COALESCE(
            m.inst_amt,
            0:: numeric:: numeric(18, 0):: numeric(18, 2)
        ) - COALESCE(
            n.interestpaid,
            0:: numeric:: numeric(18, 0):: numeric(18, 2)
        )
    ) < 0:: numeric:: numeric(18, 0):: numeric(18, 2) THEN 0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ELSE COALESCE(
        m.inst_amt,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) - COALESCE(
        n.interestpaid,
        0:: numeric:: numeric(18, 0):: numeric(18, 2)
    ) END AS oust_int,
    p.sz_spouse_name AS spousename,
    q.sz_product_code AS loanproducttypeid,
    o.rescheduleddate,
    a.sz_payment_recovery_mode AS repayment_mode,
    to_date(
        a.i_cycleday:: text || to_char(
            'now':: character varying:: timestamp without time zone,
            '-mm-yyyy':: character varying:: text
        ),
        'dd-mm-yyyy':: character varying:: text
    ) AS emi_due_date,
    '' AS bounce_reason,
    CASE
    WHEN c.sz_loan_quality_code IS NULL THEN a.sz_loan_quality_code
    ELSE c.sz_loan_quality_code END AS loan_quality_code,
    CASE
    WHEN c.sz_rbi_loan_quality_code IS NULL THEN a.sz_rbi_loan_quality_code
    ELSE c.sz_rbi_loan_quality_code END AS rbi_loan_quality_code,
    pg_catalog.row_number() OVER(PARTITION BY a.sz_loan_account_no) AS dup_check,
    'now':: character varying:: date AS mis_date,
    a.sz_cro_id,
    l.dt_installment_start
FROM
    lms.t_lms_loan_account a
    LEFT JOIN (
        SELECT
            t_lms_provision_dtls.sz_loan_account_no AS acct_no,
            "max"(t_lms_provision_dtls.i_srno) AS srno
        FROM
            lms.t_lms_provision_dtls
        GROUP BY
            t_lms_provision_dtls.sz_loan_account_no
    ) b ON b.acct_no:: text = a.sz_loan_account_no:: text
    LEFT JOIN lms.t_lms_provision_dtls c ON b.acct_no:: text = c.sz_loan_account_no:: text
    AND c.i_srno = b.srno
    LEFT JOIN lms.t_cs_customer_details d ON a.sz_customer_no:: text = d.sz_customer_no:: text
    LEFT JOIN lms.t_cs_address_details e ON d.i_address_seq = e.i_address_seq
    LEFT JOIN lms.t_lms_fund_details f ON a.sz_fund_id:: text = f.sz_fund_id:: text
    LEFT JOIN lms.m_lms_provision_setup_dtls g ON a.sz_loan_quality_code:: text = g.sz_loan_quality_code:: text
    AND g.sz_level:: text = 'PORTFOLIO':: character varying:: text
    AND g.sz_level_value:: text = a.sz_portfolio_code:: text
    JOIN lms.t_lms_disb_dtls h ON a.sz_loan_account_no:: text = h.sz_loan_account_no:: text
    AND h.c_cancelationflg = 'N':: bpchar
    AND h.i_disb_srno = 1
    LEFT JOIN lms.base_org_mst_businessunit i ON i.szname:: text = a.sz_org_branch_code:: text
    LEFT JOIN (
        SELECT
            t_lms_repay_schedule.sz_loan_account_no,
            sum(t_lms_repay_schedule.f_prinamt) AS principal_paid,
            sum(t_lms_repay_schedule.f_intamt) AS interest_paid,
            sum(
                t_lms_repay_schedule.f_prinamt + t_lms_repay_schedule.f_intamt
            ) AS amount_paid_till_dt,
            "max"(t_lms_repay_schedule.i_installment_no) AS paid_emis
        FROM
            lms.t_lms_repay_schedule
        WHERE
            t_lms_repay_schedule.dt_last_payment IS NOT NULL
        GROUP BY
            t_lms_repay_schedule.sz_loan_account_no
    ) j ON a.sz_loan_account_no:: text = j.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            t_lms_payment_header.sz_loan_account_no,
            "max"(t_lms_payment_header.dt_payment_applied) AS max_paydt
        FROM
            lms.t_lms_payment_header
        GROUP BY
            t_lms_payment_header.sz_loan_account_no
    ) kl ON a.sz_loan_account_no:: text = kl.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            a.sz_loan_account_no,
            sum(
                COALESCE(b.f_amount, 0:: numeric:: numeric(18, 0)) - COALESCE(
                    CASE
                    WHEN b.f_rev_amount IS NULL THEN 0:: numeric:: numeric(18, 0)
                    WHEN b.f_rev_amount:: text = '':: character varying:: text THEN 0:: numeric:: numeric(18, 0)
                    ELSE b.f_rev_amount:: numeric(18, 2) END,
                    0:: numeric:: numeric(18, 0)
                )
            ) AS total_paid
        FROM
            lms.t_lms_payment_header a
            JOIN lms.t_lms_payment_dtls b ON a.i_tran_id = b.i_tran_id
            AND a.i_payment_srno = b.i_payment_srno
            AND COALESCE(a.c_pay_reverse_yn, 'N':: bpchar) <> 'Y':: bpchar
        WHERE
            a.dt_payment_applied = (
                (
                    SELECT
                        "max"(ba.dt_payment_applied) AS "max"
                    FROM
                        lms.t_lms_payment_header ba
                    WHERE
                        a.sz_loan_account_no:: text = ba.sz_loan_account_no:: text
                )
            )
        GROUP BY
            a.sz_loan_account_no
    ) "k" ON a.sz_loan_account_no:: text = "k".sz_loan_account_no:: text
    LEFT JOIN lms.t_lms_tranche_dtls l ON a.sz_loan_account_no:: text = l.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            t_lms_repay_schedule.sz_loan_account_no,
            "max"(t_lms_repay_schedule.i_installment_no) AS max_tenor,
            sum(t_lms_repay_schedule.f_prinamt) AS prin_amt,
            sum(t_lms_repay_schedule.f_intamt) AS inst_amt,
            sum(
                CASE
                WHEN t_lms_repay_schedule.i_installment_no = 1:: numeric:: numeric(18, 0):: numeric(18, 2) THEN COALESCE(
                    t_lms_repay_schedule.f_prinamt + t_lms_repay_schedule.f_intamt,
                    0:: numeric:: numeric(18, 0):: numeric(18, 2)
                )
                ELSE NULL:: numeric:: numeric(18, 0):: numeric(18, 2) END
            ) AS installment_amnt
        FROM
            lms.t_lms_repay_schedule
        GROUP BY
            t_lms_repay_schedule.sz_loan_account_no
    ) m ON a.sz_loan_account_no:: text = m.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            b.sz_loan_account_no,
            sum(
                a.f_amount - COALESCE(
                    CASE
                    WHEN a.f_rev_amount IS NULL THEN 0:: numeric:: numeric(18, 0)
                    WHEN a.f_rev_amount:: text = '':: character varying:: text THEN 0:: numeric:: numeric(18, 0)
                    ELSE a.f_rev_amount:: numeric(18, 2) END,
                    0:: numeric:: numeric(18, 0)
                )
            ) AS interestpaid
        FROM
            lms.t_lms_payment_dtls a
            JOIN lms.t_lms_payment_header b ON a.i_tran_id = b.i_tran_id
            AND a.i_payment_srno = b.i_payment_srno
            AND b.c_pay_reverse_yn = 'N':: bpchar
        WHERE
            (
                a.sz_trantype:: text = 'INSTALLMENT':: character varying:: text
                OR a.sz_trantype:: text = 'LOAN_AMOUNT':: character varying:: text
            )
            AND a.sz_tranhead:: text = 'INT_AMT':: character varying:: text
            AND b.dt_payment_applied < 'now':: character varying:: timestamp without time zone
        GROUP BY
            b.sz_loan_account_no
    ) n ON a.sz_loan_account_no:: text = n.sz_loan_account_no:: text
    LEFT JOIN (
        SELECT
            t_lms_reschedule.sz_loan_account_no,
            "max"(t_lms_reschedule.dt_transaction) AS rescheduleddate
        FROM
            lms.t_lms_reschedule
        GROUP BY
            t_lms_reschedule.sz_loan_account_no
    ) o ON a.sz_loan_account_no:: text = o.sz_loan_account_no:: text
    LEFT JOIN lms.t_cs_individual_details p ON a.sz_customer_no:: text = p.sz_customer_no:: text
    LEFT JOIN lms.t_lms_product_dtls q ON a.sz_loan_account_no:: text = q.sz_loan_account_no:: text
    AND q.i_tranche_no = 1
    LEFT JOIN (
        SELECT
            a.sz_loan_account_no,
            COALESCE(
                sum(
                    CASE
                    WHEN a.sz_tranhead:: text = 'PRN_AMT':: character varying:: text
                    OR a.sz_tranhead:: text = 'FUT_PRN':: character varying:: text THEN COALESCE(
                        a.f_due_amt,
                        0:: numeric:: numeric(18, 0):: numeric(18, 2)
                    )
                    ELSE 0:: numeric:: numeric(18, 0):: numeric(18, 2) END
                ),
                0:: numeric:: numeric(18, 0):: numeric(18, 2)
            ) AS principal_due_till_date,
            COALESCE(
                sum(
                    CASE
                    WHEN a.sz_tranhead:: text = 'INT_AMT':: character varying:: text THEN COALESCE(
                        a.f_due_amt,
                        0:: numeric:: numeric(18, 0):: numeric(18, 2)
                    )
                    ELSE 0:: numeric:: numeric(18, 0):: numeric(18, 2) END
                ),
                0:: numeric:: numeric(18, 0):: numeric(18, 2)
            ) AS interest_due_till_date,
            COALESCE(
                min(
                    CASE
                    WHEN a.sz_trantype:: text = 'INSTALLMENT':: character varying:: text
                    OR a.sz_trantype:: text = 'LOAN_AMOUNT':: character varying:: text THEN a.dt_duedate
                    ELSE NULL:: date END
                ):: timestamp without time zone,
                'now':: character varying:: timestamp without time zone
            ) AS dt_duedate,
            COALESCE(
                sum(b.f_tax_amt),
                0:: numeric:: numeric(18, 0):: numeric(18, 2)
            ) AS f_tax_amt,
            COALESCE(
                sum(a.f_due_amt),
                0:: numeric:: numeric(18, 0):: numeric(18, 2)
            ) AS total_outs,
            COALESCE(
                sum(a.f_due_amt),
                0:: numeric:: numeric(18, 0):: numeric(18, 2)
            ) + COALESCE(
                sum(b.f_tax_amt),
                0:: numeric:: numeric(18, 0):: numeric(18, 2)
            ) AS amount_due_till_dt
        FROM
            lms.t_lms_due_dtls a
            LEFT JOIN (
                SELECT
                    t_lms_taxdue_dtls.sz_loan_account_no,
                    t_lms_taxdue_dtls.i_srno,
                    sum(t_lms_taxdue_dtls.f_tax_amt) AS f_tax_amt
                FROM
                    lms.t_lms_taxdue_dtls
                GROUP BY
                    t_lms_taxdue_dtls.sz_loan_account_no,
                    t_lms_taxdue_dtls.i_srno
            ) b ON a.sz_loan_account_no:: text = b.sz_loan_account_no:: text
            AND a.i_srno:: numeric:: numeric(18, 0):: numeric(10, 0) = b.i_srno
        GROUP BY
            a.sz_loan_account_no
    ) r ON a.sz_loan_account_no:: text = r.sz_loan_account_no:: text;