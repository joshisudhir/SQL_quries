CREATE
OR REPLACE VIEW "lms"."vw_daily_repayment" AS
SELECT
   t_lms_repay_schedule.sz_loan_account_no,
   t_lms_repay_schedule.i_installment_no,
   t_lms_repay_schedule.dt_installmentdue,
   t_lms_repay_schedule.f_prinamt,
   t_lms_repay_schedule.f_intamt,
   t_lms_repay_schedule.dt_last_payment,
   (
      t_lms_repay_schedule.f_prinamt + t_lms_repay_schedule.f_intamt
   ):: numeric(18, 2) AS emi_amount,
   'now':: character varying:: date AS mis_date
FROM
   lms.t_lms_repay_schedule
WHERE
   t_lms_repay_schedule.dt_last_payment >= (
      last_day(
         add_months(
            trunc(
               'now':: character varying:: timestamp without time zone
            ):: timestamp without time zone,
            - 1:: bigint
         )
      ) + 1
   )
   AND t_lms_repay_schedule.dt_last_payment <= last_day(
      trunc(
         'now':: character varying:: timestamp without time zone - 1:: bigint
      ):: timestamp without time zone
   );