import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_timestamp,to_date
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')

tables = ['t_nach_printing', 't_lms_writeoff_header', 't_lms_tranche_dtls', 't_lms_reschedule', 't_lms_refund_dtls','t_lms_product_dtls', 't_lms_instrument_alloc', 't_lms_chg_waiver_dtls', 't_ftr', 't_application_fee']

r_user = 'vf_admin'
r_pass = 'Vfadmin@12345'

redshift_tbl = ['t_lms_chg_waiver_dtls', 't_lms_reschedule']

table_number = 0
for tab in tables:
    custom_query = f"""(SELECT * FROM vistaar_lsi.{tab} 
            WHERE trunc(DT_LASTUPDATED) >= trunc(sysdate-1 )) custom_query_alias"""
    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)
    
    table_number += 1
    if df.rdd.isEmpty():
        print(f"DataFrame is empty {tab}. No data to process.")
    else:
        df.repartition(1).write \
            .mode("overwrite") \
            .option("header", "true") \
            .option("delimiter", "|") \
            .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f'{table_number} Table {tab} is successful !!')

    if tab in redshift_tbl:
        if tab=='t_lms_chg_waiver_dtls':
            dates = ['dt_chg_waived','dt_lastupdated','dt_userdatetime']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab=='t_lms_reschedule':
            dates = ['dt_transaction','dt_lastupdated','dt_userdatetime','dt_bpi_due']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
            
        df.write \
            .format("io.github.spark_redshift_community.spark.redshift") \
            .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user,r_pass)) \
            .option("dbtable", f"lms_stg.{tab}") \
            .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
            .option("postactions",  f"CALL lms.sp_{tab}();") \
            .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
            .mode("overwrite") \
            .save()

print("All Daily tables executed successfully!")

    

