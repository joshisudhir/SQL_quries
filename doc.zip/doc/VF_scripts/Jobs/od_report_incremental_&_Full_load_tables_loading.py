import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_date, to_timestamp,from_utc_timestamp, date_format
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')

print('# =========FULL LOAD======================T_LMS_DUE_DTLS=============T_LMS_TAXDUE_DTLS Full load====================T_LMS_SETTLEMENT======================')

# redshift configuration and connection
source_jdbc_conf = glueContext.extract_jdbc_conf('Redshift_connection')
from py4j.java_gateway import java_import
java_import(sc._gateway.jvm,"java.sql.Connection")
java_import(sc._gateway.jvm,"java.sql.DatabaseMetaData")
java_import(sc._gateway.jvm,"java.sql.DriverManager")
java_import(sc._gateway.jvm,"java.sql.SQLException")

print('Trying to connect to Redshift DB  for full load')
conn = sc._gateway.jvm.DriverManager.getConnection('jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod', 'vf_admin', 'Vfadmin@12345')

print('Connecttion to Redshift DB success! for full load')

print(f'Database name : {conn.getMetaData().getDatabaseProductName()}')

# call stored procedure
stmt = conn.createStatement();

cp_T_LMS_DUE_DTLS = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "i_srno",
    "lowerBound": "1",
    "upperBound": "2500",
    "numPartitions": "12"
}
cp_T_LMS_TAXDUE_DTLS = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "i_srno",
    "lowerBound": "1",
    "upperBound": "1500",
    "numPartitions": "12"
}
cp_t_lms_settlement = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "i_srno",
    "lowerBound": "1",
    "upperBound": "1500",
    "numPartitions": "12"
}         
s3 = boto3.client('s3', region_name='ap-south-1')
redshift_tbl = {'T_LMS_TAXDUE_DTLS': cp_T_LMS_TAXDUE_DTLS, 'T_LMS_DUE_DTLS': cp_T_LMS_DUE_DTLS ,'T_LMS_SETTLEMENT':cp_t_lms_settlement}

for table, cp in redshift_tbl.items():
    try:
        df = spark.read.jdbc(url=jdbc_url, table=f'VISTAAR_LSI.{table}', properties=cp)

        if table == 'T_LMS_DUE_DTLS':
            dates = ['dt_lastupdated','DT_USERDATETIME']
            df=df.withColumn('dt_duedate',to_date(col('dt_duedate')))
            for date in dates:
                df = df.withColumn(date, to_timestamp(col(date)))
        elif table == 'T_LMS_SETTLEMENT':
            dates = ['dt_userdatetime','dt_auth','dt_application','dt_policy_from','dt_policy_to','dt_cover_note']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))

        if df.rdd.isEmpty():
            print(f"Table {table} is empty. No data to process.")
        else:
            s3_path = f"s3://vistaar-lms-oracle/Every_night_full_load/{table}"
            df.write \
                .mode("overwrite") \
                .format("parquet") \
                .option("header", "true") \
                .save(s3_path)
            print(f"Table '{table}' is successfully uploaded to S3 at '{s3_path}.' ")
            print(f'Call to stored proc on {table} trying ')
            stmt.executeUpdate(f'call lms.sp_night_full_load_{table}_from_s3()');
            print(f'Call to proc on {table} is successful. ')           
    except Exception as e:
        print(f"Error processing table {table}: {str(e)}")
        
print("All full load table Executed successfully !!!! ")        

print('===============================================Incremental-Tables=============================================================')
cn_collection_jdbc_url = "jdbc:oracle:thin:@cn-vf-prod.c3k4oeocyc54.ap-south-1.rds.amazonaws.com:1521/ORACLE"

cn_collection_connection_properties = {
    "user": "root",
    "password": "7z0p3IlCRCTBP3F4",
    "driver": "oracle.jdbc.driver.OracleDriver"
}

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}
r_user = 'vf_admin'
r_pass = 'Vfadmin@12345'

redshift_tbl = ['t_lms_provision_dtls', 't_cs_address_details', 't_lms_repay_schedule', 't_lms_payment_header', 't_lms_reschedule', 't_cs_individual_details','cn_collection','t_lms_payment_dtls']



table_number = 0
for tab in redshift_tbl:
    if tab == 't_lms_provision_dtls':
        custom_query = f"""(SELECT * FROM vistaar_lsi.t_lms_provision_dtls WHERE (dt_lastupdated) >= (CURRENT_TIMESTAMP - INTERVAL '60' minute) or (dt_userdatetime) >= (CURRENT_TIMESTAMP - INTERVAL '60' minute) ) custom_query_alias"""
    elif tab=='cn_collection':
        custom_query="""(SELECT pr.PAYMENT_RECEIPT_NO, a.ACCOUNT_NUMBER, pr.PAYMENT_MODE, pr.PAYMENT_STATUS_CODE,
                    pr.PAYMENT_DATE, a.PRINCIPAL_OUTSTANDING_AMOUNT FROM CN_CORE.PAYMENT_RECEIPT pr
                    LEFT JOIN CN_CORE.ACCOUNT a ON pr.ACCOUNT_ID =a.id
                    WHERE PAYMENT_STATUS_CODE ='Collected' AND PAYMENT_MODE ='Cash') custom_query_alias"""
    elif tab == 't_cs_address_details':
        custom_query = f"""(SELECT distinct a.* FROM vistaar_lsi.t_cs_customer_details c
                    left join vistaar_lsi.t_lms_loan_references l on c.sz_customer_no =l.sz_customer_no 
                    left join vistaar_lsi.t_cs_address_details a on c.i_address_seq=a.i_address_seq
                    WHERE  (l.DT_USERDATETIME) >=(CURRENT_TIMESTAMP - INTERVAL '60' minute))  custom_query_alias"""
    elif tab == 't_lms_repay_schedule':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_repay_schedule WHERE (dt_last_payment) >= trunc(sysdate - INTERVAL '60' minute)  or (dt_userdatetime) >= (CURRENT_TIMESTAMP - INTERVAL '60' minute) ) custom_query_alias"""
    elif tab == 't_lms_payment_header':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_payment_header WHERE (dt_lastupdated) >= (CURRENT_TIMESTAMP - INTERVAL '60' minute) or (dt_userdatetime) >= (CURRENT_TIMESTAMP - INTERVAL '60' minute) ) custom_query_alias"""
    elif tab == 't_lms_reschedule':
        custom_query = f"""(SELECT * FROM vistaar_lsi.t_lms_reschedule 
            WHERE (DT_LASTUPDATED) >= (sysdate-1 )) custom_query_alias"""
    elif tab == 't_cs_individual_details':
        custom_query = f"""(SELECT distinct c.* FROM vistaar_lsi.t_cs_individual_details c
                    left join vistaar_lsi.t_lms_loan_references l on c.sz_customer_no =l.sz_customer_no 
                    WHERE  (l.DT_USERDATETIME) >=(CURRENT_TIMESTAMP - INTERVAL '60' minute))  custom_query_alias"""
    elif tab == 't_lms_payment_dtls':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_payment_dtls WHERE (dt_payment) >=  (CURRENT_TIMESTAMP - INTERVAL '60' minute)  or (dt_userdatetime) >= (CURRENT_TIMESTAMP - INTERVAL '60' minute) ) custom_query_alias"""

    if tab=='cn_collection':
        df = spark.read.jdbc(url=cn_collection_jdbc_url, table=custom_query, properties=cn_collection_connection_properties)
    else:
        df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)

    table_number += 1
    if df.rdd.isEmpty() or tab=='cn_collection':
        print(f"DataFrame is empty {tab}. No data to process. OR its cn_collection table  ")
    else:
        df.write \
            .mode("overwrite") \
            .option("header", "true") \
            .option("delimiter", "|") \
            .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f'{table_number} . {tab}  "S3" uploaded successfully!!')

    if tab == 't_lms_provision_dtls':
        dates = ['dt_provision','dt_lastupdated','dt_userdatetime','dt_old_installdue','dt_rbi_npa_date']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
    elif tab== 't_cs_address_details':
            dates = ['dt_user_datetime','dt_last_updated']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
    elif tab == 't_lms_repay_schedule':
        dates=['dt_installmentdue','dt_last_payment','dt_userdatetime','dt_bpi_date','dt_bpi_calc_upto']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
    elif tab == 't_lms_payment_header':
        dates = ['dt_lastupdated','dt_userdatetime','dt_payment_applied']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
    elif tab == 't_lms_payment_dtls':
        dates=['dt_userdatetime','dt_duedate','dt_payment']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
    elif tab == 't_lms_reschedule':
        dates = ['dt_transaction','dt_lastupdated','dt_userdatetime','dt_bpi_due']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
    elif tab == 't_cs_individual_details':
        dates = ['dt_date_of_birth','dt_nextrekyc','dt_user_datetime','dt_last_updated']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))     
    elif tab=='cn_collection':
        df = df.withColumn('PAYMENT_DATE', date_format(col('PAYMENT_DATE'), "yyyy-MM-dd HH:mm:ss"))
        
    
    if tab=='t_lms_payment_dtls':
        df.write \
            .format("io.github.spark_redshift_community.spark.redshift") \
            .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
            .option("dbtable", f"lms_stg.{tab}") \
            .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
            .option("postactions", f"CALL lms.sp_{tab}(); CAll lms.od_report_dail_load();") \
            .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
            .mode("overwrite") \
            .save()
        print(f'{table_number} . {tab} Redshift Data push successful ! ')
        print('STORED PROC CALL od_report_dail_load(); ""SUCCESSFULL"" ')
        
    elif tab=='cn_collection':
        df.write \
            .format("io.github.spark_redshift_community.spark.redshift") \
            .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user,r_pass)) \
            .option("preactions", f"Truncate table lms.cn_collection;")\
            .option("dbtable", f"lms.cn_collection") \
            .option("tempdir", f"s3://vistaar-lms-oracle/Full_load/temp/") \
            .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
            .mode("append") \
            .save()
        print(f'{table_number} . {tab} Redshift Data push successful ! ')

    else:
        df.write \
            .format("io.github.spark_redshift_community.spark.redshift") \
            .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
            .option("dbtable", f"lms_stg.{tab}") \
            .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
            .option("postactions", f"CALL lms.sp_{tab}(); ") \
            .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
            .mode("overwrite") \
            .save()
        print(f'{table_number} . {tab} Redshift Data push successful ! ')
    
   

