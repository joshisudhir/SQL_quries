import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_date
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')

tables = ['address_details', 'wf_t_notifications', 'tv_decision', 'tv_cust_buss_prop',
          'tv_cust_buss_partner', 'tv_cust_buss_branch_detail', 'tv_cust_buss_bank', 'tv_applicant_trc',
          'tv_applicant_rescpv', 'tv_applicant_busscpv', 'tv_app_buss_exp', 't_unsubmitted_application',
          't_topup_data', 't_subproduct_waiver', 't_request_header', 't_request_details', 't_reject_application_ded',
          't_reject_application', 't_receipt_entry_details', 't_mail_rcu', 't_loan_reference_details',
          't_loan_details', 't_lms_gstin_state', 't_legal_opinion', 't_instrument_details', 't_instrument_batch',
          't_initial_receipt_header', 't_initial_receipt_details', 't_ind_applicant_detail', 't_hunter_enquiry',
          't_gstin_state', 't_fee_waiver', 't_fee', 't_encollect_missing_lan', 't_encollect_download', 't_disb_req',
          't_disb_rel_benef', 't_disb_rel', 't_deviation_appr_level', 't_deviation', 't_cs_self_employment_details',
          't_cs_salary_income', 't_cs_individual_details', 't_cs_customer_details', 't_cs_address_xref',
          't_cs_address_details', 't_crs_asset_detail', 't_collateral_details', 't_coll_address', 'cms_cibil_status',
          't_close_rcu_dtls', 't_application_reflow', 't_application_collateral', 't_application_cfa',
          't_applicant_self_employment', 't_applicant_salary', 't_applicant_address', 't_applicant', 't_appl_cfa_dev_level',
          'prd_m_repayment', 'geo_m_level_value']

table_number = 0
for tab in tables:
    custom_query = f"""(SELECT * FROM vistaar_lsi.{tab} WHERE trunc(dt_last_updated) >= trunc(SYSDATE-1) ) custom_query_alias"""
    # WHERE dt_last_updated >= TO_TIMESTAMP('2024-03-11 16:00:00', 'YYYY-MM-DD HH24:MI:SS') AND dt_last_updated <= TO_TIMESTAMP('2024-03-15 01:35:00', 'YYYY-MM-DD HH24:MI:SS')

    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)

    table_number += 1
    if df.rdd.isEmpty():
        print(f"DataFrame is empty {tab}. No data to process.")
    else:
        df.repartition(1).write \
            .mode("overwrite") \
            .option("header", "true") \
            .option("delimiter", "|") \
            .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f' {table_number} Table {tab} is successful !!')
    
print("All Daily table Executed successfully !!!! ")
