import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_timestamp
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")


# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')
table_dict = {
    'T_DISB_REQ_BENEF': 'DT_LAST_UPDATED',
    'T_LMS_DISB_DTLS': 'DT_LASTUPDATED',
    'T_LMS_DUE_DTLS': 'DT_LASTUPDATED',
    'T_LMS_LOAN_ACCOUNT': 'DT_USERDATETIME',
    'T_LMS_LOAN_REFERENCES': 'DT_USERDATETIME',
    'T_LMS_PAYMENT_DTLS': 'DT_USERDATETIME',
    'T_LMS_PAYMENT_HEADER': 'DT_LASTUPDATED',
    'T_LMS_REPAY_SCHEDULE': 'DT_USERDATETIME',
    'T_LMS_TRANCHE_DISB_REF': 'DT_USERDATETIME',
    'T_LMS_TRANCHE_SCH_PARAM': 'DT_LASTUPDATED'
}

table_number=0
for tab,iden in table_dict.items():
    custom_query = f"""(SELECT * FROM vistaar_lsi.{tab} WHERE {iden} >= (SYSDATE)-1) custom_query_alias"""
    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)
    
    table_number+=1
    if df.rdd.isEmpty():
        print(f"Table {tab} is empty. No data to process.")
    else:
        df.repartition(1).write \
        .mode("overwrite") \
        .option("header", "true") \
        .option("delimiter", "|") \
        .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f' {table_number} Table {tab} is successfull !!' )
        
print("All Daily table Executed succesfull !!!! ")
        
    

