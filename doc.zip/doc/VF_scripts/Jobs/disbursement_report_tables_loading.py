import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_date, to_timestamp
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

r_user = 'vf_admin'
r_pass = 'Vfadmin@12345'

# 'base_org_mst_businessunit', 'org_m_level_value',

redshift_tbl = ['t_lms_disb_dtls', 't_lms_loan_account', 't_cs_customer_details', 't_application', 't_lms_tranche_dtls', 'wf_t_notifications_hist', 't_lms_product_dtls', 't_lms_tranche_disb_ref']

table_number = 0
for tab in redshift_tbl:
    if tab == 't_lms_disb_dtls':
        custom_query = f"""(SELECT * FROM vistaar_lsi.t_lms_disb_dtls WHERE dt_disbursement >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) or dt_userdatetime >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) or dt_cancelsdatetime >= trunc(sysdate) ) custom_query_alias"""
    elif tab == 't_lms_loan_account':
        custom_query = f"""(Select * from vistaar_lsi.t_lms_loan_account WHERE dt_lastupdated >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) or dt_userdatetime >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) ) custom_query_alias"""
    elif tab == 't_cs_customer_details':
        custom_query = f"""(SELECT distinct c.* FROM vistaar_lsi.t_cs_customer_details c
                    left join vistaar_lsi.t_lms_loan_references l on c.sz_customer_no =l.sz_customer_no 
                    WHERE  l.DT_USERDATETIME >=(CURRENT_TIMESTAMP - INTERVAL '150' minute))  custom_query_alias"""
    elif tab == 't_application':
        custom_query = f"""(Select * from vistaar_lsi.t_application WHERE dt_last_updated >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) or dt_creation >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) ) custom_query_alias"""
    elif tab == 't_lms_tranche_dtls':
        custom_query = f"""(Select * from vistaar_lsi.t_lms_tranche_dtls where dt_userdatetime >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) or dt_lastupdated >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) ) custom_query_alias"""
    elif tab == 'wf_t_notifications_hist':
        custom_query = f"""(Select * from vistaar_lsi.wf_t_notifications_hist WHERE dt_last_updated >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) or dt_user_datetime >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) ) custom_query_alias"""
    elif tab == 't_lms_product_dtls':
        custom_query = f"""(Select * from vistaar_lsi.t_lms_product_dtls WHERE dt_userdatetime >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) or dt_lastupdated >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) ) custom_query_alias"""
    elif tab == 't_lms_tranche_disb_ref':
        custom_query = f"""(Select * from vistaar_lsi.t_lms_tranche_disb_ref WHERE dt_userdatetime >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)) custom_query_alias"""
    # else:
        # custom_query = f"""(SELECT * FROM vistaar_lsi.{tab} ) custom_query_alias"""
    
    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)

    table_number += 1
    if df.rdd.isEmpty():
        print(f"DataFrame is empty {tab}. No data to process.")
    else:
        df.write \
            .mode("overwrite") \
            .option("header", "true") \
            .option("delimiter", "|") \
            .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f' {table_number} Table {tab}  S3 uploaded successfully!!')

    if tab == 't_lms_disb_dtls':
        dates = ['dt_disbursement', 'dt_lastupdated', 'dt_userdatetime', 'dt_installment_start', 'dt_cancelsdatetime', 'dt_bpi_due']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))
    elif tab == 't_lms_loan_account':
        dates = ['dt_status_change', 'dt_lastupdated', 'dt_userdatetime', 'dt_next_installment', 'dt_last_prov', 'dt_revised_next_due', 'dt_previous_inst_due', 'dt_last_transaction', 'dt_revised_prev_due', 'dt_restructure', 'dt_dep_return', 'dt_nxt_billing', 'dt_pre_billing', 'dt_first_due', 'dt_morat_st', 'dt_morat_end', 'dt_submission']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))
    elif tab == 't_cs_customer_details':
        dates = ['dt_statusat', 'dt_user_datetime', 'dt_last_updated']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))
    elif tab == 't_application':
        dates = ['dt_creation', 'dt_submission', 'dt_user_datetime', 'dt_last_updated', 'dt_field1', 'dt_field2', 'dt_field3', 'dt_lpo_print_date', 'dt_lpo_rcv_date', 'dt_cashflow_start', 'dt_cashflow_end']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))
    elif tab == 't_lms_tranche_dtls':
        dates = ['dt_installment_start', 'dt_lastupdated', 'dt_userdatetime', 'dt_schedule_gen', 'dt_last_penal_calculated', 'dt_grace_period_end', 'dt_last_int_accr_computed', 'dt_next_idx_review', 'dt_last_billing_date', 'dt_last_grace_int_calc', 'dt_dep_return']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))            
    elif tab == 'wf_t_notifications_hist':
        dates = ['sz_start_time', 'dt_escalation_claim', 'dt_escalation_complete', 'dt_defer_time', 'dt_sla_complete', 'dt_user_datetime', 'dt_last_updated', 'dt_activity_start', 'dt_activity_end']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))            
    elif tab == 't_lms_product_dtls':
        dates = ['dt_lastupdated', 'dt_userdatetime']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))            
    elif tab == 't_lms_tranche_disb_ref':
        df = df.withColumn('dt_userdatetime', to_date('dt_userdatetime'))            
    if tab=='t_lms_product_dtls':
        df.write \
        .format("io.github.spark_redshift_community.spark.redshift") \
        .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
        .option("dbtable", f"lms_stg.{tab}") \
        .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
        .option("postactions", f"CALL lms.sp_{tab}(); CALL lms.disbursement_dail_load();") \
        .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
        .mode("overwrite") \
        .save()
    
    df.write \
        .format("io.github.spark_redshift_community.spark.redshift") \
        .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
        .option("dbtable", f"lms_stg.{tab}") \
        .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
        .option("postactions", f"CALL lms.sp_{tab}();") \
        .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
        .mode("overwrite") \
        .save()
    print(f'{table_number} . {tab} Redshift Data push successful ! ')

print("All Daily table Executed successfully !!!! ")
