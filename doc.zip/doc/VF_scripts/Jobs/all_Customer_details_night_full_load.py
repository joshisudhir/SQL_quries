import boto3
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date,to_timestamp

# Initialize GlueContext and SparkSession
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

# added by vidyasagar on 15-05-2024 to call stored proc in redshift
# redshift configuration and connection
source_jdbc_conf = glueContext.extract_jdbc_conf('Redshift_connection')
from py4j.java_gateway import java_import
java_import(sc._gateway.jvm,"java.sql.Connection")
java_import(sc._gateway.jvm,"java.sql.DatabaseMetaData")
java_import(sc._gateway.jvm,"java.sql.DriverManager")
java_import(sc._gateway.jvm,"java.sql.SQLException")

print('Trying to connect to DB')
conn = sc._gateway.jvm.DriverManager.getConnection('jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod', 'vf_admin', 'Vfadmin@12345')

print('Trying to connect to DB success!')

print(conn.getMetaData().getDatabaseProductName())

# call stored procedure
stmt = conn.createStatement();
#cstmt = conn.prepareCall("call dbname.schemaname.my_storedproc();");

cp_T_CS_CUSTOMER_DETAILS = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "i_address_seq",
    "lowerBound" : "1",
    "upperBound" :"8500000",
    "numPartitions": "20"
}
cp_T_CS_INDIVIDUAL_DETAILS= {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}
cp_T_CS_ADDRESS_DETAILS= {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "i_address_seq",
    "lowerBound" : "1",
    "upperBound" :"11000000",
    "numPartitions": "20"
}
s3 = boto3.client('s3', region_name='ap-south-1')

redshift_tbl = {'T_CS_CUSTOMER_DETAILS': cp_T_CS_CUSTOMER_DETAILS, 'T_CS_INDIVIDUAL_DETAILS': cp_T_CS_INDIVIDUAL_DETAILS, 'T_CS_ADDRESS_DETAILS': cp_T_CS_ADDRESS_DETAILS}



tab_num=0
for tab, cp in redshift_tbl.items():
    try:
        df = spark.read.jdbc(url=jdbc_url, table=f'VISTAAR_LSI.{tab}', properties=cp)
        if  tab=='T_CS_CUSTOMER_DETAILS':
             dates = ['dt_user_datetime','dt_last_updated']
             df=df.withColumn('dt_statusat',to_timestamp(col('dt_statusat')))
             for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab=='T_CS_INDIVIDUAL_DETAILS':
            dates = ['dt_date_of_birth','dt_nextrekyc']
            df=df.withColumn('DT_LAST_UPDATED',to_timestamp(col('DT_LAST_UPDATED')))
            df=df.withColumn('DT_USER_DATETIME',to_timestamp(col('DT_USER_DATETIME')))
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab== 'T_CS_ADDRESS_DETAILS':
            dates = ['dt_user_datetime','dt_last_updated']
            for date in dates:
                df=df.withColumn(date,to_timestamp(col(date)))
        tab_num+=1
        print(f'{tab_num} . spark.read.jdbc Succesfull for {tab}')
        
        s3_path = f"s3://vistaar-lms-oracle/Every_night_full_load/{tab}/"
        if tab== 'T_CS_INDIVIDUAL_DETAILS':
            df.write \
                .mode("overwrite") \
                .format("csv") \
                .option("header", "true") \
                .option("delimiter", "|") \
                .save(s3_path)
            print(f"{tab_num}. '{tab}' is successfully uploaded to S3 at '{s3_path}.' ")
            print(f'Call to proc on {tab} trying ')
            stmt.executeUpdate(f'call lms.sp_night_full_load_{tab}_from_s3()');
            print(f'Called stored proc on {tab} is successful. ')
            
        else:
            df.write \
                .mode("overwrite") \
                .format("parquet") \
                .option("header", "true") \
                .save(s3_path)
            print(f"{tab_num}. '{tab}' is successfully uploaded to S3 at '{s3_path}.' ")
            print(f'Call to proc on {tab} trying ')
            stmt.executeUpdate(f'call lms.sp_night_full_load_{tab}_from_s3()');
            print(f'Called stored proc on {tab} is successful. ')
    except Exception as e:
            print(f"Error processing table {tab}: {str(e)}")

conn.close()