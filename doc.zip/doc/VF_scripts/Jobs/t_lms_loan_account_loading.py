import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_date,to_timestamp
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

r_user = 'vf_admin'
r_pass = 'Vfadmin@12345'

redshift_tbl = ['t_application','t_lms_loan_account','wf_t_notifications_hist','t_lms_chg_booking_dtls','t_lms_payment_dtls','t_lms_payment_header','t_lms_instruments','t_lms_provision_dtls','t_lms_repay_schedule','t_lms_due_dtls']

table_number = 0
for tab in redshift_tbl:
    if tab == 't_application':
        custom_query = f"""(SELECT * FROM vistaar_lsi.t_application WHERE trunc(dt_last_updated) >= trunc(sysdate-1) or trunc(dt_creation) >= trunc(sysdate-1) ) custom_query_alias"""
        
    elif tab == 't_lms_loan_account':
        custom_query = f"""(SELECT * FROM vistaar_lsi.t_lms_loan_account WHERE trunc(dt_lastupdated) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1) ) custom_query_alias"""
        
    elif tab == 'wf_t_notifications_hist':
        custom_query= f"""(SELECT * FROM vistaar_lsi.wf_t_notifications_hist WHERE trunc(dt_last_updated) >= trunc(sysdate-1) or trunc(dt_user_datetime) >= trunc(sysdate-1) ) custom_query_alias"""
        
    elif tab == 't_lms_chg_booking_dtls':
        custom_query = f"""(SELECT * from vistaar_lsi.t_lms_chg_booking_dtls WHERE trunc(dt_lastupdated) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1)) custom_query_alias"""
        
    elif tab == 't_lms_payment_dtls':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_payment_dtls WHERE trunc(dt_payment) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1) ) custom_query_alias"""

    elif tab == 't_lms_payment_header':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_payment_header WHERE trunc(dt_lastupdated) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1) ) custom_query_alias"""

    elif tab == 't_lms_instruments':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_instruments WHERE trunc(dt_lastupdated) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1) ) custom_query_alias"""
        
    elif tab == 't_lms_provision_dtls':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_provision_dtls WHERE trunc(dt_lastupdated) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1)) custom_query_alias"""
        
    elif tab == 't_lms_repay_schedule':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_repay_schedule WHERE trunc(dt_last_payment) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1) ) custom_query_alias"""
        
    elif tab == 't_lms_due_dtls':
        custom_query= f"""(SELECT * FROM vistaar_lsi.t_lms_due_dtls WHERE trunc(dt_lastupdated) >= trunc(sysdate-1) or trunc(dt_userdatetime) >= trunc(sysdate-1) ) custom_query_alias"""
    
    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)

    table_number += 1
    if df.rdd.isEmpty():
        print(f"DataFrame is empty {tab}. No data to process.")
    else:
        df.write \
            .mode("overwrite") \
            .option("header", "true") \
            .option("delimiter", "|") \
            .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f' {table_number} Table {tab} is successful !!')
     
     
    if tab == 't_application':
        dates = ['dt_creation','dt_submission','dt_user_datetime','dt_last_updated','dt_field1','dt_field2','dt_field3','dt_lpo_print_date','dt_lpo_rcv_date','dt_cashflow_start','dt_cashflow_end']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))  

    elif tab == 't_lms_loan_account':
        dates = ['dt_status_change','dt_lastupdated','dt_userdatetime','dt_next_installment','dt_last_prov','dt_revised_next_due','dt_previous_inst_due','dt_last_transaction','dt_revised_prev_due','dt_restructure','dt_dep_return','dt_nxt_billing','dt_pre_billing','dt_first_due','dt_morat_st','dt_morat_end','dt_submission']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
            
    elif tab == 'wf_t_notifications_hist':
        dates = ['sz_start_time','dt_escalation_claim','dt_escalation_complete','dt_defer_time','dt_sla_complete','dt_user_datetime','dt_last_updated','dt_activity_start','dt_activity_end']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))

    elif tab == 't_lms_chg_booking_dtls':
        dates = ['dt_chg_booked','dt_lastupdated','dt_userdatetime']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))

    elif tab == 't_lms_payment_dtls':
        dates=['dt_userdatetime','dt_duedate','dt_payment']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
        
    elif tab == 't_lms_payment_header':
        dates = ['dt_lastupdated','dt_userdatetime','dt_payment_applied']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
        
    elif tab == 't_lms_instruments':
        dates =['dt_instrument','dt_value','dt_lastupdated','dt_userdatetime','dt_installment']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
        
    elif tab == 't_lms_provision_dtls':
        dates = ['dt_provision','dt_lastupdated','dt_userdatetime','dt_old_installdue','dt_rbi_npa_date']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
            
    elif tab == 't_lms_repay_schedule':
        dates=['dt_installmentdue','dt_last_payment','dt_userdatetime','dt_bpi_date','dt_bpi_calc_upto']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
        
    elif tab == 't_lms_due_dtls':
        dates = ['dt_lastupdated','DT_USERDATETIME']
        df=df.withColumn('dt_duedate',to_date(col('dt_duedate')))
        for date in dates:
            df = df.withColumn(date, to_timestamp(col(date)))
        
    df.write \
        .format("io.github.spark_redshift_community.spark.redshift") \
        .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
        .option("dbtable", f"lms_stg.{tab}") \
        .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
        .option("postactions", f"CALL lms.sp_{tab}();") \
        .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
        .mode("overwrite") \
        .save()
    print(f'{table_number} . {tab} Redshift Data push successfull ! ')

print("All Daily table Executed successfully !!!! ")
