import boto3
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date,to_timestamp
from datetime import datetime

# Initialize GlueContext and spark_session
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

cp_BASE_APP_MST_LOOKUPS = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "IORDER",
    "lowerBound": "1",
    "upperBound": "20",
    "numPartitions": "8"
}

cp_BASE_SEC_MST_SYSTEMUSER = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "ISESSION_FAILED_LOGON_ATTEMPTS",
    "lowerBound": "0",
    "upperBound": "25",
    "numPartitions": "8"
}

todays_date = datetime.now().strftime("%Y-%m-%d")

# redshift configuration and connection
source_jdbc_conf = glueContext.extract_jdbc_conf('Redshift_connection')
from py4j.java_gateway import java_import
java_import(sc._gateway.jvm,"java.sql.Connection")
java_import(sc._gateway.jvm,"java.sql.DatabaseMetaData")
java_import(sc._gateway.jvm,"java.sql.DriverManager")
java_import(sc._gateway.jvm,"java.sql.SQLException")

print('Trying to connect to Redshift DB')
conn = sc._gateway.jvm.DriverManager.getConnection('jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod', 'vf_admin', 'Vfadmin@12345')

print('Trying to connect to Redshift DB success!')

print(conn.getMetaData().getDatabaseProductName())

# call stored procedure
stmt = conn.createStatement();

      
s3 = boto3.client('s3', region_name='ap-south-1')

table_dict = {
    'BASE_APP_MST_LOOKUPS':'VISTAAR_ACE',
    'BASE_SEC_MST_SYSTEMUSER':'VISTAAR_ACE'
}


for table,schema in table_dict.items():
    try:
        
        if table == 'BASE_APP_MST_LOOKUPS':
            df = spark.read.jdbc(url=jdbc_url, table=f"{schema}.{table}", properties=cp_BASE_APP_MST_LOOKUPS)
            df=df.withColumn('DTUPDTIMESTAMP',to_timestamp(col('DTUPDTIMESTAMP')))
            
        elif table == 'BASE_SEC_MST_SYSTEMUSER':
            df = spark.read.jdbc(url=jdbc_url, table=f"{schema}.{table}", properties=cp_BASE_SEC_MST_SYSTEMUSER)
            time_stamps_list = ['DTACTIVE_UNTILL', 'DTLAST_PASSWORD_CHANGE', 'DTLAST_LOGIN', 'DTLAST_LOGOUT', 'DTINVALID_ATTEMPT', 'DTFIELD1', 'DTFIELD2', 'DTFIELD3', 'DTMODIFIED_ON', 'DTENABLED', 'DTDISABLE_ON', 'DTFIELD4', 'DTFIELD5']
            for coulumn in time_stamps_list:
                df=df.withColumn(coulumn,to_timestamp(col(coulumn)))
                
        if df.rdd.isEmpty():
            print(f"Table {table} is empty. No data to process.")
        else:
            s3_path = f"s3://vistaar-lms-oracle/Every_night_full_load/{table}"
            df.write.mode("overwrite").format("parquet").option("header", "true").save(s3_path)
            print(f"Table '{table}' is successfully uploaded to S3 at '{s3_path}.' ")
            print(f'Call to stored proc on {table} trying ')
            stmt.executeUpdate(f'call lms.sp_night_full_load_{table}_from_s3()');
            print(f'Call to proc on {table} is successful. ') 
            
    except Exception as e:
        print(f"Error processing table {table}: {str(e)}")
        
             
