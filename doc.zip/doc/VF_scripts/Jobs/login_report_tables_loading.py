import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_date,to_timestamp
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

r_user = 'vf_admin'
r_pass = 'Vfadmin@12345'
# base_app_mst_lookups','base_sec_mst_systemuser'
# 't_applicant','t_applicant_address','t_application_cfa',
redshift_tbl = ['t_applicant','t_applicant_address','t_application_cfa','t_application_fee','t_application_spl_attrib',
't_ind_applicant_detail','t_loan_details','t_reject_application','wf_t_notifications']


table_number = 0
for tab in redshift_tbl:
    if tab == 't_applicant':
        custom_query = f"""(SELECT * FROM vistaar_lsi.t_applicant WHERE (dt_last_updated) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  or (dt_user_datetime) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  ) custom_query_alias"""
        
    elif tab=='t_applicant_address':
        custom_query=f"""(Select * from vistaar_lsi.t_applicant_address WHERE (dt_last_updated) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  or (DT_USER_DATETIME) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  ) custom_query_alias"""
        
    elif tab=='t_application_cfa':
        custom_query=f"""(Select * from vistaar_lsi.t_application_cfa WHERE (dt_last_updated) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  or (DT_USER_DATETIME) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  ) custom_query_alias"""
        
    elif tab=='t_application_fee':
        custom_query=f"""(Select * from vistaar_lsi.t_application_fee WHERE (dt_lastupdated) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  or (DT_USERDATETIME) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  ) custom_query_alias"""
    
    elif tab=='t_application_spl_attrib':
        custom_query=f"""(Select * from vistaar_lsi.t_application_spl_attrib where (DT_STS_LAST_UPDATED) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  ) custom_query_alias"""
        
    elif tab=='t_ind_applicant_detail':
        custom_query=f"""(Select * from vistaar_lsi.t_ind_applicant_detail WHERE (dt_last_updated) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  or (DT_USER_DATETIME) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  ) custom_query_alias"""
    
    elif tab=='t_loan_details':
        custom_query=f"""(Select * from vistaar_lsi.t_loan_details WHERE (dt_last_updated) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  or (DT_USER_DATETIME) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  ) custom_query_alias"""
        
    elif tab=='t_reject_application':
        custom_query=f"""(Select distinct r.* from vistaar_lsi.t_reject_application r 
                            JOIN vistaar_lsi.t_application_spl_attrib s on r.sz_application_no = s.sz_application_no 
                            where (s.DT_STS_LAST_UPDATED) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute) ) custom_query_alias"""
        
    elif tab=='wf_t_notifications':
        custom_query=f"""(Select * from vistaar_lsi.wf_t_notifications WHERE (dt_last_updated) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)  or (DT_USER_DATETIME) >= (CURRENT_TIMESTAMP - INTERVAL '150' minute)   ) custom_query_alias"""
    
    
    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)

    table_number += 1
    if df.rdd.isEmpty():
        print(f"DataFrame is empty {tab}. No data to process.")
    else:
        df.write \
            .mode("overwrite") \
            .option("header", "true") \
            .option("delimiter", "|") \
            .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f' {table_number} Table {tab}  S3 uploaded successfull!!')

    if tab == 'base_app_mst_lookups':
        df=df.withColumn('DTUPDTIMESTAMP',to_timestamp(col('DTUPDTIMESTAMP')))
        
    elif tab == 'base_sec_mst_systemuser':
        dates = ['DTACTIVE_UNTILL','DTLAST_PASSWORD_CHANGE','DTLAST_LOGIN','DTLAST_LOGOUT','DTINVALID_ATTEMPT','DTFIELD1','DTFIELD2','DTFIELD3','DTMODIFIED_ON','DTENABLED','DTDISABLE_ON','DTFIELD4','DTFIELD5']
        for date in dates:
            df=df.withColumn(date,to_timestamp(col(date)))
            
    elif tab == 't_applicant':
        dates=['DT_ID1_VALID_TILL','DT_ID2_VALID_TILL','DT_ID3_VALID_TILL','DT_INTERNAL_VER_DONE_DATE','DT_FI_DONE_DATE','DT_ID4_VALID_TILL','DT_MEMBERSHIP_DATE']
        ts= ['DT_USER_DATETIME','DT_LAST_UPDATED']
        for date in dates:
            df=df.withColumn(date,to_date(col(date)))
        for ts in ts:
            df=df.withColumn(ts,to_timestamp(col(ts)))
    elif tab == 't_applicant_address':
        dates=['DT_USER_DATETIME','DT_LAST_UPDATED']
        for date in dates:
            df=df.withColumn(date,to_timestamp(col(date)))
        
    elif tab == 't_application_cfa':
        ts = ['DT_USER_DATETIME','DT_LAST_UPDATED']
        dates=['DT_CASHFLOW_DATE']
        for date in dates:
            df = df.withColumn(date, to_date(col(date)))
        for ts in ts:
            df = df.withColumn(ts, to_timestamp(col(ts)))
            
    elif tab == 't_application_fee':
        dates = ['DT_USERDATETIME','DT_LASTUPDATED']
        for date in dates:
            df = df.withColumn(date, to_timestamp(col(date)))
            
    elif tab == 't_application_spl_attrib':
        dates = ['DT_STS_LAST_UPDATED','DT_PRI_LAST_UPDATED']
        for date in dates:
            df = df.withColumn(date, to_timestamp(col(date)))
            
    elif tab == 't_ind_applicant_detail':
        ts = ['DT_USER_DATETIME','DT_LAST_UPDATED']
        date = ['DT_BIRTH_DATE','DT_FIELD1','DT_FIELD2','DT_FIELD3','DT_FIELD4','DT_FIELD5','DT_AS_ON_DATE','DT_NEXTREKYC']
        for d in date:
            df = df.withColumn(d, to_date(col(d)))
        for ts in ts:
            df = df.withColumn(ts, to_timestamp(col(ts)))
            
    elif tab == 't_loan_details':
        ts = ['DT_USER_DATETIME','DT_LAST_UPDATED']
        date = ['DT_FIELD1','DT_FIELD2','DT_DOWN_PAY_RECEIPT']
        for d in date:
            df = df.withColumn(d, to_date(col(d)))
        for ts in ts:
                df = df.withColumn(ts, to_timestamp(col(ts)))
    # t_reject_application No dates 
    elif tab == 'wf_t_notifications':
        ts = ['DT_ESCALATION_CLAIM','DT_ESCALATION_COMPLETE','DT_USER_DATETIME','DT_LAST_UPDATED','DT_CREATION','DT_SUBMISSION','DT_BEGIN_DATE']
        date = ['SZ_START_TIME','DT_DEFER_TIME','DT_SLA_COMPLETE','DT_ACTIVITY_START','DT_ACTIVITY_END']
        for d in date:
            df = df.withColumn(d, to_date(col(d)))
        for ts in ts:
            df = df.withColumn(ts, to_timestamp(col(ts)))
    if tab=='wf_t_notifications':
        df.write \
            .format("io.github.spark_redshift_community.spark.redshift") \
            .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
            .option("dbtable", f"lms_stg.{tab}") \
            .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
            .option("postactions", f"CALL lms.sp_{tab}(); CALL lms.login_daily_load();") \
            .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
            .mode("overwrite") \
            .save()
        print(f'{table_number} . {tab} Redshift Data push successfull ! ')
    else:
        df.write \
            .format("io.github.spark_redshift_community.spark.redshift") \
            .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
            .option("dbtable", f"lms_stg.{tab}") \
            .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
            .option("postactions", f"CALL lms.sp_{tab}();") \
            .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
            .mode("overwrite") \
            .save()
    print(f'{table_number} . {tab} Redshift Data push successfull ! ')

print("All Daily table Executed successfully !!!! ")
