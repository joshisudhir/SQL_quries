import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,to_date,to_timestamp
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext  and spark_session
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

# redshift configuration and connection
source_jdbc_conf = glueContext.extract_jdbc_conf('Redshift_connection')
from py4j.java_gateway import java_import
java_import(sc._gateway.jvm,"java.sql.Connection")
java_import(sc._gateway.jvm,"java.sql.DatabaseMetaData")
java_import(sc._gateway.jvm,"java.sql.DriverManager")
java_import(sc._gateway.jvm,"java.sql.SQLException")

print('Trying to connect to Redshift DB')
conn = sc._gateway.jvm.DriverManager.getConnection('jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod', 'vf_admin', 'Vfadmin@12345')

print('Trying to connect to Redshift DB success!')

print(conn.getMetaData().getDatabaseProductName())

# call stored procedure
stmt = conn.createStatement();

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "I_INSTALLMENT_NO",
    "lowerBound" : "0",
    "upperBound" :"366",
    "numPartitions": "36"
}
s3 = boto3.client('s3', region_name='ap-south-1')
r_user = 'vf_admin'
r_pass = 'Vfadmin@12345'

redshift_tbl = ['T_LMS_REPAY_SCHEDULE']
table_number = 0
for tab in redshift_tbl:
    df = spark.read.jdbc(url=jdbc_url, table=f'VISTAAR_LSI.{tab}', properties=connection_properties)
    dates=['dt_installmentdue','dt_last_payment','dt_bpi_date','dt_bpi_calc_upto']
    df=df.withColumn('DT_USERDATETIME',to_timestamp(col('DT_USERDATETIME'))) 
    for date in dates:
         df=df.withColumn(date,to_date(col(date))) 
    table_number += 1
    if df.rdd.isEmpty():
            print(f"Table {tab} is empty. No data to process.")
    else:
        s3_path = f"s3://vistaar-lms-oracle/Every_night_full_load/{tab}"
        df.write \
            .mode("overwrite") \
            .format("parquet") \
            .option("header", "true") \
            .save(s3_path)
        print(f"Table '{tab}' is successfully uploaded to S3 at '{s3_path}.' ")
        print(f'Call to stored proc on {tab} trying ')
        stmt.executeUpdate(f'call lms.sp_night_full_load_{tab}_from_s3()');
        print(f'Call stored proc on {tab} is successful. ')

conn.close()