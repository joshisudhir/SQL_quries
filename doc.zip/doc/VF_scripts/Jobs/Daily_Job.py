import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,to_date
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")

# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')
table_dict = {
    'BASE_ADT_TRN_INCREMENTS': 'DTMODIFIEDON',
    'BASE_ADT_TRN_SNAPSHOT': 'DTMODIFIEDON',
    'BASE_AST_MST_SETTINGS': 'DTMODIFIED_ON',
    'BASE_SEC_MST_PROFILE': 'DTMODIFIED_ON',
    'BASE_SEC_MST_PROFILE_DETAILS': 'DTMODIFIED_ON',
    'BASE_SEC_MST_SYSTEMUSER': 'DTMODIFIED_ON',
    'BASE_UDF_MST_EXTENTSION': 'DTMODIFIED_ON',
    'EXT_ADDRESS_DETAILS': 'DTLASTUPDATED',
    'T_APP_RCU_CHK_INFO': 'DTUPDATEDON',
    'T_APPLICATION_SPL_ATTRIB': 'dt_sts_last_updated',
    'T_APPLICATION_STATUSES': 'dt_sts_last_updated',
    'T_BRANCHLEVELREC': 'DT_UPDATE',
    'T_EPIK_FEE_DTLS': 'DT_DATETIME',
    'T_JOB_EXECUTION': 'DT_LAST_UPDATE',
    'T_LMS_PREPAYMENT_PAYDTLS': 'DT_USERDATETIME',
    'T_LMS_PREPAYMENT_SIM': 'DT_USERDATETIME',
    'T_LMS_TRAN_ADDITIONAL_DTLS': 'DT_USERDATETIME',
    'T_LMS_TRAN_HEADER': 'DT_USERDATETIME',
    'T_LOS_LOAN_TRACK_RECORD': 'DT_USERDATETIME',
    'T_RELEASE_DATA': 'DT_BUISNESS_DATE',
    'T_REPAYMENT_DETAILS': 'DT_USER_DATETIME',
    'T_VALUATION_PAYOUT_DETAILS': 'DT_LAST_UPDATE',
    'T_WFW_NOTIFICATIONS': 'DT_USER_DATETIME',
    'TR_CIBIL_CTC_RESPONSE': 'DTLASTUPDATED',
    'TR_CIBIL_CTC_TURF_SC': 'DTLASTUPDATED',
    'TR_COL_OWNERSHIPDET': 'DTLASTUPDATED',
    'TR_COLL_LOAN_MAP': 'DTLASTUPDATED',
    'TR_COLLATERAL_MASTER': 'DTLASTUPDATED',
    'TR_DYN_CUSTOMERDETAILS': 'DTLASTUPDATED',
    'T_LMS_TAX_CHGBOOKING': 'DT_LASTUPDATED',
    'T_LMS_TAX_CHGWAIVER': 'DT_LASTUPDATED',
    # 'T_ADHOC_HIGHMARK_REQ': 'LAST_UPDATED_DATE',
    'T_COLL_VISIT': 'DT_SUBMISSION',
    'T_LMS_WRITEOFF_DTLS': 'DT_LASTUPDATED',
    't_lms_tranche_disb_ref': 'DT_USERDATETIME',
    't_lms_disb_dtls':'DT_DISBURSEMENT', #identifier changes as null values 
    't_cs_individual_details':'DT_USERDATETIME',
    't_cs_customer_details':'DT_USERDATETIME',
    't_cs_address_details':'DT_USERDATETIME',
    't_lms_tranche_dtls':'DT_USERDATETIME',
    't_lms_product_dtls':'DT_USERDATETIME',
    't_lms_loan_references' : 'DT_USERDATETIME'
}

r_user = 'vf_admin'
r_pass = 'Vfadmin@12345'
redshift_tbl = ['t_lms_tranche_disb_ref','t_lms_disb_dtls','t_cs_customer_details','t_cs_individual_details','t_cs_address_details','t_lms_product_dtls','t_lms_tranche_dtls','t_lms_loan_references']

table_number = 0
for tab, iden in table_dict.items():
    if tab == 'T_COLL_VISIT':
        custom_query = f"""(select distinct c.* from VISTAAR_LSI.T_COLL_VISIT c left join
        VISTAAR_LSI.T_APPLICATION a on c.SZ_APPLICATION_NO=a.SZ_APPLICATION_NO 
        where trunc(DT_SUBMISSION) >= trunc(SYSDATE-1)) custom_query_alias"""
        
    elif tab == 'T_LMS_TAX_CHGBOOKING':
        custom_query = f"""(SELECT distinct c.* FROM VISTAAR_LSI.T_LMS_TAX_CHGBOOKING c left join 
        VISTAAR_LSI.t_lms_chg_booking_dtls b on c.sz_loan_account_no =b.sz_loan_account_no 
        where trunc(DT_LASTUPDATED) >= trunc(SYSDATE-1)  and c.I_CHGBOOKTRAN_ID=b.I_CHGBOOKTRAN_ID ) custom_query_alias"""
        
    elif tab == 'T_LMS_TAX_CHGWAIVER':
        custom_query = f"""(SELECT distinct c.* FROM VISTAAR_LSI.T_LMS_TAX_CHGWAIVER  c left join 
        VISTAAR_LSI.t_lms_chg_waiver_dtls w on c.sz_loan_account_no =w.sz_loan_account_no 
        where trunc(DT_LASTUPDATED) >= trunc(SYSDATE-1 )) custom_query_alias"""
        
    # elif tab == 'T_LMS_TAXDUE_DTLS':
    #     custom_query = f"""(SELECT c.* FROM VISTAAR_LSI.T_LMS_TAXDUE_DTLS  c left join VISTAAR_LSI.t_lms_due_dtls h on c.sz_loan_account_no =h.sz_loan_account_no where trunc(DT_LASTUPDATED) >= trunc(SYSDATE-1)  and c.I_SRNO=h.I_SRNO ) custom_query_alias"""
    elif tab == 'T_LMS_WRITEOFF_DTLS':
        custom_query = f"""(SELECT distinct c.* FROM VISTAAR_LSI.T_LMS_WRITEOFF_DTLS  c left join VISTAAR_LSI.t_lms_writeoff_header h on c.sz_loan_account_no =h.sz_loan_account_no   where trunc(DT_LASTUPDATED) >=trunc(SYSDATE-1 )) custom_query_alias"""
        
    elif tab =='t_cs_individual_details':
        custom_query = f"""(SELECT distinct c.* FROM vistaar_lsi.t_cs_individual_details c
                    left join vistaar_lsi.t_lms_loan_references l on c.sz_customer_no =l.sz_customer_no 
                    WHERE  trunc(l.DT_USERDATETIME) >=trunc(SYSDATE-1))  custom_query_alias"""
                    
    elif tab == 't_cs_customer_details':
        custom_query = f"""(SELECT distinct c.* FROM vistaar_lsi.t_cs_customer_details c
                    left join vistaar_lsi.t_lms_loan_references l on c.sz_customer_no =l.sz_customer_no 
                    WHERE  trunc(l.DT_USERDATETIME) >=trunc(SYSDATE-1))  custom_query_alias"""
                    
    elif tab == 't_cs_address_details':
        custom_query = f"""(SELECT distinct a.* FROM vistaar_lsi.t_cs_customer_details c
                    left join vistaar_lsi.t_lms_loan_references l on c.sz_customer_no =l.sz_customer_no 
                    left join vistaar_lsi.t_cs_address_details a on c.i_address_seq=a.i_address_seq
                    WHERE  trunc(l.DT_USERDATETIME) >=trunc(SYSDATE-1))  custom_query_alias"""
                    
    elif tab == 't_lms_disb_dtls':
        custom_query = f"""(Select distinct * from vistaar_lsi.t_lms_disb_dtls where trunc(dt_userdatetime) >= trunc(sysdate-1) or trunc(dt_lastupdated) >= trunc(sysdate-1))"""
    
    elif tab == 't_lms_loan_references':
        custom_query = f"""(Select distinct * from vistaar_lsi.t_lms_loan_references where dt_userdatetime >= trunc(sysdate-1))"""
        
    elif tab =='t_lms_tranche_dtls':
        custom_query = f"""(Select distinct * from vistaar_lsi.t_lms_tranche_dtls where trunc(dt_userdatetime) >= trunc(sysdate-1) or trunc(dt_lastupdated) >= trunc(sysdate-1))"""
        
    elif tab =='t_lms_product_dtls':
        custom_query = f"""(Select distinct * from vistaar_lsi.t_lms_product_dtls where trunc(dt_userdatetime) >= trunc(sysdate-1) or trunc(dt_lastupdated) >= trunc(sysdate-1))"""
    else:
        custom_query = f"""(SELECT distinct * FROM vistaar_lsi.{tab} WHERE trunc({iden}) >= trunc(SYSDATE-1 )) custom_query_alias"""
    
    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)
    
    table_number += 1
    if df.rdd.isEmpty():
        print(f"{table_number}. Table {tab} is empty. No data to process.")
    else:
        df.write \
            .mode("overwrite") \
            .option("header", "true") \
            .option("delimiter", "|") \
            .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f'{table_number}. Table {tab} is successful!!')
    
    if tab in redshift_tbl:
        if tab == 't_lms_tranche_disb_ref':
            df=df.withColumn('dt_userdatetime',to_date('dt_userdatetime'))
        elif tab=='t_lms_disb_dtls':
            dates = ['dt_disbursement','dt_lastupdated','dt_userdatetime','dt_installment_start','dt_cancelsdatetime','dt_bpi_due']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab=='t_cs_customer_details':
            dates = ['dt_statusat','dt_user_datetime','dt_last_updated']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab=='t_cs_individual_details':
            dates = ['dt_date_of_birth','dt_nextrekyc','dt_user_datetime','dt_last_updated']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab== 't_cs_address_details':
            dates = ['dt_user_datetime','dt_last_updated']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab=='t_lms_product_dtls':
            dates = ['dt_lastupdated','dt_userdatetime']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab=='t_lms_tranche_dtls':
            dates = ['dt_installment_start','dt_lastupdated','dt_userdatetime','dt_schedule_gen','dt_last_penal_calculated','dt_grace_period_end','dt_last_int_accr_computed','dt_next_idx_review','dt_last_billing_date','dt_last_grace_int_calc','dt_dep_return']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
        elif tab=='t_lms_loan_references':
            dates = ['dt_userdatetime']
            for date in dates:
                df=df.withColumn(date,to_date(col(date)))
                
        df.write \
            .format("io.github.spark_redshift_community.spark.redshift") \
            .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
            .option("dbtable", f"lms_stg.{tab}") \
            .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/{todays_date}") \
            .option("postactions", f"CALL lms.sp_{tab}();") \
            .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
            .mode("overwrite") \
            .save()

print("All Daily tables executed successfully!!!")

