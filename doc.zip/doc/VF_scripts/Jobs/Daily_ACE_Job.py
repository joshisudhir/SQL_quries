import boto3
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_timestamp
from datetime import datetime

todays_date = datetime.now().strftime("%Y-%m-%d")


# Initialize GlueContext
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

connection_properties = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver
}

# Initialize a boto3 client
s3 = boto3.client('s3', region_name='ap-south-1')
table_dict  = {
    "BASE_ADT_TRN_INCREMENTS": "DTMODIFIEDON",
    "BASE_ADT_TRN_SNAPSHOT": "DTMODIFIEDON",
    "BASE_AST_MST_SETTINGS": "DTMODIFIED_ON",
    # "BASE_ORG_MST_BUSINESSUNIT": "DTMODIFIED_ON",
    "BASE_SEC_MST_PROFILE": "DTMODIFIED_ON",
    "BASE_SEC_MST_PROFILE_DETAILS": "DTMODIFIED_ON",
    "BASE_SEC_MST_SYSTEMUSER": "DTMODIFIED_ON",
    "BASE_UDF_MST_EXTENTSION": "DTMODIFIED_ON"
}

table_number=0
for tab,iden in table_dict.items():
    custom_query = f"""(SELECT * FROM VISTAAR_ACE.{tab} WHERE {iden} >= sysdate-1 ) custom_query_alias"""
    df = spark.read.jdbc(url=jdbc_url, table=custom_query, properties=connection_properties)
    
    table_number+=1
    if df.rdd.isEmpty():
        print(f"Table {tab} is empty. No data to process.")
    else:
        df.repartition(1).write \
        .mode("overwrite") \
        .option("header", "true") \
        .option("delimiter", "|") \
        .csv(f"s3://vistaar-lms-oracle/increment/VISTAAR_LSI/{tab}/{todays_date}/")
        print(f' {table_number} Table {tab} is successfull !!' )
        
print("All Daily table Executed succesfull !!!! ")
        
    

