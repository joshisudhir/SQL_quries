
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import col, from_json, to_timestamp, from_utc_timestamp, date_format, date_sub, current_date, lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, DoubleType, TimestampType

import urllib.parse
from pymongo import MongoClient
import pandas as pd
from pandas import json_normalize
from datetime import datetime, date, timedelta
import urllib3
import numpy as np
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# display(HTML("<style>.container { width:100% !important; }</style>"))
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


###########
# creating the connection with mongodb
# host = "192.168.113.11"
host = "10.1.7.22"
port = 27017

user_name = "vistarlouserRead"
pass_word = "vIsTaarloRead"  

db_name = "vistaarlosdb"

client = MongoClient(f'mongodb://{user_name}:{urllib.parse.quote_plus(pass_word)}@{host}:{port}/{db_name}?directConnection=true')
db = client[db_name]
collection = db['oaoapplications_dropped'] 	

#constructing todays date as dynamic to get data only for today.
start_date = datetime.now()-timedelta(hours=1)
# print(current_time)
print("mod_time filter for worklogs",start_date)
#define the filed to filter the data for incremental logic
query = {
    'mod_time': {
        '$gte': start_date
    }
} 

# Define the projection
projection = {
    'application_id': 1,
    # 'primaryApplicantId':1,
    # 'applicant':1,
    'panNumber':1,
    'mobileNo':1,
    'flowName':1,
    'cre_time': 1,
    'mod_time': 1,
    'worklogs.startTS':1,
    'worklogs.stepName':1,
    'worklogs.action':1,
    'worklogs.actionDescription':1,
    'worklogs.progress':1,
    'worklogs.taskName':1,
    'worklogs.userId':1,
    'primarySector':1,
    '_applicationStatus':1,
    'loanAccountNumber':1,
    'customerIdReceipts':1,
    'branchCode':1,
    'productCode':1,
    'userIdCro':1,
    'vcpCode':1,
    'vcpName':1,
    'mobile':1,
    'finalApvdLoanAmt':1,
    'requestedLoanAmount':1,
    'principalOsObligated':1,
    'todaysDateCibil':1,
    'finalApvdLoanAmt':1,
    'trancheOneWithCharge':1,
    'sourcingType':1,
    'name':1,
    'ebClosureAmount':1,
    'loginProduct':1,
    '_currentStepName':1,
    'cmSelectionProduct':1,
    'legalRepReceived':1,
    'legalReportDate':1,
    'recommendationLegal':1

}

print("firing the query.")
results = collection.find(query, projection)

df_1 = pd.DataFrame(list(results))

print("Create an empty list to hold each processed row from worklogs")
table = []

print("Iterating the dataframe df_1 for worklogs.")
# Iterate over each record in the DataFrame
for index, record in df_1.iterrows():
    worklogs = record.get('worklogs')
    if isinstance(worklogs, list):  # Make sure worklogs is a list
        for log in worklogs:
            # Extract and convert the 'startTS' if it exists
            if isinstance(log.get('startTS'), dict) and '$date' in log['startTS']:
                ts = pd.to_datetime(log['startTS']['$date'], unit='ms')
                ts = ts.tz_localize('UTC').tz_convert('Asia/Kolkata')
            else:
                ts = None  # Default if no timestamp is present

            # Extract user information
            user_info = log.get('userId', {})
            username = user_info.get('username', 'Unknown') if isinstance(user_info, dict) else user_info

            # Construct a row dictionary for each log
            row = {
                'Applicant_Id': record['application_id'],
                'Flow_Name': record['flowName'],
                'Step_Name': log.get('stepName'),
                'startTS': str(log.get('startTS')),
                'Action': log.get('action'),
                'Action_Description': log.get('actionDescription'),
                'Status': log.get('progress'),
                'User_Name': username,
                'Task_Name': log.get('taskName')
            }
            table.append(row)  # Append the row to the table list

result_df = pd.DataFrame(table)
# Convert the list of dicts to a DataFrame
if not result_df.empty:
    result_df.replace(['NaN', 'None', 'nan', '', 'N/A'], np.nan, inplace=True)
    result_df.fillna('', inplace=True)
    spark_df = spark.createDataFrame(result_df)
    spark_df = spark_df.withColumn("startTS", from_utc_timestamp(col("startTS"), "Asia/Kolkata"))
    spark_df = spark_df.withColumn("Event_Date", date_format(col("startTS"), "dd/MM/yyyy"))
    spark_df = spark_df.withColumn("Event_Time", date_format(col("startTS"), "HH:mm:ss"))
    print('narrow transformation done')
    print('ordering the columns as we need for worklogs')
    spark_df = spark_df.select("Applicant_Id","Flow_Name","Event_Date","Event_Time","Step_Name","Task_Name","User_Name","Action","Action_Description","Status")

    utc_time = datetime.utcnow()
    ist_time = utc_time + timedelta(hours=5, minutes=30)
    formatted_time = ist_time.strftime("%H-00-00")
    formatted_today_date = ist_time.strftime("%Y-%m-%d")
    
    print("converting spark dataframe to pandas dtaframe: related to worklogs")
    pandas_df = spark_df.toPandas()
    print("saving worklogs using pandas dataframe")
    pandas_df.to_csv(f"s3://vf-prod-misreport/EPIK_LOS_DUMP/vf-dl-los-incremental/MIS-06-Worklogs-Info@{formatted_today_date}@{formatted_time}@3.txt", sep=',',  index = False)
    
else:
    print("Dataframe is  is empty. No further processing performed.")

############################################################################
print("Now Iterating over df_1 for mis_variables.")
###############################################################################
# Create an empty list to hold each processed row
table = []
# Iterate over each record in the DataFrame
print("iterating on a dataframe.")
for index, record in df_1.iterrows():
    row = {
    "SZ_APPLICATION_NO": str(record.get('loanAccountNumber','')),
     "APPLICANT_ID": str(record.get('application_id','')),
     "CUSTOMER_ID": str(record.get('customerIdReceipts','')),
     "BRANCH_CD": str(record.get('branchCode','')),
     "SUB_PRODUCT": str(record.get('productCode','')),
     "CRO_CODE": str(record.get('userIdCro','')),
     "VCP_ID": str(record.get('vcpCode','')),
     "VCP_NAME": str(record.get('vcpName','')),
     "GENDER": str(record.get('gender','')),
     "DT_BIRTH_DTE": str(record.get('dob','')),
     "AGE": str(record.get('age','')),
     "SZ_MARITAL_STATUS": str(record.get('personnelMaritalStatus','')),
     "SZ_EDUCTION_LEVEL": str(record.get('educationLevel','')),
     "MOBILE_NO": str(record.get('mobile','')),
     "LOAN_AMOUNT": str(record.get('finalApvdLoanAmt','')),
     "APPLIEDAMOUNT": str(record.get('requestedLoanAmount','')),
     "Tranche_Amount_1": str(record.get('trancheOneWithCharge','')),
     "Tranche_Amount_2": str(record.get('tranchetwoWithCharge','')),
     "Tranche_Amount_3": str(record.get('tranchethreeWithCharge','')),
     "EB_OUTSTANDING_AMT": str(record.get('principalOsObligated','')),
     "I_TENOR": str(record.get('finalLoanPeriod','')),
     "collateralOneId": str(record.get('collateralOneId','')),
     "collateralTwoId": str(record.get('collateralTwoId','')),
     "F_INTEREST_RATE": str(record.get('roiCm','')),
     "APPLICATION_FEE": str(record.get('feeAmount','')),
     "FEE_PAYMENT_STATUS": str(record.get('feePaymentStatus','')),
     "CREATION_DT": str(record.get('todaysDateCibil','')),
     "SANCTIONED_AMT": str(record.get('finalApvdLoanAmt','')),
     "I_DSB_SRNO": str(record.get('trancheNumber','')),
     "DISBURSED_AMT": str(record.get('trancheOneWithCharge','')),
     "SZ_REJ_CODE": str(record.get('blank','')),
     "REJECTION_REASON": str(record.get('_latestComments', {}).get('code', '')) if isinstance(record.get('_latestComments'), dict) else '',
     "PRIMARY_LIVELIHOOD": str(record.get('primarySector','')),
     "TOTAL_INCOME": str(record.get('totalNetIncome','')),
     "F_TOTAL_VAL": str(record.get('fairMrktValPOVO','')),
     "F_FAIR_MKT_VAL": str(record.get('fairMrktValPOVO','')),
     "SZ_OLDLAN": str(record.get('existingLan','')),
     "CIBIL_SCORE": str(record.get('cibilScore','')),
     "PROPERTY_TYPE": str(record.get('typeOfPropertyPropOneValOne','')),
     "SECTORS": str(record.get('primarySector','')),
     "SUB_SECTORS": str(record.get('subSector','')),
     "LOGIN_STATUS": str(record.get('_applicationStatus','')),
     "CUSTOMER_TYPE": str(record.get('sourcingType','')),
     "CUSTOMER_NAME": str(record.get('name','')),
     "EB_CLOSURE_AMT_MTD": str(record.get('ebClosureAmount','')),
     "FINAL_DISB_FLAG": str(record.get('finalDisbursement','')),
     "DISB_SRNO": str(record.get('trancheNumber','')),
     "TENOR": str(record.get('finalLoanPeriod','')),
     "F_ACTUAL_EMI": str(record.get('getAmortEmi','')),
     "I_NO_DEPENDENT": str(record.get('blank','')),
     "NUMBER_EMPLOYEE": str(record.get('blank','')),
     "Branch_Product": str(record.get('loginProduct','')),
     "Current_Step_Name": str(record.get('_currentStepName','')),
     "Existing_Customer": str(record.get('customerType','')),
     "Facility_Type": str(record.get('facilityType','')),
     "PRODUCT": str(record.get('cmSelectionProduct','')),
     "Max_Loan_Amount": str(record.get('enteredMaxLoanAmt','')),
     "DSR_Value": str(record.get('actualDsrValTwo','')),
     "ROI": str(record.get('roiCm','')),
     "EMI": str(record.get('maxValEMi','')),
     "Assesment_Method_Policy": str(record.get('assesmentmethodpolicy','')),
     "Final_EMI_Amount": str(record.get('finalEmiAmount','')),
     "Limit_Requested": str(record.get('requestedLoanAmount','')),
     "Limit_Proposed": str(record.get('limitCm','')),
     "RO1": str(record.get('roiCm','')),
     "Tenor": str(record.get('tenor','')),
     "DSR": str(record.get('dsrSummary','')),
     "Current_Obligations": str(record.get('fetchedTotalObligation','')),
     "Customer_Comfortable_EMI": str(record.get('customereligibleemi','')),
     "Customer_Type": str(record.get('customertype','')),
     "Asset_Created_within_4_years": str(record.get('assetcreated','')),
     "No._Of_Collaterals_Offered": str(record.get('CollateralsOffered','')),
     "Sampatti_End_Use": str(record.get('sampLtvConcat','')),
     "Property_Type": str(record.get('typeOfPropertyPropOneValOne','')),
     "Occupancy_Type": str(record.get('currentOccupancyPropOneValOne','')),
     "Collateral_Scheme": str(record.get('collateralSchemePropOneValOne','')),
     "Fair_Makret_Value": str(record.get('fairMrktValPOVO','')),
     "Assesment_Method": str(record.get('finalAssesMethodCfa','')),
     "Net_Profit_Considered": str(record.get('finalVal','')),
     "Additional_Income": str(record.get('additionalincome','')),
     "Total_net_Income": str(record.get('totalNetIncome','')),
     "Max_Eligible_EMI": str(record.get('maxEligibleEmiFinal','')),
     "Proposed_Limit": str(record.get('limitCm','')),
     "Product_Cap": str(record.get('maxAsPerPolicy','')),
     "Collateral_Cap": str(record.get('maxLoanCollPOVO','')),
     "CFA": str(record.get('eligiblelimitaspercfa','')),
     "Comfortable_EMI": str(record.get('comfortableEMI','')),
     "Sampatti_Margin": str(record.get('propertyValMargin','')),
     "MAXIMUM_LOAN_WHICH_CAN_BE_APPROVED_TO_THE_CUSTOMER": str(record.get('enteredMaxLoanAmt','')),
     "Actual_DSR": str(record.get('actualDsrValTwo','')),
     "Actual_LTV": str(record.get('ltvEnteredSummary','')),
     "ROI": str(record.get('roiCm','')),
     "TENOR_IN_Months": str(record.get('finalMaxTenor','')),
     "ASSESSMENT_METHOD_CONSIDERD": str(record.get('assesmentmethodpolicy','')),
     "PRODUCT_CONSIDERED": str(record.get('cmSelectionProduct','')),
     "Sampatti_margin_calculation": str(record.get('sampattiMixedEnduse','')),
     "Final_Loan_Amount": str(record.get('finalApvdLoanAmt','')),
     "Final_EMI": str(record.get('finalEmiAmount','')),
     "Loan_Period": str(record.get('tenorCM','')),
     "Rate": str(record.get('roiCm','')),
     "RCU_Final_Status": str(record.get('rcuFinalStatus','')),
     "RCU_KYC_Status": str(record.get('rcuKycStatus','')),
     "Dedupe_Status": str(record.get('rcuDedupeStatus','')),
     "limitDataEntry": str(record.get('limitDataEntry','')),
     "Product_Selected_is_Sampatti": str(record.get('productCheck','')),
     "Branch_Tier": str(record.get('branchTier','')),
     "Rate_Card": str(record.get('roiRateCard','')),
     "branchCro": str(record.get('branchCro','')),
     "roiTierOne": str(record.get('roiTierOne','')),
     "roiTiertwo": str(record.get('roiTierTwo','')),
     "roiTierThree": str(record.get('roiTierThree','')),
     "Property_Type_2": str(record.get('sampLtvConcat','')),
     "ROI_Sampatti": str(record.get('sampattiRoi','')),
     "Temporary_Business": str(record.get('temporaryBusinessCheck','')),
     "Difference_in_ROI_Approval": str(record.get('roiDiffereceDeviation','')),
     "Deviation_Level": str(record.get('deviationLevelNego','')),
     "Processing_fee_Excluding_GST_Standard_amount": str(record.get('finalProcFee','')),
     "Processing_fee_amount": str(record.get('finalProcFeeVal','')),
     "Collection_type": str(record.get('processingFeeCollection','')),
     "Waived_Processing_Fee": str(record.get('updatedProcFee','')),
     "Processing_fee_Collected_amount_incl_GST": str(record.get('finalProcFeeDisplay','')),
     "Enter_the_actual_waiver": str(record.get('procFeeWaiveAmount','')),
     "Documentation_fee_Excl_GST_Standard_amount": str(record.get('documentHandlingActual','')),
     "Documentation_fee_Incl_GST_Collected_amount": str(record.get('docHandelingCharges','')),
     "Legal_and_valuation_fee": str(record.get('totalPaymentVendors','')),
     "Insurance_amount_collected_Kotak": str(record.get('kotakSubProductCharges','')),
     "Insurance_amount_collected_ICICI": str(record.get('iciciSubProductCharges','')),
     "SALUTATION": str(record.get('title','')),
     "AddressLineOne": str(record.get('permManAddLine','')),
     "AddressLineTwo": str(record.get('permManAddLineTwo','')),
     "CITY": str(record.get('permanentCity','')),
     "STATE": str(record.get('permanentState','')),
     "PINCODE": str(record.get('permanentPostalCode','')),
     "PROPERTYADDRESSONE": str(record.get('addrLnOneCollOne','')),
     "PROPERTYADDRESSTWO": str(record.get('addrLnTwoCollOne','')),
     "PROPERTYCITY": str(record.get('districtPOVO','')),
     "PROPERTYSTATE": str(record.get('stateLegal','')),
     "PROPERTYPINCODE": str(record.get('pincodePOVO','')),
     "NOMINEENAME": str(record.get('subProdutNomineeName','')),
     "RELATIONSHIP": str(record.get('subProductNomineeRelation','')),
     "SZ_PAN": str(record.get('panNumber','')),
     "ROI_difference": str(record.get('roiDiffereceNego','')),
     "FinalRoi": str(record.get('mnNegLoanRate','')),
     "REGION": str(record.get('region','')),
     "Split Loan": str(record.get('splitLoan','')),
     "Flow Name": str(record.get('flowName','')),
     "INSURED_NAME_THREE": str(record.get('insuredNameThree','')),
     "DATE_OF_BIRTH_APPLICANT_THREE": str(record.get('dateOfBirthApplicantThree','')),
     "EMAIL_OF_INSURER_THREE": str(record.get('emailOfInsurerThree','')),
     "GENDER_OF_INSURER_THREE": str(record.get('genderOfInsurerThree','')),
     "RELATIONSHIP_WITH_APPLICANT_INSURER_THREE": str(record.get('relationshipWithApplicantInsurerThree','')),
     "INSURED_NAME_FOUR": str(record.get('insuredNameFour','')),
     "DATE_OF_BIRTH_APPLICANT_FOUR": str(record.get('dateOfBirthApplicantFour','')),
     "EMAIL_OF_INSURER_FOUR": str(record.get('emailOfInsurerFour','')),
     "GENDER_OF_INSURER_FOUR": str(record.get('genderOfInsurerFour','')),
     "RELATIONSHIP_WITH_APPLICANT_INSURER_FOUR": str(record.get('relationshipWithApplicantInsurerFour','')),
     "INSURED_NAME_FIVE": str(record.get('insuredNameFive','')),
     "DATE_OF_BIRTH_APPLICANT_FIVE": str(record.get('dateOfBirthApplicantFive','')),
     "EMAIL_OF_INSURER_FIVE": str(record.get('emailOfInsurerFive','')),
     "GENDER_OF_INSURER_FIVE": str(record.get('genderOfInsurerFive','')),
     "RELATIONSHIP_WITH_APPLICANT_INSURER_FIVE": str(record.get('relationshipWithApplicantInsurerFive','')),
     "INSURED_NAME_SIX": str(record.get('insuredNameSix','')),
     "DATE_OF_BIRTH_APPLICANT_SIX": str(record.get('dateOfBirthApplicantSix','')),
     "EMAIL_OF_INSURER_SIX": str(record.get('emailOfInsurerSix','')),
     "GENDER_OF_INSURER_SIX": str(record.get('genderOfInsurerSix','')),
     "RELATIONSHIP_WITH_APPLICANT_INSURER_SIX": str(record.get('relationshipWithApplicantInsurerSix','')),
     "Actual_ROI": str(record.get('roi','')),
     "Legal_report_Received": str(record.get('legalRepReceived','')),
     "Legal_Report_Date": str(record.get('legalReportDate','')),
     "Final_Recommendation": str(record.get('recommendationLegal',''))
     
            }
    table.append(row)  # Append the row to the table list


result_df_mis = pd.DataFrame(table)
    
if not result_df_mis.empty:
    # Replace any non-empty string representations of missing values with empty strings
    result_df_mis.replace(['NaN', 'None', 'nan', '', 'N/A'], np.nan, inplace=True)
    result_df_mis.fillna('', inplace=True)
    
    utc_time = datetime.utcnow()
    ist_time = utc_time + timedelta(hours=5, minutes=30)
    formatted_time = ist_time.strftime("%H-00-00")
    formatted_today_date = ist_time.strftime("%Y-%m-%d")
    
    print("saving mis-variables using pandas dataframe")
    result_df_mis.to_csv(f"s3://vf-prod-misreport/EPIK_LOS_DUMP/vf-dl-los-incremental/MIS-Variables@{formatted_today_date}@{formatted_time}@3.txt", sep='|',  index = False)
else:
    print("Dataframe is  is empty. No further processing performed.")
    #################################################################



 