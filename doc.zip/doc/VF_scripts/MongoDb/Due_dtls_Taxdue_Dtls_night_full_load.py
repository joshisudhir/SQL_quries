#Schedule At 09:10 PM
#Cron Expression 10 21 * * ? *

import boto3
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date,to_timestamp
from datetime import datetime

# Initialize GlueContext and SparkSession
glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session

# jdbc_url = "jdbc:oracle:thin:@192.168.153.10:1521/VISTLSI"
jdbc_url = "jdbc:oracle:thin:@10.1.7.235:1521/VISTLSI"
jdbc_user = "analytics"
jdbc_password = "ANALYTIC123$"
jdbc_driver = "oracle.jdbc.driver.OracleDriver"

todays_date = datetime.now().strftime("%Y-%m-%d")

cp_T_LMS_DUE_DTLS = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "i_srno",
    "lowerBound": "1",
    "upperBound": "2500",
    "numPartitions": "20"
}

cp_T_LMS_TAXDUE_DTLS = {
    "user": jdbc_user,
    "password": jdbc_password,
    "driver": jdbc_driver,
    "partitionColumn": "i_srno",
    "lowerBound": "1",
    "upperBound": "1500",
    "numPartitions": "20"
}

s3 = boto3.client('s3', region_name='ap-south-1')
redshift_tbl = {'T_LMS_TAXDUE_DTLS': cp_T_LMS_TAXDUE_DTLS, 'T_LMS_DUE_DTLS': cp_T_LMS_DUE_DTLS}

for table, cp in redshift_tbl.items():
    try:
        df = spark.read.jdbc(url=jdbc_url, table=f'VISTAAR_LSI.{table}', properties=cp)

        if table == 'T_LMS_DUE_DTLS':
            dates = ['dt_lastupdated','DT_USERDATETIME']
            df=df.withColumn('dt_duedate',to_date(col('dt_duedate')))
            for date in dates:
                df = df.withColumn(date, to_timestamp(col(date)))

        if df.rdd.isEmpty():
            print(f"Table {table} is empty. No data to process.")
        else:
            s3_path = f"s3://vistaar-lms-oracle/Every_night_full_load/{table}"
            df.write \
                .mode("overwrite") \
                .format("parquet") \
                .option("header", "true") \
                .save(s3_path)
            print(f"Table '{table}' is successfully uploaded to S3 at '{s3_path}.' ")
    except Exception as e:
        print(f"Error processing table {table}: {str(e)}")
