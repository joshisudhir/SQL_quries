#Schedule At 30 minutes past the hour, every 1 hours, between 03:00 AM and 04:59 PM
#Cron Expression 30 3-16/1 * * ? *


import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import col, from_json, to_timestamp, from_utc_timestamp, date_format, date_sub, current_date, lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, DoubleType, TimestampType

import urllib.parse
from pymongo import MongoClient
import pandas as pd
from pandas import json_normalize
from datetime import datetime, date, timedelta
import urllib3
import numpy as np
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# display(HTML("<style>.container { width:100% !important; }</style>"))
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


###########
# creating the connection with mongodb
# host = "192.168.113.11"
host = "10.1.7.22"
port = 27017

user_name = "vistarlouserRead"
pass_word = "vIsTaarloRead"  

db_name = "vistaarlosdb"

client = MongoClient(f'mongodb://{user_name}:{urllib.parse.quote_plus(pass_word)}@{host}:{port}/{db_name}?directConnection=true')
db = client[db_name]
collection = db['oaoapplicants'] 	



#constructing todays date as dynamic to get data only for today.
start_date = datetime.now()-timedelta(hours=3)
# print(current_time)
print("mod_time filter for worklogs",start_date)
#define the filed to filter the data for incremental logic
query = {
    'mod_time': {
        '$gte': start_date
    }
} 

# Define the projection
projection = {
    '_id': 1,
    'application_id': 1,
    'primaryApplicantId':1,
    'applicant':1,
    'panNumber':1,
    'mobileNo':1,
    'flowName':1,
    'cre_time': 1,
    'mod_time': 1,
    'worklogs.startTS':1,
    'worklogs.stepName':1,
    'worklogs.action':1,
    'worklogs.actionDescription':1,
    'worklogs.progress':1,
    'worklogs.taskName':1,
    'worklogs.userId':1
    
}
results = collection.find(query, projection)

df_1 = pd.DataFrame(list(results))

# Create an empty list to hold each processed row from worklogs
table = []


# Iterate over each record in the DataFrame
for index, record in df_1.iterrows():
    worklogs = record.get('worklogs')
    if isinstance(worklogs, list):  # Make sure worklogs is a list
        for log in worklogs:
            # Extract and convert the 'startTS' if it exists
            if isinstance(log.get('startTS'), dict) and '$date' in log['startTS']:
                ts = pd.to_datetime(log['startTS']['$date'], unit='ms')
                ts = ts.tz_localize('UTC').tz_convert('Asia/Kolkata')
            else:
                ts = None  # Default if no timestamp is present

            # Extract user information
            user_info = log.get('userId', {})
            username = user_info.get('username', 'Unknown') if isinstance(user_info, dict) else user_info

            # Construct a row dictionary for each log
            row = {
                'Applicant_Id': record['application_id'],
                'Flow_Name': record['flowName'],
                'Step_Name': log.get('stepName'),
                'startTS': str(log.get('startTS')),
                'Action': log.get('action'),
                'Action_Description': log.get('actionDescription'),
                'Status': log.get('progress'),
                'User_Name': username,
                'Task_Name': log.get('taskName'),
                'worklog_Type': str('Applicant') #this is constant column to identify the worklogs type. This is coming from oaoapplicants collection.
            }
            table.append(row)  # Append the row to the table list

result_df = pd.DataFrame(table)
# Convert the list of dicts to a DataFrame
if not result_df.empty:
    result_df.replace(['NaN', 'None', 'nan', '', 'N/A'], np.nan, inplace=True)
    result_df.fillna('', inplace=True)
    spark_df = spark.createDataFrame(result_df)
    spark_df = spark_df.withColumn("startTS", from_utc_timestamp(col("startTS"), "Asia/Kolkata"))
    spark_df = spark_df.withColumn("EventDate", date_format(col("startTS"), "dd/MM/yyyy"))
    spark_df = spark_df.withColumn("EventTime", date_format(col("startTS"), "HH:mm:ss"))
    
    utc_time = datetime.utcnow()
    ist_time = utc_time + timedelta(hours=5, minutes=30)
    formatted_date_time = ist_time.strftime("%Y-%m-%d %H:%M:00")
    formatted_today_date = ist_time.strftime("%Y-%m-%d")
    
    spark_df.repartition(1).write.format("csv") \
        .option("header", "true") \
        .mode("append") \
        .option("delimiter", ",") \
        .save(f"s3://vistaar-los-mongodb/Incremental/vistaarlosdb/oaoapplicants/worklog/{formatted_today_date}/{formatted_date_time}/")
    print('record inserted in S3 bucket')
        
    ##Added by Sandip on 15-May-2024 to load Worklogs in Redshift
    r_user = 'vf_admin'
    r_pass = 'Vfadmin@12345'
    spark_df.write \
                .format("io.github.spark_redshift_community.spark.redshift") \
                .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user, r_pass)) \
                .option("preactions", f"Truncate table los_stg.Worklogs;")\
                .option("dbtable", f"los_stg.Worklogs") \
                .option("tempdir", f"s3://vistaar-lms-oracle/increment/temp/") \
                .option("postactions", f"CALL los.sp_Insert_Delete_Worklogs();") \
                .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
                .mode("append") \
                .save()
    print('record inserted in redshift')
else:
    print("Dataframe is  is empty. No further processing performed.")




 