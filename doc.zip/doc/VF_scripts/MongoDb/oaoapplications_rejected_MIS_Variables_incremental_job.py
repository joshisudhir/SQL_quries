
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import col, from_json, to_timestamp, from_utc_timestamp, date_format, date_sub, current_date, lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, DoubleType, TimestampType

import urllib.parse
from pymongo import MongoClient
import pandas as pd
from pandas import json_normalize
from datetime import datetime, date, timedelta
import pytz
import urllib3
import numpy as np
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# display(HTML("<style>.container { width:100% !important; }</style>"))
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


###########
# creating the connection with mongodb
# host = "192.168.113.11"
host = "10.1.7.22"
port = 27017

user_name = "vistarlouserRead"
pass_word = "vIsTaarloRead"  

db_name = "vistaarlosdb"

client = MongoClient(f'mongodb://{user_name}:{urllib.parse.quote_plus(pass_word)}@{host}:{port}/{db_name}?directConnection=true')
db = client[db_name]
collection = db['oaoapplications_rejected'] 	



#constructing todays date as dynamic to get data only for today.
# start_date = datetime.combine(date.today(), datetime.min.time())
start_date = datetime.now()-timedelta(hours=3)
# start_date = datetime(2024, 2, 1)
# print(current_time)

#define the filed to filter the data for incremental logic
query = {
    'mod_time': {
        '$gte': start_date
    }
} 	




# Define the projection
projection = {
    '_id': 1,
    'application_id': 1,
    'primaryApplicantId':1,
    'applicant':1,
    'panNumber':1,
    'mobileNo':1,
    'flowName':1,
    'cre_time': 1,
    'mod_time': 1,
    'aadharCard':1,
    'voterIdNo':1,
    'drivingLicenceNo':1,
    'coApplicantName':1,
    'monthlySalaryCoApplicant':1,
    'yearsExperience':1,
    'ageCoApplicant':1,
    'dob':1,
    'gender':1,
    'fatherName':1,
    'fatherMname':1,
    'fatherLname':1,
    'spouseName':1,
    'passportNo':1,
    'addressLineOne':1,
    'addressLineTwo':1,
    'aplcntPermAddrPin':1,
    'aplcntPermAddrCity':1,
    'aplcntPermAddrState':1,
    'aplcntPermStateCode':1,
    'cibilScore':1,
    'currentAgeBor':1,
    'salariedAccount':1,
    'title':1,
    'personnelAge':1,
    'educationLevel':1,
    'mothersMaidenName':1,
    'religion':1,
    'personnelCategory':1,
    'personnelMaritalStatus':1,
    'userIdCro':1,
    'branchCro':1,
    'vistaarStateCode':1,
    'branchCode':1,
    'dmsBranch':1,
    'customerType':1,
    'fname':1,
    'mname':1,
    'lname':1,
    'mobile':1,
    'email':1,
    'age':1,
    'requestedLoanAmount':1,
    'selectDetailsLms':1,
    'loanAccountNumberFetch':1,
    'panNumberLms':1,
    'ErrorDescMobile':1,
    'messageMobileMulti':1,
    'lmsLoanAcErrorDesc':1,
    'lmsLoanAcMessage':1,
    'loanAccountNumber':1,
    'customerIdReceipts':1,
    'productCode':1,
    'vcpCode':1,
    'vcpName':1,
    'finalApvdLoanAmt':1,
    'trancheOneWithCharge':1,
    'tranchetwoWithCharge':1,
    'tranchethreeWithCharge':1,
    'principalOsObligated':1,
    'finalLoanPeriod':1,
    'collateralOneId':1,
    'collateralTwoId':1,
    'roiCm':1,
    'feeAmount':1,
    'feePaymentStatus':1,
    'todaysDateCibil':1,
    'trancheNumber':1,
    'primarySector':1,
    'totalNetIncome':1,
    'fairMrktValPOVO':1,
    'typeOfPropertyPropOneValOne':1,
    'subSector':1,
    '_applicationStatus':1,
    'sourcingType':1,
    'name':1,
    'ebClosureAmount':1,
    'finalDisbursement':1,
    'finalLoanPeriod':1,
    'getAmortEmi':1,
    'loginProduct':1,
    '_currentStepName':1,
    'facilityType':1,
    'cmSelectionProduct':1,
    'enteredMaxLoanAmt':1,
    'actualDsrValTwo':1,
    'maxValEMi':1,
    'assesmentmethodpolicy':1,
    'finalEmiAmount':1,
    'limitCm':1,
    'tenor':1,
    'dsrSummary':1,
    'fetchedTotalObligation':1,
    'customereligibleemi':1,
    'assetcreated':1,
    'CollateralsOffered':1,
    'sampLtvConcat':1,
    'currentOccupancyPropOneValOne':1,
    'collateralSchemePropOneValOne':1,
    'finalAssesMethodCfa':1,
    'finalVal':1,
    'additionalincome':1,
    'totalNetIncome':1,
    'maxEligibleEmiFinal':1,
    'maxAsPerPolicy':1,
    'maxLoanCollPOVO':1,
    'eligiblelimitaspercfa':1,
    'comfortableEMI':1,
    'propertyValMargin':1,
    'enteredMaxLoanAmt':1,
    'actualDsrValTwo':1,
    'ltvEnteredSummary':1,
    'finalMaxTenor':1,
    'assesmentmethodpolicy':1,
    'cmSelectionProduct':1,
    'sampattiMixedEnduse':1,
    'tenorCM':1,
    'rcuFinalStatus':1,
    'rcuKycStatus':1,
    'rcuDedupeStatus':1,
    'limitDataEntry':1,
    'productCheck':1,
    'branchTier':1,
    'roiRateCard':1,
    'roiTierOne':1,
    'roiTierTwo':1,
    'roiTierThree':1,
    'sampLtvConcat':1,
    'sampattiRoi':1,
    'temporaryBusinessCheck':1,
    'roiDiffereceDeviation':1,
    'deviationLevelNego':1,
    'finalProcFee':1,
    'finalProcFeeVal':1,
    'processingFeeCollection':1,
    'updatedProcFee':1,
    'finalProcFeeDisplay':1,
    'procFeeWaiveAmount':1,
    'documentHandlingActual':1,
    'docHandelingCharges':1,
    'totalPaymentVendors':1,
    'kotakSubProductCharges':1,
    'iciciSubProductCharges':1,
    'title':1,
    'permManAddLine':1,
    'permManAddLineTwo':1,
    'permanentCity':1,
    'permanentState':1,
    'permanentPostalCode':1,
    'addrLnOneCollOne':1,
    'addrLnTwoCollOne':1,
    'districtPOVO':1,
    'stateLegal':1,
    'pincodePOVO':1,
    'subProdutNomineeName':1,
    'subProductNomineeRelation':1,
    'roiDiffereceNego':1,
    'mnNegLoanRate':1,
    'region':1,
    'splitLoan':1,
    '_latestComments':1,
    'existingLan':1
}

############
# results = collection.find(query, projection).limit(2)
results = collection.find(query, projection)

df = pd.DataFrame(list(results))


###############
# data for MIS variable

# Create an empty list to hold each processed row
table = []

# Iterate over each record in the DataFrame
for index, record in df.iterrows():
    row = {
                # 'Applicant_Id': str(record['application_id']),
                'Applicant_Id': str(record.get('application_id')),
                'SZ_APPLICATION_NO': str(record.get('loanAccountNumber')),
                'CUSTOMER_ID': str(record.get('customerIdReceipts')),
                'BRANCH_CD': str(record.get('branchCode')),
                # 'SUB_PRODUCT': str(record['productCode']),
                'CRO_CODE': str(record.get('userIdCro')),
                'VCP_ID': str(record.get('vcpCode')),
                'VCP_NAME': str(record.get('vcpName')),
                'GENDER': str(record.get('gender')),
                'DT_BIRTH_DTE': str(record.get('dob')),
                'AGE': str(record.get('age')),
                'SZ_MARITAL_STATUS': str(record.get('personnelMaritalStatus')),
                'SZ_EDUCTION_LEVEL': str(record.get('educationLevel')),
                'MOBILE_NO': str(record.get('mobile')),
                'LOAN_AMOUNT': str(record.get('finalApvdLoanAmt')),
                'APPLIEDAMOUNT': str(record.get('requestedLoanAmount')),
                # 'Tranche_Amount_1': str(record['trancheOneWithCharge']),
                # 'Tranche_Amount_2': str(record['tranchetwoWithCharge']),
                # 'Tranche_Amount_3': str(record['tranchethreeWithCharge']),
                # 'EB_OUTSTANDING_AMT': str(record['principalOsObligated']),
                'I_TENOR': str(record.get('finalLoanPeriod')),
                # 'collateralOneId': str(record['collateralOneId']),
                'collateralOneId': str(record.get('collateralOneId')),
                'collateralTwoId': str(record.get('collateralTwoId')),
                'F_INTEREST_RATE': str(record.get('roiCm')),
                'APPLICATION_FEE': str(record.get('feeAmount')),
                'FEE_PAYMENT_STATUS': str(record.get('feePaymentStatus')),
                'CREATION_DT': str(record.get('todaysDateCibil')),
                'SANCTIONED_AMT': str(record.get('finalApvdLoanAmt')),
                # 'I_DSB_SRNO': str(record['trancheNumber']),
                # 'DISBURSED_AMT': str(record['trancheOneWithCharge']),
                'PRIMARY_LIVELIHOOD': str(record.get('primarySector')),
                'TOTAL_INCOME': str(record.get('totalNetIncome')),
                'F_TOTAL_VAL': str(record.get('fairMrktValPOVO')),
                'SZ_OLDLAN': str(record.get('existingLan')),
                'CIBIL_SCORE': str(record.get('cibilScore')),
                'PROPERTY_TYPE': str(record.get('typeOfPropertyPropOneValOne')),
                'SECTORS': str(record.get('primarySector')),
                'SUB_SECTORS': str(record.get('subSector')),
                'LOGIN_STATUS': str(record.get('_applicationStatus')),
                'CUSTOMER_TYPE_SOURCING': str(record.get('sourcingType')),
                'CUSTOMER_NAME': str(record.get('name')),
                'EB_CLOSURE_AMT_MTD': str(record.get('ebClosureAmount')),
                # 'FINAL_DISB_FLAG': str(record['finalDisbursement']),
                # 'DISB_SRNO': str(record['trancheNumber']),
                'TENOR_FINALLOAN_PERIOD': str(record.get('finalLoanPeriod')),
                'F_ACTUAL_EMI': str(record.get('getAmortEmi')),
                'Branch_Product': str(record.get('loginProduct')),
                'Current_Step_Name': str(record.get('_currentStepName')),
                'Existing_Customer': str(record.get('customerType')),
                'Facility_Type': str(record.get('facilityType')),
                'PRODUCT': str(record.get('cmSelectionProduct')),
                'Max_Loan_Amount': str(record.get('enteredMaxLoanAmt')),
                'DSR_Value': str(record.get('actualDsrValTwo')),
                'ROI': str(record.get('roiCm')),
                'EMI': str(record.get('maxValEMi')),
                'Assesment_Method_Policy': str(record.get('assesmentmethodpolicy')),
                'Final_EMI_Amount': str(record.get('finalEmiAmount')),
                'Limit_Requested': str(record.get('requestedLoanAmount')),
                'Limit_Proposed': str(record.get('limitCm')),
                'RO1': str(record.get('roiCm')),
                'Tenor': str(record.get('tenor')),
                'DSR': str(record.get('dsrSummary')),
                'Current_Obligations': str(record.get('fetchedTotalObligation')),
                'Customer_Comfortable_EMI': str(record.get('customereligibleemi')),
                'Asset_Created_within_4_years': str(record.get('assetcreated')),
                'No_Of_Collaterals_Offered': str(record.get('CollateralsOffered')),
                'Sampatti_End_Use': str(record.get('sampLtvConcat')),
                'Occupancy_Type': str(record.get('currentOccupancyPropOneValOne')),
                'Collateral_Scheme': str(record.get('collateralSchemePropOneValOne')),
                'Fair_Makret_Value': str(record.get('fairMrktValPOVO')),
                'Assesment_Method': str(record.get('finalAssesMethodCfa')),
                'Net_Profit_Considered': str(record.get('finalVal')),
                'Additional_Income': str(record.get('additionalincome')),
                'Total_net_Income': str(record.get('totalNetIncome')),
                'Max_Eligible_EMI': str(record.get('maxEligibleEmiFinal')),
                'Proposed_Limit': str(record.get('limitCm')),
                'Product_Cap': str(record.get('maxAsPerPolicy')),
                'Collateral_Cap': str(record.get('maxLoanCollPOVO')),
                'CFA': str(record.get('eligiblelimitaspercfa')),
                'Comfortable_EMI': str(record.get('comfortableEMI')),
                'Sampatti_Margin': str(record.get('propertyValMargin')),
                'MAXIMUM_LOAN_WHICH_CAN_BE_APPROVED_TO_THE_CUSTOMER': str(record.get('enteredMaxLoanAmt')),
                'Actual_DSR': str(record.get('actualDsrValTwo')),
                'Actual_LTV': str(record.get('ltvEnteredSummary')),
                'ROI': str(record.get('roiCm')),
                'TENOR_IN_Months': str(record.get('finalMaxTenor')),
                'EMI': str(record.get('maxValEMi')),
                'ASSESSMENT_METHOD_CONSIDERD': str(record.get('assesmentmethodpolicy')),
                'PRODUCT_CONSIDERED': str(record.get('cmSelectionProduct')),
                'Sampatti_margin_calculation': str(record.get('sampattiMixedEnduse')),
                'Final_Loan_Amount': str(record.get('finalApvdLoanAmt')),
                'Final_EMI': str(record.get('finalEmiAmount')),
                'Loan_Period': str(record.get('tenorCM')),
                'Rate': str(record.get('roiCm')),
                'RCU_Final_Status': str(record.get('rcuFinalStatus')),
                'RCU_KYC_Status': str(record.get('rcuKycStatus')),
                'Dedupe_Status': str(record.get('rcuDedupeStatus')),
                'limitDataEntry': str(record.get('limitDataEntry')),
                'Product_Selected_is_Sampatti': str(record.get('productCheck')),
                'Branch_Tier': str(record.get('branchTier')),
                'Rate_Card': str(record.get('roiRateCard')),
                'branchCro': str(record.get('branchCro')),
                'roiTierOne': str(record.get('roiTierOne')),
                'roiTierTwo': str(record.get('roiTierTwo')),
                'roiTierThree': str(record.get('roiTierThree')),
                'Property_Type_2': str(record.get('sampLtvConcat')),
                'ROI_Sampatti': str(record.get('sampattiRoi')),
                'Temporary_Business': str(record.get('temporaryBusinessCheck')),
                'Difference_in_ROI_Approval': str(record.get('roiDiffereceDeviation')),
                'Deviation_Level': str(record.get('deviationLevelNego')),
                'Processing_fee_Excluding_GST_Standard_amount': str(record.get('finalProcFee')),
                'Processing_fee_amount': str(record.get('finalProcFeeVal')),
                'Collection_type': str(record.get('processingFeeCollection')),
                'Waived_Processing_Fee': str(record.get('updatedProcFee')),
                'Processing_fee_Collected_amount_incl_GST': str(record.get('finalProcFeeDisplay')),
                'Enter_the_actual_waiver': str(record.get('procFeeWaiveAmount')),
                # 'Documentation_fee_Excl_GST_Standard_amount': str(record['documentHandlingActual']),
                'Documentation_fee_Incl_GST_Collected_amount': str(record.get('docHandelingCharges')),
                'Legal_and_valuation_fee': str(record.get('totalPaymentVendors')),
                'Insurance_amount_collected_Kotak': str(record.get('kotakSubProductCharges')),
                'Insurance_amount_collected_ICICI': str(record.get('iciciSubProductCharges')),
                'SALUTATION': str(record.get('title')),
                'AddressLineOne': str(record.get('permManAddLine')),
                'AddressLineTwo': str(record.get('permManAddLineTwo')),
                'CITY': str(record.get('permanentCity')),
                'STATE': str(record.get('permanentState')),
                'PINCODE': str(record.get('permanentPostalCode')),
                'PROPERTYADDRESSONE': str(record.get('addrLnOneCollOne')),
                'PROPERTYADDRESSTWO': str(record.get('addrLnTwoCollOne')),
                'PROPERTYCITY': str(record.get('districtPOVO')),
                'PROPERTYSTATE': str(record.get('stateLegal')),
                'PROPERTYPINCODE': str(record.get('pincodePOVO')),
                'NOMINEENAME': str(record.get('subProdutNomineeName')),
                'RELATIONSHIP': str(record.get('subProductNomineeRelation')),
                'SZ_PAN': str(record.get('panNumber')),
                'ROI_difference': str(record.get('roiDiffereceNego')),
                'FinalRoi': str(record.get('mnNegLoanRate')),
                'REGION': str(record.get('region')),
                'Split_Loan': str(record.get('splitLoan')),
                'Flow_Name': str(record.get('flowName')),
                'Created_DateTime': str(record.get('cre_time')),
                'Modified_DateTime': str(record.get('mod_time')),
                'REJECTION_REASON': str(record.get('_latestComments', {}).get('code', '')) if isinstance(record.get('_latestComments'), dict) else ''
                # 'REJECTION_REASON': str(record['_latestComments']['code']) if isinstance(record['_latestComments'], dict) else 'BLANK'
                # 'REJECTION_REASON': record.get('code')
               # 'REJECTION_REASON': str(record['_latestComments'])
                
            }
    table.append(row)  # Append the row to the table list


result_df_mis = pd.DataFrame(table)

if not result_df_mis.empty:
    result_df_mis.replace(['NaN', 'None', 'nan', '', 'N/A'], np.nan, inplace=True)
    result_df_mis.fillna('', inplace=True)

    spark_df_mis = spark.createDataFrame(result_df_mis)
    
    spark_df_mis = spark_df_mis.withColumn("Created_DateTime", from_utc_timestamp(col("Created_DateTime"), "Asia/Kolkata"))
    spark_df_mis = spark_df_mis.withColumn("Created_DateTime", date_format(col("Created_DateTime"), "yyyy-MM-dd hh:mm:ss"))
    spark_df_mis = spark_df_mis.withColumn("Modified_DateTime", from_utc_timestamp(col("Modified_DateTime"), "Asia/Kolkata"))
    spark_df_mis = spark_df_mis.withColumn("Modified_DateTime", date_format(col("Modified_DateTime"), "yyyy-MM-dd hh:mm:ss"))
    spark_df_mis = spark_df_mis.withColumn('SUB_PRODUCT', lit(''))\
                           .withColumn('Tranche_Amount_1', lit(''))\
                           .withColumn('Tranche_Amount_2', lit(''))\
                           .withColumn('Tranche_Amount_3', lit(''))\
                           .withColumn('EB_OUTSTANDING_AMT', lit(''))\
                           .withColumn('I_DSB_SRNO', lit(''))\
                           .withColumn('DISBURSED_AMT', lit(''))\
                           .withColumn('FINAL_DISB_FLAG', lit(''))\
                           .withColumn('DISB_SRNO', lit(''))\
                           .withColumn('Documentation_fee_Excl_GST_Standard_amount', lit(''))\
                           .withColumn('SZ_OLDLAN', lit(''))

    spark_df_mis = spark_df_mis.select('Applicant_Id','SZ_APPLICATION_NO','CUSTOMER_ID','BRANCH_CD','CRO_CODE','VCP_ID','VCP_NAME','GENDER','DT_BIRTH_DTE',
            'AGE','SZ_MARITAL_STATUS','SZ_EDUCTION_LEVEL','MOBILE_NO','LOAN_AMOUNT','APPLIEDAMOUNT','EB_OUTSTANDING_AMT','I_TENOR','collateralOneId','collateralTwoId','F_INTEREST_RATE','APPLICATION_FEE','FEE_PAYMENT_STATUS','CREATION_DT','SANCTIONED_AMT','I_DSB_SRNO','DISBURSED_AMT','PRIMARY_LIVELIHOOD','TOTAL_INCOME','F_TOTAL_VAL','CIBIL_SCORE','PROPERTY_TYPE','SECTORS','SUB_SECTORS','LOGIN_STATUS','CUSTOMER_TYPE_SOURCING','CUSTOMER_NAME','EB_CLOSURE_AMT_MTD','FINAL_DISB_FLAG','TENOR_FINALLOAN_PERIOD','F_ACTUAL_EMI','Branch_Product','Current_Step_Name','Existing_Customer','Facility_Type','PRODUCT','Max_Loan_Amount','DSR_Value','ROI','EMI','Assesment_Method_Policy','Final_EMI_Amount',
                'Limit_Requested','Limit_Proposed','RO1','Tenor','DSR','Current_Obligations','Customer_Comfortable_EMI','Asset_Created_within_4_years'       ,'No_Of_Collaterals_Offered','Sampatti_End_Use','Occupancy_Type','Collateral_Scheme','Fair_Makret_Value','Assesment_Method','Net_Profit_Considered','Additional_Income','Total_net_Income','Max_Eligible_EMI','Proposed_Limit','Product_Cap','Collateral_Cap','CFA','Comfortable_EMI','Sampatti_Margin','MAXIMUM_LOAN_WHICH_CAN_BE_APPROVED_TO_THE_CUSTOMER','Actual_DSR','Actual_LTV','TENOR_IN_Months','ASSESSMENT_METHOD_CONSIDERD','PRODUCT_CONSIDERED','Sampatti_margin_calculation','Final_Loan_Amount','Final_EMI','Loan_Period','Rate','RCU_Final_Status','RCU_KYC_Status','Dedupe_Status','limitDataEntry','Product_Selected_is_Sampatti','Branch_Tier','Rate_Card',
                'branchCro','roiTierOne','roiTierTwo','roiTierThree','Property_Type_2','ROI_Sampatti','Temporary_Business','Difference_in_ROI_Approval', 'Deviation_Level','Processing_fee_Excluding_GST_Standard_amount','Processing_fee_amount','Collection_type','Waived_Processing_Fee','Processing_fee_Collected_amount_incl_GST','Enter_the_actual_waiver','Documentation_fee_Excl_GST_Standard_amount','Documentation_fee_Incl_GST_Collected_amount','Legal_and_valuation_fee','Insurance_amount_collected_Kotak','Insurance_amount_collected_ICICI','SALUTATION','AddressLineOne','AddressLineTwo','CITY','STATE','PINCODE','PROPERTYADDRESSONE','PROPERTYADDRESSTWO',
                'PROPERTYCITY','PROPERTYSTATE','PROPERTYPINCODE','NOMINEENAME','RELATIONSHIP','SZ_PAN','ROI_difference','FinalRoi','REGION','Split_Loan','Flow_Name','Created_DateTime','Modified_DateTime','REJECTION_REASON','SZ_OLDLAN','tranche_amount_3','tranche_amount_2','tranche_amount_1')	


############
    utc_time = datetime.utcnow()
    ist_time = utc_time + timedelta(hours=5, minutes=30)
    formatted_date_time = ist_time.strftime("%Y-%m-%d %H:%M:00")
    formatted_today_date = ist_time.strftime("%Y-%m-%d")
            
    spark_df_mis.repartition(1).write.format("csv") \
        .option("header", "true") \
        .mode("overwrite") \
        .save(f"s3://vistaar-los-mongodb/Incremental/vistaarlosdb/oaoapplications_rejected"+
        f"{formatted_today_date}/{formatted_date_time}/")	
	
    r_user='vf_admin'
    r_pass='Vfadmin@12345'
    
    # spark_df_mis.write \
    #             .format("io.github.spark_redshift_community.spark.redshift") \
    #             .option("url", "jdbc:redshift://vf-prod-redshift-cluster.cimscijokmzf.ap-south-1.redshift.amazonaws.com:5439/prod?user={}&password={}".format(r_user,r_pass)) \
    #             .option("preactions", f"Truncate table los_stg.mis_variables;")\
    #             .option("dbtable", f"los_stg.mis_variables") \
    #             .option("tempdir", f"s3://vistaar-lms-oracle/Full_load/temp/") \
    #             .option("postactions", f"CALL los.sp_mis_variables();") \
    #             .option("aws_iam_role", "arn:aws:iam::975050328457:role/Redshift-Read-write-Prod") \
    #             .mode("append") \
    #             .save()

else:
    print("Dataframe is  is empty. No further processing performed.")
#################################################################
