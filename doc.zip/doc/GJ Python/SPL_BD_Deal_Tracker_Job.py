#importing all required modules, library and packages.
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
import sys 
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.user_credential import UserCredential
import pandas as pd
from io import StringIO
import boto3
from awsglue.utils import getResolvedOptions # library used for accessing environment variables
from datetime import datetime, timedelta
import logging


# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    # Retrieve command line arguments
    command_line_args = getResolvedOptions(sys.argv, ['SHAREPOINT_URL', 'SHAREPOINT_UN', 'SHAREPOINT_PW'])
    
    site_url = command_line_args['SHAREPOINT_URL']  # SharePoint site URL
    username = command_line_args['SHAREPOINT_UN'] # SharePoint username
    password = command_line_args['SHAREPOINT_PW'] # SharePoint password
    
    logger.info("Environment variable accessed successfully.")
    # print("Environment variable accessed successfully.")
    
except KeyError as e:
     # Log an error and exit if required environment variables are missing
    logger.error(f"Failed to get SharePoint data: {e}")
    # print(f"Environment variables could not be accessed; the password may have been changed : {e}")
    sys.exit(1)  # Exit if essential environment variables are missing
    
# Initialize Spark and Glue contexts
sc = SparkContext()
glue_context = GlueContext(sc)
spark = glue_context.spark_session

# Initialize Glue Job
job = Job(glue_context)
job.init("SPL_BD_Deal_Tracker_Job")
    
# Initialize boto3 clients
s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')
bucket = 'bd-data-prod' # S3 bucket name

def print_progress(items):
     # Function to print the progress of items read from SharePoint
    print("Total items read in BD Deals Tracker are:- : {0}".format(len(items)))

# Connect to SharePoint
logger.info("accessing office365 Client (URL)")
ctx = ClientContext(site_url).with_credentials(UserCredential(username, password)) # Authenticate with SharePoint
large_list = ctx.web.lists.get_by_title("BD Deals Tracker") # Access the specific SharePoint list i.e. BD Deals Tracker
paged_items = (
    large_list.items.paged(1000, page_loaded=print_progress).get().execute_query() # Fetch items with pagination
) #1000 is the batch size of records we are suppose to take. We may increased this or decrease. 

logger.info("accessing office365 Client (URL) successfully")
# Process items retrieved from SharePoint
data = []
column_names = []

logger.info("Entering into for loop")
for item in paged_items:
    item_properties = item.properties # Append item properties to the data list
    data.append(item_properties)
    # Update column names list to include any new columns found
    column_names.extend([key for key in item_properties.keys() if key not in column_names])

# Convert the data into a pandas DataFrame
df = pd.DataFrame(data, columns=column_names)

# Apply various transformations as per requirements
# Select and rename columns
selected_columns_df = df[['DueDate', 'DASigningDate', 'Category0', 'DealType', 'StartDate',
                          'Priority', 'Title','LandArea_x0028_InAcres_x0029_',
                          'FSIPotential_x0028_InLacSq_x002e', 'RevenuePotential_x0028_InRsCrs_x',
                          'Progress', 'BEEBIT_x0028_InRsCr_x0029_',
                          'LandCost_x002b_StampDuty_x002b_S','FundsDeploymentQuarter',
                          'ExpDateofChairmanSubmission']]

#Renaming Columns name as per requirement.
rename_columns_df = selected_columns_df.rename({
    'DueDate': 'City',
    'Category0': 'Deal Stage',
    'StartDate': 'Deal Received Date',
    'LandArea_x0028_InAcres_x0029_': 'LandArea_InAcres',
    'FSIPotential_x0028_InLacSq_x002e': 'FSIPotential_InLacSq',
    'RevenuePotential_x0028_InRsCrs_x': 'RevenuePotential_InRsCrs',
    'Progress': 'Region',
    'BEEBIT_x0028_InRsCr_x0029_': 'BEEBIT_InRsCr',
    'LandCost_x002b_StampDuty_x002b_S': 'LandCost_StampDuty',
    'FundsDeploymentQuarter': 'Funds_Deployment_Quarter',
    'ExpDateofChairmanSubmission': 'Exp_Date_ofChairman_Submission'
}, axis=1) 



# Extract values from 'Deal Stage' column example: {0: 'Rejected'} = Rejected
def extract_deal_stage_value(deal_stage):
    if isinstance(deal_stage, dict) and 0 in deal_stage:
        return deal_stage[0]
    return deal_stage

rename_columns_df['Deal Stage'] = rename_columns_df['Deal Stage'].apply(extract_deal_stage_value)

# Define the mapping for replacing values in Deal Stage column
deal_stage_mapping = {
    'Initial Stage': 'Under Evaluation',
    'TDD - Term Sheet': 'Term Sheet',
    'On Hold': 'Rejected',
    'Commercial Negotiation': 'Under Discussion',
    'Commercial Closed': 'Pre-Term Sheet',
    'DA Signed': 'Definitive Agreement',
    'Rejected': 'Rejected'
}

# Apply the mapping
rename_columns_df['Deal Stage'] = rename_columns_df['Deal Stage'].replace(deal_stage_mapping)

deal_type_mapping = {
    "Deferred Outright" : "FSI Sale",
    "JDA - Area Share"  : "JV/JDA - Area Sharing",
    "JDA - Equity Share" : "JV/JDA - Equity Sharing",
    "JDA - Profit Share" : "Profit Sharing",
    "JDA - Revenue Share" : "JV/JDA - Revenue Sharing",
    "Outright" : "Outright Sale",
    
}

rename_columns_df['DealType'] = rename_columns_df['DealType'].replace(deal_type_mapping).fillna('DM')


# Convert date columns to pandas datetime format and format them to YYYY-MM-DD
rename_columns_df['DASigningDate'] = pd.to_datetime(rename_columns_df['DASigningDate']).dt.strftime('%Y-%m-%d')
rename_columns_df['Deal Received Date'] = pd.to_datetime(rename_columns_df['Deal Received Date']).dt.strftime('%Y-%m-%d')


final_df = rename_columns_df

# Save DataFrame to CSV and upload to S3
logger.info("csv_buffer file is generating to save DF to s3 bucket")
csv_buffer = StringIO()  
final_df.to_csv(csv_buffer, index=False)
today = datetime.now().strftime("%Y-%m-%d")
filepath = f"SharePoint_data/BD_Deal_Tracker_Files/BD_Deal_Tracker_{today}.csv"
s3_resource.Object(bucket, filepath).put(Body=csv_buffer.getvalue())

logger.info(f"File BD_Deal_Tracker_{today}.csv has successfully been uploaded to this bucket {bucket}")
# Commit Glue job
job.commit()