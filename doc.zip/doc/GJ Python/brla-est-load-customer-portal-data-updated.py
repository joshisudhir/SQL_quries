import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SQLContext
from pyspark.sql.functions import col
import json
import boto3
from botocore.exceptions import ClientError

secret_name = "redshiftcredential-prod"
region_name = "ap-south-1"

# Create a Secrets Manager client
session = boto3.session.Session()
client = session.client(
service_name='secretsmanager',
region_name=region_name )
get_secret_value_response = client.get_secret_value(SecretId=secret_name)


secret = get_secret_value_response['SecretString']
secret = json.loads(secret)
db_username = secret.get('username')
db_password = secret.get('password')
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
sqlContext = SQLContext(sc)

s3 = boto3.client('s3')
bucket = "bd-data-prod"

redshift_url = "jdbc:redshift://redshift-cluster-birla-estates-prod.c89v6okyyhza.ap-south-1.redshift.amazonaws.com:5439/finance_db_dev"


CUST_PORT_CUSTINFO_TBL = f"s3://{bucket}/Customer_Portal/tblcustomerproject_fullfile.csv"
CUST_PORT_DOCUMENTS_TBL = f"s3://{bucket}/Customer_Portal/tbldocument_fullfile.csv"
CUST_PORTAL_OTP_TBL = f"s3://{bucket}/Customer_Portal/tblotp_fullfile.csv"

tables = ["CUST_PORT_CUSTINFO_TBL", "CUST_PORT_DOCUMENTS_TBL", "CUST_PORTAL_OTP_TBL"]

print("For Loop is been Started")

for table, path in zip(tables, [CUST_PORT_CUSTINFO_TBL, CUST_PORT_DOCUMENTS_TBL, CUST_PORTAL_OTP_TBL]):

    try:
        response = s3.head_object(Bucket=bucket, Key=path.split(bucket + '/')[1])
        df = sqlContext.read.load(path, format='csv', delimiter=',', header='true', inferSchema='false')
        print(f"the table {table} is successfully read from this location {path} ")
        df.repartition(1).write.mode("overwrite").option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false").option("header", "true").options(quotes = '"').options(delimiter=',').csv(f"s3://{bucket}/testfile/")
        # df = df.select(df.columns[:4])
        # df.show()
        # we need to make folders of each table to call 
        print(f"Writing data to redshift for table {table}")
        try:
            df.write.format("com.databricks.spark.redshift") \
                .option("url", f"{redshift_url}?user={db_username}&password={db_password}") \
                .option('preactions', f"Truncate table dbo.stg_{table.lower()};") \
                .option('postactions', f"CALL dbo.sp_load_{table.lower()}();") \
                .option("dbtable", f"dbo.stg_{table.lower()}") \
                .option("tempdir", f"s3://{bucket}/temp") \
                .option("aws_iam_role", "arn:aws:iam::222814654508:role/RedshiftCopyUnload-Prod") \
                .mode("append") \
                .save()
            print(f"Data has been successfully written to the stg_{table}")
        except Exception as e:
            print(f"Error writing data to Redshift for table {table}: {e}")
    except Exception as e:
        print(f"The file for table {table} does not exist at location: {path}. Hence, Skipping...")
        continue  # Skip to the next table if there's an error

