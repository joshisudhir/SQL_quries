
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

import requests
import boto3
import json
import tableauserverclient as TSC
import re
from io import BytesIO
import pandas as pd
import requests
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)


bucket_name = "whatsappimage-new"
s3_key = "BudgetVsActual.png"


# Initialize boto3 S3 client with credentials
s3_client = boto3.client(
    's3',
    aws_access_key_id='AKIATHYGJ2AWMJDSL5H5',
    aws_secret_access_key='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'
)


# Configure for TSC to publish
# Note: Do not store creds/tokens in plaintext, please use env vars :)
hyper_name = 'superstore.hyper'
server_address = 'https://prod-apnortheast-a.online.tableau.com'
site_name = 'birlaestates'
project_name = 'Whatsapp_Automation'
token_name = 'whatsappautomation'
token_value = '6F2AeANRTu+j0ukFZnPgnA==:csU7RfHCYInKASudXtxeel7fySFbw62H'


tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=token_value, site_id=site_name)
server = TSC.Server(server_address, use_server_version=True)


#Export the image from tableau and upload it into S3 bucket directly
with server.auth.sign_in(tableau_auth):
    view_id = '92a91885-1550-4782-9de3-e1adf34f5720'
    view_item = server.views.get_by_id(view_id)
    server.views.populate_image(view_item)
    
    # Save the image into a BytesIO object instead of writing to a local file
    image_data = BytesIO(view_item.image)

    # Upload the image data to S3
    s3_client.upload_fileobj(image_data, bucket_name, s3_key)

    print(f"Image uploaded to S3: s3://{bucket_name}/{s3_key}")
# S3 bucket name and folder (prefix) path in the bucket
bucket_name = 'brla-est-sap-tables-bucket'
folder_prefix = 'saptables/ZFI_BBC'  # Folder where the files are stored

# List objects in the specified S3 folder
response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=folder_prefix)

# Get the list of files with their LastModified date
files = response.get('Contents', [])
if not files:
    print("No files found in the specified S3 folder.")
else:
    # Find the latest file by the LastModified date
    latest_file = max(files, key=lambda x: x['LastModified'])

    print(f"Latest file found: {latest_file['Key']}")

    # Retrieve the latest CSV file from S3
    csv_obj = s3_client.get_object(Bucket=bucket_name, Key=latest_file['Key'])

    # Read the CSV data into a pandas DataFrame
    csv_data = pd.read_csv(BytesIO(csv_obj['Body'].read()))

# csv_data

aggregated_values = csv_data[['BOOKING_BUDGET_FTM.1', 'BOOKING_ACTUAL_YTD','BOOKING_BUDGET_FTM','BOOKING_ACTUAL_FTM','BILLING_BUDGET_YTD','BILLING_ACTUAL_YTD','BILLING_BUDGET_FTM','BILLING_ACTUAL_FTM','COLLECTION_BUDGET_YTD','COLLECTION_ACTUAL_YTD','COLLECTION_BUDGET_FTM','COLLECTION_ACTUAL_FTM']].sum()
aggregated_values

aggregated_row = pd.DataFrame({
    'PROJECT_NAME': ['All Projects'],   # Adding the constant header and value
    'MobileNumber': ['8879393782'],
    'BOOKING_BUDGET_FTM.1': [aggregated_values['BOOKING_BUDGET_FTM.1']],
    'BOOKING_ACTUAL_YTD': [aggregated_values['BOOKING_ACTUAL_YTD']],
    'BOOKING_BUDGET_FTM': [aggregated_values['BOOKING_BUDGET_FTM']],
    'BOOKING_ACTUAL_FTM': [aggregated_values['BOOKING_ACTUAL_FTM']],
    'BILLING_BUDGET_YTD': [aggregated_values['BILLING_BUDGET_YTD']],
    'BILLING_ACTUAL_YTD': [aggregated_values['BILLING_ACTUAL_YTD']],
    'BILLING_BUDGET_FTM': [aggregated_values['BILLING_BUDGET_FTM']],
    'BILLING_ACTUAL_FTM': [aggregated_values['BILLING_ACTUAL_FTM']],
    'COLLECTION_BUDGET_YTD': [aggregated_values['COLLECTION_BUDGET_YTD']],
    'COLLECTION_ACTUAL_YTD': [aggregated_values['COLLECTION_ACTUAL_YTD']],
    'COLLECTION_BUDGET_FTM': [aggregated_values['COLLECTION_BUDGET_FTM']],
    'COLLECTION_ACTUAL_FTM': [aggregated_values['COLLECTION_ACTUAL_FTM']]
})

# aggregated_row
#update the image content type and ContentDisposition
def update_content_type(bucket_name, s3_key):
    """
    Updates the Content-Type of an existing object in S3.
    """
  

    # Copy the object to itself, while updating the metadata
    try:
        s3_client.copy_object(
            Bucket='whatsappimage-new',
            CopySource={'Bucket': 'whatsappimage-new', 'Key': 'BudgetVsActual.png'},
            Key='BudgetVsActual.png',
            MetadataDirective='REPLACE',
            ContentType='image/png',  # Set the correct content type
            ContentDisposition='inline',  # Set Content-Disposition to inline
            ACL='public-read'
        )
        print(f"Content-Type of BudgetVsActual.png updated to image/png")
    except Exception as e:
        print(f"Error updating Content-Type: {e}")

# Example usage
update_content_type('whatsappimage-new', 'BudgetVsActual.png')

Image = 'https://whatsappimage-new.s3.ap-south-1.amazonaws.com/BudgetVsActual.png'

for index, row in aggregated_row.iterrows():
    ProjectName = row['PROJECT_NAME']
    Mobile = row['MobileNumber']
    #Booking
    Budget_Booking_YTD = row['BOOKING_BUDGET_FTM.1']
    Actual_Booking_YTD = row['BOOKING_ACTUAL_YTD']
    Budget_Booking_FTD = row['BOOKING_BUDGET_FTM']
    Actual_Booking_FTD = row['BOOKING_ACTUAL_FTM']
    #Billing
    Budget_Billing_YTD = row['BILLING_BUDGET_YTD']
    Actual_Billing_YTD = row['BILLING_ACTUAL_YTD']
    Budget_Billing_FTD = row['BILLING_BUDGET_FTM']
    Actual_Billing_FTD = row['BILLING_ACTUAL_FTM']
    #Collection
    Budget_Collection_YTD = row['COLLECTION_BUDGET_YTD']
    Actual_Collection_YTD = row['COLLECTION_ACTUAL_YTD']
    Budget_Collection_FTD = row['COLLECTION_BUDGET_FTM']
    Actual_Collection_FTD = row['COLLECTION_ACTUAL_FTM']
    
    url = f"https://media.smsgupshup.com/GatewayAPI/rest?userid=2000224168&password=WYxJruK%23&send_to={Mobile}&v=1.1&format=json&msg_type=IMAGE&method=SENDMEDIAMESSAGE&caption=Hello%2C%0ABelow+is+key+Information+on+Billing%2C+Booking+and+Collection.%0A%0AProject++%3A+{ProjectName}%0A%0ABooking%0AActual+for+the+Month++++++++++++++++++++%3A+{Actual_Booking_FTD}%0ABudget+for+the+Month++++++++++++++++++%3A+{Budget_Booking_FTD}%0AActual+for+the+FY-TD++++++++++++++++++++%3A+{Actual_Booking_YTD}%0ABudget+for+the+FY-TD+++++++++++++++++++%3A+{Budget_Booking_YTD}%0A%0ABilling%0AActual+for+the+Month+++++++++++++++++++%3A+{Actual_Billing_FTD}%0ABudget+for+the+Month++++++++++++++++++%3A+{Budget_Billing_FTD}%0AActual+for+the+FY-TD++++++++++++++++++++%3A+{Actual_Billing_YTD}%0ABudget+for+the+FY-TD+++++++++++++++++++%3A+{Budget_Billing_YTD}%0A%0ACollection%0AActual+for+the+Month+++++++++++++++++++%3A+{Actual_Collection_FTD}%0ABudget+for+the+Month++++++++++++++++++%3A+{Budget_Collection_FTD}%0AActual+for+the+FY-TD++++++++++++++++++++%3A+{Actual_Collection_YTD}%0ABudget+for+the+FY-TD+++++++++++++++++++%3A+{Actual_Collection_YTD}&media_url={Image}&isTemplate=true&footer=Birla+Estates"
    
#     submit request for each constructed URL to whatsapp server
    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)
#     print(url)
# pip install --target ./package urllib3==1.26.5 boto3==1.24.10 botocore==1.27.10
# zip -r9 package.zip ./package
job.commit()