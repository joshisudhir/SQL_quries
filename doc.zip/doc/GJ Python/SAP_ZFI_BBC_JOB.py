import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SQLContext
from pyspark.sql.functions import col, lit, split
import json
import boto3
from datetime import datetime

# Boto3 session to get credentials from Secrets Manager
secret_name = "redshiftcredential-prod"
region_name = "ap-south-1"
session = boto3.session.Session()
client = session.client(service_name='secretsmanager', region_name=region_name)

# Retrieve Redshift credentials
get_secret_value_response = client.get_secret_value(SecretId=secret_name)
secret = json.loads(get_secret_value_response['SecretString'])
db_username = secret.get('username')
db_password = secret.get('password')

# # Initialize Spark and Glue context
# sc = SparkContext.getOrCreate()
# glueContext = GlueContext(sc)
# spark = glueContext.spark_session
# sqlContext = SQLContext(sc)

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
sqlContext = SQLContext(sc)

# S3 details
s3 = boto3.client('s3')
bucket = "brla-est-sap-tables-bucket"
prefix = "saptables/ZFI_BBC/"
redshift_url = "jdbc:redshift://redshift-cluster-birla-estates-prod.c89v6okyyhza.ap-south-1.redshift.amazonaws.com:5439/dev"

# List objects in the S3 bucket to find the latest file
response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)

latest_file = None
latest_time = None
for obj in response.get('Contents', []):
    if latest_time is None or obj['LastModified'] > latest_time:
        latest_time = obj['LastModified']
        latest_file = obj['Key']

print(f"Latest file found: {latest_file}")

if latest_file:
    # Load the latest file into a DataFrame
    s3_path = f"s3://{bucket}/{latest_file}"
    df = sqlContext.read.load(s3_path, format='csv', delimiter=',', header='true', inferSchema='false')

    # Add additional columns
    current_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    df = df.withColumn("file_name", lit(latest_file).alias("file_name")) \
           .withColumn("file_name", split(col("file_name"), "/").getItem(2)) \
           .withColumn("LastModifiedDate", lit(latest_time.strftime('%Y-%m-%d %H:%M:%S'))) \
           .withColumn("currentTimeStamp", lit(current_timestamp))

    # Reorder columns as required
    column_order = [
        "vkorg", "region", "project_name", "booking_budget_ftm3", "booking_actual_ftm", 
        "billing_budget_ftm", "billing_actual_ftm", "collection_budget_ftm", "collection_actual_ftm", 
        "booking_budget_ftm9", "booking_actual_ytd", "billing_budget_ytd", "billing_actual_ytd", 
        "collection_budget_ytd", "collection_actual_ytd", "file_name", "LastModifiedDate", 
        "currentTimeStamp", "OUTSTANDING"
    ]
    
    df = df.select(column_order)# Write the DataFrame to Redshift, truncating the table first
    df.write.format("com.databricks.spark.redshift") \
        .option("url", f"{redshift_url}?user={db_username}&password={db_password}") \
        .option('preactions', "TRUNCATE TABLE fin.zfi_bbc_tbl;") \
        .option("dbtable", "fin.zfi_bbc_tbl") \
        .option("tempdir", f"s3://{bucket}/temp") \
        .option("aws_iam_role", "arn:aws:iam::222814654508:role/RedshiftCopyUnload-Prod") \
        .mode("append") \
        .save()
    print("Data has been successfully written to the fin.zfi_bbc_tbl table in Redshift.")





















# import sys
# from awsglue.transforms import *
# from awsglue.utils import getResolvedOptions
# from pyspark.context import SparkContext
# from awsglue.context import GlueContext
# from awsglue.job import Job
# from pyspark.sql import SQLContext
# from pyspark.sql.functions import col, lit, split
# import json
# import boto3
# from botocore.exceptions import ClientError
# from datetime import datetime, timedelta

# s3 = boto3.client('s3')
# redshift_url = "jdbc:redshift://redshift-cluster-birla-estates-prod.c89v6okyyhza.ap-south-1.redshift.amazonaws.com:5439/dev"
# secret_name = "redshiftcredential-prod"
# region_name = "ap-south-1"

# # Create a Secrets Manager client
# session = boto3.session.Session()
# client = session.client(service_name='secretsmanager', region_name=region_name)

# # Retrieve Redshift credentials
# get_secret_value_response = client.get_secret_value(SecretId=secret_name)
# secret = json.loads(get_secret_value_response['SecretString'])
# db_username = secret.get('username')
# db_password = secret.get('password')

# sc = SparkContext.getOrCreate()
# glueContext = GlueContext(sc)
# spark = glueContext.spark_session
# job = Job(glueContext)
# sqlContext = SQLContext(sc)

# bucket = "brla-est-sap-tables-bucket"
# prefix = "saptables/ZFI_BBC/"

# # List objects in the S3 bucket
# response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)

# # print(f"This is responce {response}")

# # Find the latest file
# latest_file = None
# latest_time = None
# for obj in response.get('Contents', []):
#     if latest_time is None or obj['LastModified'] > latest_time:
#         latest_time = obj['LastModified']
#         latest_file = obj['Key']
# print(f"this is latest file {latest_file}")
# if latest_file:
#     # Load the latest file into a DataFrame
#     s3_path = f"s3://{bucket}/{latest_file}"
#     df = spark.read.option("header", "true").csv(s3_path)
#     current_timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#     #Adding 3 required columns to the df 
#     df = df.withColumn("file_name", lit(latest_file)) \
#       .withColumn("file_name", split(col("file_name"), "/").getItem(2))
#     df = df.withColumn("LastModifiedDate", lit(latest_time.strftime('%Y-%m-%d %H:%M:%S')))
#     df = df.withColumn("currentTimeStamp", lit(current_timestamp))
    
    
#     column_order = [
#     "vkorg", "region", "project_name", 
#     "booking_budget_ftm3", "booking_actual_ftm", "billing_budget_ftm", "billing_actual_ftm", 
#     "collection_budget_ftm", "collection_actual_ftm", "booking_budget_ftm9", "booking_actual_ytd", 
#     "billing_budget_ytd", "billing_actual_ytd", "collection_budget_ytd", "collection_actual_ytd",
#     "file_name", "LastModifiedDate", "currentTimeStamp", "OUTSTANDING"]
    
#     df = df.select(column_order)
    
#     # df.show()
#     # Write the DataFrame to Redshift in append mode
#     df.write \
#       .format("jdbc") \
#       .option("url", redshift_url) \
#       .option('preactions', f"Truncate table fin.zfi_bbc_tbl;") \
#       .option("dbtable", "fin.zfi_bbc_tbl") \
#       .option("user", db_username) \
#       .option("password", db_password) \
#       .option("driver", "com.amazon.redshift.jdbc42.Driver") \
#       .mode("append") \
#       .save()
# print("Data is been appended to the fin.zfi_bbc_tbl table")
# # job.commit()
