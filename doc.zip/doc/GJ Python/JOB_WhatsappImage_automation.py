import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import requests
import boto3
import json
import tableauserverclient as TSC
import re
from io import BytesIO
import pandas as pd
import requests
import psycopg2  # Added for Redshift connection

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

bucket_name = "whatsappimage-new"
s3_key = "BudgetVsActual.png"

# Initialize boto3 S3 client with credentials
s3_client = boto3.client('s3')

# Configure for TSC to publish
# Note: Do not store creds/tokens in plaintext, please use env vars :)
hyper_name = 'superstore.hyper'
server_address = 'https://prod-apnortheast-a.online.tableau.com'
site_name = 'birlaestates'
project_name = 'Whatsapp_Automation'
token_name = 'whatsappautomation'
token_value = '6F2AeANRTu+j0ukFZnPgnA==:csU7RfHCYInKASudXtxeel7fySFbw62H'

tableau_auth = TSC.PersonalAccessTokenAuth(token_name=token_name, personal_access_token=token_value, site_id=site_name)
server = TSC.Server(server_address, use_server_version=True)

# Export the image from Tableau and upload it into S3 bucket directly
with server.auth.sign_in(tableau_auth):
    view_id = '92a91885-1550-4782-9de3-e1adf34f5720'
    image_req_option = TSC.ImageRequestOptions(imageresolution=TSC.ImageRequestOptions.Resolution.High, maxage=1)
    view_item = server.views.get_by_id(view_id)
    server.views.populate_image(view_item, image_req_option)
    # Save the image into a BytesIO object instead of writing to a local file
    image_data = BytesIO(view_item.image)

    # Upload the image data to S3
    s3_client.upload_fileobj(image_data, bucket_name, s3_key)

    print(f"Image uploaded to S3: s3://{bucket_name}/{s3_key}")

# Update the image content type and ContentDisposition
def update_content_type(bucket_name, s3_key):
    """
    Updates the Content-Type of an existing object in S3.
    """
    # Copy the object to itself, while updating the metadata
    try:
        s3_client.copy_object(
            Bucket=bucket_name,
            CopySource={'Bucket': bucket_name, 'Key': s3_key},
            Key=s3_key,
            MetadataDirective='REPLACE',
            ContentType='image/png',  # Set the correct content type
            ContentDisposition='inline',  # Set Content-Disposition to inline
            ACL='public-read'
        )
        print(f"Content-Type of {s3_key} updated to image/png")
    except Exception as e:
        print(f"Error updating Content-Type: {e}")

# Example usage
update_content_type(bucket_name, s3_key)

# Read data directly from Redshift
import psycopg2

# Redshift connection details
host = 'redshift-cluster-birla-estates-prod.c89v6okyyhza.ap-south-1.redshift.amazonaws.com'
port = '5439'
dbname = 'dev'
user = 'awsuser'
password = 'Redshift!12345'

conn = psycopg2.connect(
    host=host,
    port=port,
    dbname=dbname,
    user=user,
    password=password
)

# Create a cursor to execute queries
cur = conn.cursor()
cur.execute("SELECT * FROM dev.fin.zfi_bbc_tbl")

# Fetch results
rows = cur.fetchall()

colnames = [desc[0] for desc in cur.description]

# Convert to pandas DataFrame
df = pd.DataFrame(rows, columns=colnames)

# Close cursor and connection
cur.close()
conn.close()

# Calculate aggregated values
aggregated_values = df[['booking_budget_ftm3', 'booking_actual_ftm', 'billing_budget_ftm', 'billing_actual_ftm',
                        'collection_budget_ftm', 'collection_actual_ftm', 'booking_budget_ftm9', 'booking_actual_ytd',
                        'billing_budget_ytd', 'billing_actual_ytd', 'collection_budget_ytd', 'collection_actual_ytd',
                        'outstanding']].sum()

aggregated_row = pd.DataFrame({
    'PROJECT_NAME': ['All Projects'],   # Adding the constant header and value
    #'MobileNumber': ['8588815801'],#8879393782
    'BOOKING_BUDGET_FTM.1': [aggregated_values['booking_budget_ftm3']],
    'BOOKING_ACTUAL_FTM': [aggregated_values['booking_actual_ftm']],
    'BILLING_BUDGET_FTM': [aggregated_values['billing_budget_ftm']],
    'BILLING_ACTUAL_FTM': [aggregated_values['billing_actual_ftm']],
    'COLLECTION_BUDGET_FTM': [aggregated_values['collection_budget_ftm']],
    'COLLECTION_ACTUAL_FTM': [aggregated_values['collection_actual_ftm']],
    # YTD
    'BOOKING_BUDGET_FTM': [aggregated_values['booking_budget_ftm9']],
    'BOOKING_ACTUAL_YTD': [aggregated_values['booking_actual_ytd']],
    'BILLING_BUDGET_YTD': [aggregated_values['billing_budget_ytd']],
    'BILLING_ACTUAL_YTD': [aggregated_values['billing_actual_ytd']],
    'COLLECTION_BUDGET_YTD': [aggregated_values['collection_budget_ytd']],
    'COLLECTION_ACTUAL_YTD': [aggregated_values['collection_actual_ytd']],
    'OUTSTANDING': [aggregated_values['outstanding']]
})

Image = 'https://whatsappimage-new.s3.ap-south-1.amazonaws.com/BudgetVsActual.png'
MobileNumberList = ['8588815801', '8879393782', '7738374023','8605242519']

for index, row in aggregated_row.iterrows():
    ProjectName = row['PROJECT_NAME']
    # Booking
    Budget_Booking_FTD = row['BOOKING_BUDGET_FTM.1']
    Actual_Booking_FTD = row['BOOKING_ACTUAL_FTM']
    Budget_Booking_YTD = row['BOOKING_BUDGET_FTM']
    Actual_Booking_YTD = row['BOOKING_ACTUAL_YTD']
    # Billing
    Budget_Billing_FTD = row['BILLING_BUDGET_FTM']
    Actual_Billing_FTD = row['BILLING_ACTUAL_FTM']
    Budget_Billing_YTD = row['BILLING_BUDGET_YTD']
    Actual_Billing_YTD = row['BILLING_ACTUAL_YTD']
    # Collection
    Budget_Collection_FTD = row['COLLECTION_BUDGET_FTM']
    Actual_Collection_FTD = row['COLLECTION_ACTUAL_FTM']
    Budget_Collection_YTD = row['COLLECTION_BUDGET_YTD']
    Actual_Collection_YTD = row['COLLECTION_ACTUAL_YTD']
    # Outstanding
    Outstanding = row['OUTSTANDING']

    for Mobile in MobileNumberList:
        url = f"https://media.smsgupshup.com/GatewayAPI/rest?userid=2000224168&password=WYxJruK%23&send_to={Mobile}&v=1.1&format=json&msg_type=IMAGE&method=SENDMEDIAMESSAGE&caption=Hello%2C%0ABelow+is+key+Information+on+Billing%2C+Booking+and+Collection.%0A%0AProject++%3A+{ProjectName}%0A%0ABooking%0AActual+for+the+Month++++++++++++++++++++%3A+{Actual_Booking_FTD}%0ABudget+for+the+Month++++++++++++++++++%3A+{Budget_Booking_FTD}%0AActual+for+the+FY-TD++++++++++++++++++++%3A+{Actual_Booking_YTD}%0ABudget+for+the+FY-TD+++++++++++++++++++%3A+{Budget_Booking_YTD}%0A%0ABilling%0AActual+for+the+Month+++++++++++++++++++%3A+{Actual_Billing_FTD}%0ABudget+for+the+Month++++++++++++++++++%3A+{Budget_Billing_FTD}%0AActual+for+the+FY-TD++++++++++++++++++++%3A+{Actual_Billing_YTD}%0ABudget+for+the+FY-TD+++++++++++++++++++%3A+{Budget_Billing_YTD}%0A%0ACollection%0AActual+for+the+Month+++++++++++++++++++%3A+{Actual_Collection_FTD}%0ABudget+for+the+Month++++++++++++++++++%3A+{Budget_Collection_FTD}%0AActual+for+the+FY-TD++++++++++++++++++++%3A+{Actual_Collection_YTD}%0ABudget+for+the+FY-TD+++++++++++++++++++%3A+{Budget_Collection_YTD}&media_url={Image}&isTemplate=true&footer=Birla+Estates"
    #     submit request for each constructed URL to whatsapp server
        payload = {}
        headers = {}
        response = requests.request("GET", url, headers=headers, data=payload)
        print(response.text)
        # print(url)

# Commit the job
job.commit()
