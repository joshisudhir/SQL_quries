from pyspark.context import SparkContext
from awsglue.context import GlueContext
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

bucket_name = "birla-est-quality-bucket"
dynamicFrame = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    connection_options={"paths": ["s3://birla-est-quality-bucket/walkin.json"]},
    format="json",
    format_options={
       "jsonPath": "$.payload",
        "multiline": False,
        # "optimizePerformance": True, -> not compatible with jsonPath, multiline
    }
)
glueContext.write_dynamic_frame.from_options(
    frame = dynamicFrame,
    connection_options = {'path': 's3://birla-est-quality-bucket/walkin_new.csv'},
    connection_type = 's3',
    format = 'csv',
)




