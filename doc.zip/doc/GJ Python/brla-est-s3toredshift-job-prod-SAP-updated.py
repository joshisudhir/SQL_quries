import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SQLContext
from pyspark.sql.functions import col
import json
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timedelta

s3 = boto3.client('s3')

secret_name = "redshiftcredential-prod"
region_name = "ap-south-1"

# Create a Secrets Manager client
session = boto3.session.Session()
client = session.client(
service_name='secretsmanager',
region_name=region_name )
get_secret_value_response = client.get_secret_value(SecretId=secret_name)


secret = get_secret_value_response['SecretString']
secret = json.loads(secret)
db_username = secret.get('username')
db_password = secret.get('password')

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
sqlContext = SQLContext(sc)
bucket = "brla-est-sap-tables-bucket"
redshift_url = "jdbc:redshift://redshift-cluster-birla-estates-prod.c89v6okyyhza.ap-south-1.redshift.amazonaws.com:5439/finance_db_dev"



underscore = "_"
today_date = datetime.now()

previous_day = today_date - timedelta(days=1)
previous_day_formatted = previous_day.strftime("%d_%m_%Y")
# print(f'{underscore}{previous_day_formatted}')

tables = ["ZSD_OS_TAB1","ZSD_COLLECT_TAB","ZSD_PLAN_INVCOL","ZSD_FS_TAB","ZSD_CUST_ID_TAB","ZSD_RI_TAB","ZSD_AGEING_TAB"]
paths = [f"s3://{bucket}/qas/{table}/{table}{underscore}{previous_day_formatted}.CSV" for table in tables]

print('Loop started')
# Read and write in a loop
for table, path in zip(tables, paths):
    try:
        response = s3.head_object(Bucket=bucket, Key=path.split(bucket + '/')[1])
        df = sqlContext.read.load(path, format='com.databricks.spark.csv', delimiter=',', header='true', inferSchema='false')
        df.repartition(1).write.mode("overwrite").option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false").option("header", "true").options(delimiter=',').csv(f"s3://{bucket}/testfile/")
        print('Writing data to redshift')
        try:
            df.write.format("com.databricks.spark.redshift") \
                .option("url", f"{redshift_url}?user={db_username}&password={db_password}") \
                .option('preactions', f"Truncate table dbo.stg_brla_est_{table.lower()};") \
                .option('postactions', f"CALL dbo.sp_load_{table.lower()}();") \
                .option("dbtable", f"dbo.stg_brla_est_{table.lower()}") \
                .option("tempdir", f"s3://{bucket}/temp") \
                .option("aws_iam_role", "arn:aws:iam::222814654508:role/RedshiftCopyUnload-Prod") \
                .mode("append") \
                .save()
            print(f"Data has been successfully written to the stg_{table}")
        except Exception as e:
            print(f"Error writing data to Redshift for table {table}: {e}")
    except Exception as e:
        print(f"The file for table {table} does not exist at location: {path}. Hence, Skipping...")
        continue  # Skip to the next table if there's an error
        
# Move files to Archive folder
s3_client = boto3.client('s3')
for table in tables:
    source_path = f"s3://{bucket}/qas/{table}/"
    archive_path = f"s3://{bucket}/qas/Archive/"
    try:
        response = s3_client.list_objects(Bucket=bucket, Prefix=f'qas/{table}/')
        if 'Contents' in response:
            for obj in response['Contents']:
                source_key = obj['Key']
                destination_key = source_key.replace('qas/', 'qas/Archive/')
                s3_client.copy_object(Bucket=bucket, CopySource={'Bucket': bucket, 'Key': source_key}, Key=destination_key)
                s3_client.delete_object(Bucket=bucket, Key=source_key)
    except ClientError as e:
        print(f"Error moving files for table {table}: {e}")
        