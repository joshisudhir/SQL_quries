import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import pandas as pd
import requests
import boto3
from io import StringIO
from datetime import datetime, timedelta
current_date = datetime.now().date()
  
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
current_date


# Specify S3 bucket and file paths
bucket_name = "birla-est-quality-bucket"
sap_bucket_name = "brla-est-sap-tables-bucket"
input_path = "s3://birla-est-quality-bucket/walkin.json"
sap_input_path = "s3://brla-est-sap-tables-bucket/qas/Archive/ZSD_OS_TAB1/ZSD_OS_TAB1_27_08_2024.CSV"
output_path = "s3://birla-est-quality-bucket/walkin_new.csv"
sap_file_key = 'qas/Archive/ZSD_OS_TAB1/ZSD_OS_TAB1_27_08_2024.CSV'

# Read the JSON file from S3
dynamicFrame = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    connection_options={"paths": [input_path]},
    format="json",
    format_options={
        "jsonPath": "$.payload",
        "multiline": False,
    }
)

s3 = boto3.client('s3')




# Read the CSV file from S3


# Convert DynamicFrame to DataFrame
dataFrame = dynamicFrame.toDF()
dataFrame.show()

# Write DataFrame to S3 in CSV format, overwriting the existing file
dataFrame.write.mode("overwrite").csv(output_path, header=True)

# Rename the part file to the desired file name
s3 = boto3.client('s3')

# List the files in the output path to find the generated part file
output_prefix = 'walkin_new.csv'
response = s3.list_objects_v2(Bucket=bucket_name, Prefix=output_prefix)
for obj in response['Contents']:
    if obj['Key'].endswith('.csv'):
        part_file_key = obj['Key']
        break

# Copy the part file to the desired file name
copy_source = {'Bucket': bucket_name, 'Key': part_file_key}
destination_key = output_prefix + '/walkin_new_fixed_name.csv'
s3.copy_object(CopySource=copy_source, Bucket=bucket_name, Key=destination_key)

# Delete the original part file
s3.delete_object(Bucket=bucket_name, Key=part_file_key)

from datetime import datetime, timedelta
current_date = datetime.now().date()

# df = pd.read_csv(r'C:\Users\SandipSharma\OneDrive - ScatterPie Analytics Private Limited\BirlaeState\WhatsAPP API\InputData\run-1722236356971-part-r-00000.csv')

# Initialize boto3 client for S3
s3 = boto3.client('s3')

# Specify your S3 bucket name and CSV file key (path)
bucket_name = 'birla-est-quality-bucket'
file_key = 'walkin_new.csv/walkin_new_fixed_name.csv'


# Read the CSV file from S3
csv_obj = s3.get_object(Bucket=bucket_name, Key=file_key)
body = csv_obj['Body']
csv_string = body.read().decode('utf-8')

# Use StringIO to create a file-like object from the CSV string
csv_file = StringIO(csv_string)



sap_bucket_name = 'brla-est-sap-tables-bucket'
sap_file_key = 'qas/Archive/ZSD_OS_TAB1/ZSD_OS_TAB1_27_08_2024.CSV'


# Read the CSV file from S3
sap_csv_obj = s3.get_object(Bucket=sap_bucket_name, Key=sap_file_key)
sap_body = sap_csv_obj['Body']
sap_csv_string = sap_body.read().decode('utf-8')

# Use StringIO to create a file-like object from the CSV string
sap_csv_file = StringIO(sap_csv_string)





# Read the CSV file into a pandas DataFrame
df = pd.read_csv(csv_file)
sap_df = pd.read_csv('s3://brla-est-sap-tables-bucket/qas/Archive/ZSD_OS_TAB1/ZSD_OS_TAB1_27_08_2024.CSV')

df['channelType'] = df['channelPartnerRefId'].apply(lambda x: 'Direct' if pd.isnull(x) else 'CP')

sap_df['sourceType'] = sap_df['SOURCE'].apply(lambda x: 'CP' if x=='Broker' else 'Direct')

df['walkInCreatedAt'] = pd.to_datetime(df['walkInCreatedAt']).dt.date
sap_df['AUDAT'] = pd.to_datetime(sap_df['AUDAT']).dt.date
#df['BookingStatus'] = df['opportunityStatus'].apply(lambda x: 'Booking' if x == 'Z4' else 'No Booking')


# Define the mapping dictionary for ProjectName
project_name_map = {
    'BETI': 'Birla%20Tisya',
    'BEAN': 'Birla%20Anayu',
    'BENA': 'Birla%20Navya',
    'BESH': 'Birla%20Vanya',
    'BENI': 'Birla%20Niyaara',
    'BEAL': 'Birla%20Alokya',
    'BETR': 'Birla%20Trimaya',
    'BEOJ': 'Birla%20Ojasvi'
}
# Map the 'projectRefId' column to 'ProjectName'
df['ProjectName'] = df['projectRefId'].map(project_name_map).fillna('Unknown Project')

# Define the mapping dictionary for Project Region
project_region_map = {
      
    'BENA': 'NCR',
    'BENI': 'MMR',
    'BEAN': 'MMR',
    'BESH': 'MMR',
    'BETI': 'Bengaluru',
    'BEAL': 'Bengaluru',
    'BETR': 'Bengaluru',
    'BEOJ': 'Bengaluru'
}

# Define the mapping dictionary for Mobile No


region_mobile_map = {
      
    'NCR': '8879393782',
    'MMR': '8879393782',
    'Bengaluru': '8879393782'
}

project_mobile_map = {
      
#    'Birla%20Vanya': '7021591262',
#    'Birla%20Trimaya': '8454900623',
#    'Birla%20Niyaara': '7799265413',
#    'Birla%20Tisya': '9324404359',
#    'Birla%20Alokya': '9607717199',
#    'Birla%20Navya': '9518987947',
#    'Birla%20Ojasvi': '9686488144',
#    'Birla%20Anayu': '9843981125'
    
#     'Birla%20Vanya': '8879393782',
#     'Birla%20Trimaya': '8879393782',
#     'Birla%20Niyaara': '8879393782',
#     'Birla%20Tisya': '8879393782',
#     'Birla%20Alokya': '8879393782',
#     'Birla%20Navya': '8879393782',
#     'Birla%20Ojasvi': '8879393782',
#     'Birla%20Anayu': '8879393782',
   
     'Birla%20Vanya': '8879393782',
     'Birla%20Trimaya': '8879393782',
     'Birla%20Niyaara': '8879393782',
     'Birla%20Tisya': '8879393782',
     'Birla%20Alokya': '8879393782',
     'Birla%20Navya': '8879393782',
     'Birla%20Ojasvi': '8879393782',
     'Birla%20Anayu': '8879393782'

}

# Map the 'projectRefId' column to 'ProjectName'
df['ProjectRegion'] = df['projectRefId'].map(project_region_map).fillna('Unknown Project')


# Create a new column 'periodType' based on the condition of 'walkInCreatedAt'
df['periodType'] = df['walkInCreatedAt'].apply(
    lambda x: 'MTD' if x.year == current_date.year and x.month == current_date.month else 'PTD'
)
df = df[df['periodType'] == 'MTD']

# Define the current week range (Monday to Sunday)

start_of_week = current_date - timedelta(days=current_date.weekday())
end_of_week = start_of_week + timedelta(days=6)
current_date = current_date - timedelta(days=1)

# Add the 'FTD' and 'WTD' columns
df['FTDPeriod'] = df['walkInCreatedAt'].apply(lambda x: 'FTD' if x == current_date else '')
df['WTDPeriod'] = df['walkInCreatedAt'].apply(lambda x: 'WTD' if start_of_week <= x <= end_of_week else '')





# Group by data for MTD
walkins_df = df.groupby(['ProjectName','ProjectRegion','channelType','periodType','FTDPeriod','WTDPeriod'])['walkInId'].nunique().reset_index(name='count_distinct_walkInId')
walkins_df


pivot_table = walkins_df.pivot_table(
    index='ProjectName',
    columns='channelType',
    values='count_distinct_walkInId',
    aggfunc='sum',
    fill_value=0
)

pivot_table1 = walkins_df.pivot_table(
    index='ProjectRegion',
    columns='channelType',
    values='count_distinct_walkInId',
    aggfunc='sum',
    fill_value=0
)

sap_df['ProjectRegion'] = sap_df['VKORG'].map(project_region_map).fillna('Unknown Project')
sap_df['AUDAT'] = pd.to_datetime(sap_df['AUDAT'])

sap_df['periodType'] = sap_df['AUDAT'].apply(
    lambda x: 'MTD' if x.year == current_date.year and x.month == current_date.month else 'PTD'
)

sap_df = sap_df[sap_df['periodType'] == 'MTD']

sap_df['FTDPeriod'] = sap_df['AUDAT'].apply(lambda x: 'FTD' if x == current_date else '') 
sap_df['WTDPeriod'] = sap_df['AUDAT'].apply(lambda x: 'WTD' if start_of_week <= x <= end_of_week else '')

booking_df = sap_df.groupby(['VTEXT','ProjectRegion','sourceType','periodType','FTDPeriod','WTDPeriod'])['MATNR'].count().reset_index(name='count_distinct_bookings')


booking_pivot_table = booking_df.pivot_table(
    index='VTEXT',
    columns='sourceType',
    values='count_distinct_bookings',
    aggfunc='sum',
    fill_value=0
)

booking_pivot_table1 = booking_df.pivot_table(
    index='ProjectRegion',
    columns='sourceType',
    values='count_distinct_bookings',
    aggfunc='sum',
    fill_value=0
)






# Reset the index to make 'mobile' a column again
pivot_table.reset_index(inplace=True)
pivot_table1.reset_index(inplace=True)

booking_pivot_table.reset_index(inplace=True)
booking_pivot_table1.reset_index(inplace=True)

# Ensure 'CP' and 'Direct' columns are present and fill missing ones with zeros
if 'CP' not in pivot_table:
    pivot_table['CP'] = 0

if 'Direct' not in pivot_table:
    pivot_table['Direct'] = 0
    
if 'CP' not in pivot_table1:
    pivot_table1['CP'] = 0

if 'Direct' not in pivot_table1:
    pivot_table1['Direct'] = 0
    
############################################    
if 'CP' not in pivot_table:
    booking_pivot_table['CP'] = 0

if 'Direct' not in pivot_table:
    booking_pivot_table['Direct'] = 0
    
if 'CP' not in pivot_table1:
    booking_pivot_table1['CP'] = 0

if 'Direct' not in pivot_table1:
    booking_pivot_table1['Direct'] = 0    

# Calculate the sum of 'CP' and 'Direct' for each 'mobile'
pivot_table['Total'] = pivot_table['CP'] + pivot_table['Direct']
pivot_table1['Total'] = pivot_table1['CP'] + pivot_table1['Direct']


booking_pivot_table['Total'] = pivot_table['CP'] + pivot_table['Direct']
booking_pivot_table1['Total'] = pivot_table1['CP'] + pivot_table1['Direct']

walkins_df = walkins_df[walkins_df['FTDPeriod'] == 'FTD']

pivot_table_ftd = walkins_df.pivot_table(
    index='ProjectName',
    columns='channelType',
    values='count_distinct_walkInId',
    aggfunc='sum',
    fill_value=0
)
pivot_table_ftd1 = walkins_df.pivot_table(
    index='ProjectRegion',
    columns='channelType',
    values='count_distinct_walkInId',
    aggfunc='sum',
    fill_value=0
)


booking_df = booking_df[booking_df['FTDPeriod'] == 'FTD']


booking_pivot_table_ftd = booking_df.pivot_table(
    index='VTEXT',
    columns='channelType',
    values='count_distinct_walkInId',
    aggfunc='sum',
    fill_value=0
)
booking_pivot_table_ftd1 = booking_df.pivot_table(
    index='ProjectRegion',
    columns='channelType',
    values='count_distinct_walkInId',
    aggfunc='sum',
    fill_value=0
)


# Reset the index to make 'mobile' a column again
pivot_table_ftd.reset_index(inplace=True)
pivot_table_ftd1.reset_index(inplace=True)

booking_pivot_table_ftd.reset_index(inplace=True)
booking_pivot_table_ftd1.reset_index(inplace=True)

# Ensure 'CP' and 'Direct' columns are present and fill missing ones with zeros
if 'CP' not in booking_pivot_table_ftd:
    booking_pivot_table_ftd['CP'] = 0

if 'Direct' not in booking_pivot_table_ftd:
    booking_pivot_table_ftd['Direct'] = 0
    

if 'CP' not in booking_pivot_table_ftd1:
    booking_pivot_table_ftd1['CP'] = 0

if 'Direct' not in booking_pivot_table_ftd1:
    booking_pivot_table_ftd1['Direct'] = 0

# Calculate the sum of 'CP' and 'Direct' for each 'mobile'
pivot_table_ftd['Total'] = pivot_table_ftd['CP'] + pivot_table_ftd['Direct']
pivot_table_ftd1['Total'] = pivot_table_ftd1['CP'] + pivot_table_ftd1['Direct']

booking_pivot_table_ftd['Total'] = booking_pivot_table_ftd['CP'] + booking_pivot_table_ftd['Direct']
booking_pivot_table_ftd1['Total'] = booking_pivot_table_ftd1['CP'] + booking_pivot_table_ftd1['Direct']


pivot_table_ftd.rename(columns={'Total': 'W_FTD_TOTAL', 'CP': 'W_FTD_CP','Direct':'W_FTD_D'}, inplace=True)
pivot_table_ftd1.rename(columns={'Total': 'W_FTD_TOTAL', 'CP': 'W_FTD_CP','Direct':'W_FTD_D'}, inplace=True)
pivot_table_ftd1


booking_pivot_table_ftd.rename(columns={'Total': 'W_FTD_TOTAL', 'CP': 'W_FTD_CP','Direct':'W_FTD_D'}, inplace=True)
booking_pivot_table_ftd1.rename(columns={'Total': 'W_FTD_TOTAL', 'CP': 'W_FTD_CP','Direct':'W_FTD_D'}, inplace=True)


# Group by data
#df = df[df['BookingStatus'] == 'Booking']
#booking_df = df.groupby(['ProjectName','channelType'])['walkInId'].nunique().reset_index(name='count_distinct_walkInId')
#booking_df1 = df.groupby(['ProjectRegion','channelType'])['walkInId'].nunique().reset_index(name='count_distinct_walkInId')
#booking_df
#booking_df1

#pivot_booking_table = booking_df.pivot_table(
#    index='ProjectName',
#    columns='channelType',
#   values='count_distinct_walkInId',
#    aggfunc='sum',
#    fill_value=0
#)

#pivot_booking_table1 = booking_df1.pivot_table(
#    index='ProjectRegion',
#    columns='channelType',
#    values='count_distinct_walkInId',
#    aggfunc='sum',
#   fill_value=0
#)

# Reset the index to make 'mobile' a column again
#pivot_booking_table.reset_index(inplace=True)
#pivot_booking_table1.reset_index(inplace=True)

# Ensure 'CP' and 'Direct' columns are present and fill missing ones with zeros
#if 'CP' not in pivot_booking_table:
#    pivot_booking_table['CP'] = 0

#if 'Direct' not in pivot_booking_table:
#    pivot_booking_table['Direct'] = 0
    
#if 'CP' not in pivot_booking_table1:
#    pivot_booking_table1['CP'] = 0

#if 'Direct' not in pivot_booking_table1:
#    pivot_booking_table1['Direct'] = 0

# Calculate the sum of 'CP' and 'Direct' for each 'mobile'
#pivot_booking_table['Total'] = pivot_booking_table['CP'] + pivot_booking_table['Direct']
#pivot_booking_table1['Total'] = pivot_booking_table1['CP'] + pivot_booking_table1['Direct']


#pivot_booking_table.rename(columns={'Total': 'BT', 'CP': 'BCP','Direct':'BD'}, inplace=True)
#pivot_booking_table1.rename(columns={'Total': 'BT', 'CP': 'BCP','Direct':'BD'}, inplace=True)
#pivot_booking_table1



# Perform an inner join on the 'ID' column
#final_df = pd.merge(pivot_table, pivot_booking_table, on=['ProjectName'], how='left')
#final_df = pd.merge(final_df, pivot_table_ftd, on=['ProjectName'], how='left')
#final_df1 = pd.merge(pivot_table1, pivot_booking_table1, on=['ProjectRegion'], how='left')
#final_df1 = pd.merge(final_df1, pivot_table_ftd1, on=['ProjectRegion'], how='left')

final_df = pd.merge(pivot_table, booking_pivot_table, left_on=['ProjectName'], right_on='VTEXT', how='left')
final_df = pd.merge(final_df, booking_pivot_table_ftd, left_on=['ProjectName'], right_on='VTEXT', how='left')
final_df1 = pd.merge(pivot_table1, pivot_booking_table1, on=['ProjectRegion'], how='left')
final_df1 = pd.merge(final_df1, pivot_table_ftd1, on=['ProjectRegion'], how='left')

final_df.fillna(0, inplace=True)
final_df['BCP'] = final_df['BCP'].astype(int)
final_df['BD'] = final_df['BD'].astype(int)
final_df['BT'] = final_df['BT'].astype(int)

final_df1.fillna(0, inplace=True)
final_df1['BCP'] = final_df1['BCP'].astype(int)
final_df1['BD'] = final_df1['BD'].astype(int)
final_df1['BT'] = final_df1['BT'].astype(int)

final_df['W_FTD_CP'] = final_df['W_FTD_CP'].astype(int)
final_df['W_FTD_D'] = final_df['W_FTD_D'].astype(int)
final_df['W_FTD_TOTAL'] = final_df['W_FTD_TOTAL'].astype(int)

final_df1['W_FTD_CP'] = final_df1['W_FTD_CP'].astype(int)
final_df1['W_FTD_D'] = final_df1['W_FTD_D'].astype(int)
final_df1['W_FTD_TOTAL'] = final_df1['W_FTD_TOTAL'].astype(int)

# Map the 'projectRefId' column to 'ProjectName'
final_df['MobileNo'] = final_df['ProjectName'].map(project_mobile_map).fillna('Unknown Project')
final_df1['MobileNo'] = final_df1['ProjectRegion'].map(region_mobile_map).fillna('Unknown Project')

final_df1


for index, row in final_df.iterrows():
    Mobile = row['MobileNo']
    ProjectName = row['ProjectName']
    #Walking MTD
    WT = row['Total']
    WD = row['Direct']
    WCP = row['CP']
    
    #Walking FTD
    FWT = row['W_FTD_TOTAL']
    FWD = row['W_FTD_D']
    FWCP = row['W_FTD_CP']
    #booking
    
    BT = row['BT']
    BD = row['BD']
    BCP = row['BCP']
    
    url = f"https://media.smsgupshup.com/GatewayAPI/rest?userid=2000224168&password=WYxJruK%23&send_to={Mobile}&v=1.1&format=json&msg_type=TEXT&method=SENDMESSAGE&v=1.1&format=json&msg_type=TEXT&method=SENDMESSAGE&msg=Hello%2C%0ABelow+is+key+Information+on+Walk-ins+and+Walk-in+to+Booking+Conversions+.%0A%0AProject++%3A+{ProjectName}%0A%0AWalk-ins+-+FTD%0ATotal+Walk-ins+for+the+Day+++++++%3A+{FWT}+%0ADirect+Walk-ins+for+the+Day+++++%3A+{FWD}%0ACP+Walk-ins+for+the+Day++++++++++%3A+{FWCP}%0A%0AWalk-ins+-+MTD%0ATotal+Walk-ins+for+the+Month++++++%3A+{WT}%0ADirect+Walk-ins+for+the+Month+++++%3A+{WD}%0ACP+Walk-ins+for+the+Month+++++++++%3A+{WCP}%0A%0ABooking+Conversions-+MTD%0ATotal+Booking+Conversions+for+the+Month++++++%3A+{BT}%0ADirect+Booking+Conversions+for+the+Month+++++%3A+{BD}%0ACP+Booking+Conversions+for+the+Month+++++++++%3A+{BCP}&isTemplate=true&header=Daily+Report&footer=Birla+Estates"
    
    #submit request for each constructed URL to whatsapp server
    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)
#     print(url)


for index, row in final_df1.iterrows():
    Mobile = row['MobileNo']
    ProjectRegion = row['ProjectRegion']
    #Walking MTD
    WT = row['Total']
    WD = row['Direct']
    WCP = row['CP']
    
    #Walking FTD
    FWT = row['W_FTD_TOTAL']
    FWD = row['W_FTD_D']
    FWCP = row['W_FTD_CP']
    #booking
    
    BT = row['BT']
    BD = row['BD']
    BCP = row['BCP']
    
    url = f"https://media.smsgupshup.com/GatewayAPI/rest?userid=2000224168&password=WYxJruK%23&send_to={Mobile}&v=1.1&format=json&msg_type=TEXT&method=SENDMESSAGE&v=1.1&format=json&msg_type=TEXT&method=SENDMESSAGE&msg=Hello%2C%0ABelow+is+key+Information+on+Walk-ins+and+Walk-in+to+Booking+Conversions+.%0A%0AProject++%3A+{ProjectRegion}%0A%0AWalk-ins+-+FTD%0ATotal+Walk-ins+for+the+Day+++++++%3A+{FWT}+%0ADirect+Walk-ins+for+the+Day+++++%3A+{FWD}%0ACP+Walk-ins+for+the+Day++++++++++%3A+{FWCP}%0A%0AWalk-ins+-+MTD%0ATotal+Walk-ins+for+the+Month++++++%3A+{WT}%0ADirect+Walk-ins+for+the+Month+++++%3A+{WD}%0ACP+Walk-ins+for+the+Month+++++++++%3A+{WCP}%0A%0ABooking+Conversions-+MTD%0ATotal+Booking+Conversions+for+the+Month++++++%3A+{BT}%0ADirect+Booking+Conversions+for+the+Month+++++%3A+{BD}%0ACP+Booking+Conversions+for+the+Month+++++++++%3A+{BCP}&isTemplate=true&header=Daily+Report&footer=Birla+Estates"
    
    #submit request for each constructed URL to whatsapp server
    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)
#     print(url)


# List of mobile numbers
mobile_numbers = ['8879393782']

# Create a DataFrame with the mobile numbers
df_mobile = pd.DataFrame(mobile_numbers, columns=['Mobile_No'])
# df_mobile

# Perform the cross join
df_mobile['key'] = 1
final_df['key'] = 1

df_cross = pd.merge(final_df, df_mobile, on='key').drop('key', axis=1)
# df_cross
## Reset index to make 'channelType' a column again
aggregated_df = df_cross.groupby('Mobile_No').sum().reset_index()
aggregated_df


for index, row in aggregated_df.iterrows():
    Mobile = row['Mobile_No']
    ProjectName = 'All Projects'
    #Walking MTD
    WT = row['Total']
    WD = row['Direct']
    WCP = row['CP']
    
    #Walking FTD
    FWT = row['W_FTD_TOTAL']
    FWD = row['W_FTD_D']
    FWCP = row['W_FTD_CP']
    #booking
    
    BT = row['BT']
    BD = row['BD']
    BCP = row['BCP']
    
    url = f"https://media.smsgupshup.com/GatewayAPI/rest?userid=2000224168&password=WYxJruK%23&send_to={Mobile}&v=1.1&format=json&msg_type=TEXT&method=SENDMESSAGE&v=1.1&format=json&msg_type=TEXT&method=SENDMESSAGE&msg=Hello%2C%0ABelow+is+key+Information+on+Walk-ins+and+Walk-in+to+Booking+Conversions+.%0A%0AProject++%3A+{ProjectName}%0A%0AWalk-ins+-+FTD%0ATotal+Walk-ins+for+the+Day+++++++%3A+{FWT}+%0ADirect+Walk-ins+for+the+Day+++++%3A+{FWD}%0ACP+Walk-ins+for+the+Day++++++++++%3A+{FWCP}%0A%0AWalk-ins+-+MTD%0ATotal+Walk-ins+for+the+Month++++++%3A+{WT}%0ADirect+Walk-ins+for+the+Month+++++%3A+{WD}%0ACP+Walk-ins+for+the+Month+++++++++%3A+{WCP}%0A%0ABooking+Conversions-+MTD%0ATotal+Booking+Conversions+for+the+Month++++++%3A+{BT}%0ADirect+Booking+Conversions+for+the+Month+++++%3A+{BD}%0ACP+Booking+Conversions+for+the+Month+++++++++%3A+{BCP}&isTemplate=true&header=Daily+Report&footer=Birla+Estates"
    
    #submit request for each constructed URL to whatsapp server
    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)
#     print(url)

